# StreamPlay Stremio Addon

A pengu.uk-style, self-hostable multi-source stream addon for Stremio,
ported from the [StreamPlay](../StreamPlay) Cloudstream extension. Users pick
their sources and fine-tune output in a configure page; the selection is
encoded statelessly in the addon URL (no database, no accounts, trivial VPS
hosting).

## Features

- **27 sources** with per-source toggles (like pengu's `source_*` config):

  | Source     | Kind   | What it does |
  |------------|--------|--------------|
  | 4KHDHub    | scraper| WordPress search -> HubCloud / GDFlix / Pixeldrain file hosts |
  | HDHub4u    | scraper| pingora Typesense search -> HubCloud / GDFlix |
  | VegaMovies | scraper| Typesense search API -> V-Cloud servers |
  | RogMovies  | scraper| Typesense search API -> V-Cloud / G-Direct / M4uplay |
  | MoviesDrive| scraper| search.php API -> HubCloud / GDFlix (incl. search-recover) |
  | MovieBox   | scraper| Signed Android-app API: MP4 + DASH, multi-audio dubs, captions |
  | 2Embed     | scraper| vidcore.io (enc-dec.app) HLS, fallback 2embed.cc -> uqloads |
  | Cinejoy    | scraper| api.wing.st encrypted multi-server HLS |
  | Vidy       | scraper| api.wecollege.net multi-city servers (custom keystream cipher) |
  | Videasy    | direct | player.videasy.to 9 servers (same keystream cipher, TMDB keyed) |
  | Bollyflix  | scraper| post pages -> sidexfee decode -> HubCloud |
  | MoviesMod  | scraper| post pages -> hrefli bypass -> HubCloud / GDFlix / driveseed |
  | UHDMovies  | scraper| search -> driveleech redirect or hrefli bypass -> HubCloud |
  | TopMovies  | scraper| WordPress search -> g-drive fast servers -> hrefli bypass |
  | MultiMovies| scraper| server chips -> modiplay / filemoon HLS (JS-unpacked) |
  | Movies4u   | scraper| lookup.php Typesense + download pages -> HubCloud |
  | Hdmovie2   | scraper| dooplay player ajax -> GDFlix / resolvable embeds |
  | Hindmoviez | scraper| hindshare-signed dl pages -> HubCloud / GDFlix |
  | VidSrc     | direct | data.vidsrc.sh API + per-server token (IMDb keyed) |
  | VidLink    | direct | vidlink.pro multi-quality HLS (TMDB keyed) |
  | VidRock    | direct | vidrock.ru AES-GCM decrypted HLS (TMDB keyed) |
  | VidFast    | direct | vidfast.vc servers via enc-dec.app (TMDB keyed) |
  | VidUp      | direct | vidup.to servers via enc-dec.app (TMDB keyed) |
  | VidZee     | direct | core.vidzee.wtf multi-server (Dcloud/Doppler/Acme/TCloud) |
  | XPass      | direct | play.xpass.top SHA-256/AES-GCM server playlists |
  | Vadapav    | direct | stremio.vadapav.mov direct streams (IMDb keyed) |
  | Atlantic   | direct | hls.lol family (7 sub-flows incl. nesterov AES-GCM) |

  Unresolvable embed-only players are skipped silently (Stremio can't play
  iframes) - the router unpacks the filemoon family and drops the rest.

- **Stream title Formatter** - a template like `{source} {quality} {size}`
  with placeholders `{source} {quality} {size} {title} {se} {year} {lang}
  {host}` (live preview in the configure page).
- **Quality filter** (2160/1080/720/480/360) and `disable direct providers`
  master switch (pengu's `disable_direct`).
- **Sorting & limits** - quality-first / size-first / grouped-by-source,
  per-source and total stream caps.
- **Catalogs** - Trending Movies / Series, Anime, Indian Cinema (TMDB-powered
  when `TMDB_API` is set, automatic Cinemeta fallback otherwise) + search.
- **Subtitles resource** - OpenSubtitles (Stremio addon) merged with Wyzie,
  ordered by preferred languages.
- **Runtime domain resolution** - scrapers fetch live domains from the same
  `domains.json` the Cloudstream extension uses, so domain migrations keep
  working without redeploying.
- Metadata via Cinemeta (no TMDB key needed for streams).

## Run locally

```bash
npm install
npm start          # http://localhost:7000
```

Open <http://localhost:7000/configure>, pick sources, tweak the formatter,
copy the manifest URL and install it in Stremio (`stremio://` button).

## Deploy on a VPS

### Option A - Docker (recommended)

```bash
cd streamplay-stremio
docker compose up -d --build
```

The compose file ships a healthcheck (`/health`) and `restart:
unless-stopped`.

### Option B - systemd

```bash
sudo cp -r streamplay-stremio /opt/streamplay-addon
cd /opt/streamplay-addon && npm ci --omit=dev
sudo cp deploy/streamplay-addon.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now streamplay-addon
```

### TLS / reverse proxy

Put nginx (or Caddy) in front:

```bash
sudo cp deploy/nginx-streamplay.conf /etc/nginx/sites-available/streamplay
# edit server_name, then:
sudo ln -s /etc/nginx/sites-available/streamplay /etc/nginx/sites-enabled/
sudo certbot --nginx -d addon.example.com
sudo systemctl reload nginx
```

Then your configure page is `https://addon.example.com/configure` and the
manifest URL installs as `https://addon.example.com/c/<cfg>/manifest.json`.
The addon honors `X-Forwarded-Proto/Host`, so URLs come out HTTPS-correct
automatically.

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `PORT` | `7000` | HTTP port |
| `HOST` | `0.0.0.0` | Bind address |
| `SOURCE_TIMEOUT_MS` | `12000` | Per-source hard timeout |
| `MAX_STREAMS` | `120` | Hard cap on returned streams |
| `TMDB_API` | unset | TMDB-powered catalogs (falls back to Cinemeta) |
| `STREAMPLAY_DOMAINS_URL` | TVVVV `domains.json` | Override live-domain source |
| `MOVIEBOX_HOST` | `https://apig.inmoviebox.com` | MovieBox API host |
| `MOVIEBOX_CLIENT_BUILD` | embedded | MovieBox session id (x-client-build) |
| `MOVIEBOX_SECRET_KEY_DEFAULT` / `MOVIEBOX_SECRET_KEY_ALT` | embedded (base64) | MovieBox signing keys |

All variables can also live in a `.env` file next to `src/` (loaded at boot,
no dependency).

## API surface

| Route | Description |
|-------|-------------|
| `/manifest.json` | Manifest for default config |
| `/c/<cfg>/manifest.json` | Manifest for your config |
| `/c/<cfg>/stream/{movie\|series}/<imdb>[:s:e].json` | Streams |
| `/c/<cfg>/catalog/{type}/{id}/[extras].json` | Catalogs (genre/skip/search extras) |
| `/c/<cfg>/subtitles/{type}/{imdb}[:s:e].json` | Subtitles |
| `/configure` | Configuration page |
| `/api/sources` | Source/catalog/feature metadata for the UI |
| `/health` | Health endpoint for uptime monitors |

## Notes & limitations (v1.2)

- **Anime sources (miruro, anikoto, anipm...) are not ported** - they need a
  browser-grade Cloudflare bypass (WebView) that a plain server can't do.
  Pengu-exclusive sources (Arctic, Nexa, Moflix, VAPlayer, Vidly.net,
  Live TV...) have no StreamPlay implementation to port from.
- **KissKH is omitted** - it depends on private key-server endpoints from
  the extension's build secrets.
- vidsrc.sh / vidfast / vidup / vidcore moved parts of their flows behind
  client-side rendering or WASM decryptors; those sources fail soft (empty).
  Videasy needs api.speedracelight.com reachable from your VPS.
- The heavy scrapers (Bollyflix/TopMovies/UHDMovies/Hindmoviez) chain 5-8
  sequential pages per link; they often fill their 20s per-source budget and
  may return fewer links on slower networks. Bump `SOURCE_TIMEOUT_MS` on a
  fast VPS.
- MovieBox DASH plays in Stremio desktop; some mobile clients need an
  external player for `.mpd`.
- Scraped sites change often; all scrapers resolve live domains at runtime
  and fail soft (skipped on error), never breaking the whole response.
