// StreamPlay configure dashboard.
// Stateless config -> /c/<base64url>/manifest.json. Hash routes the views.

const FALLBACK_SOURCES = [
  ['general', [
    { id: 'k4hdhub', label: '4KHDHub', kind: 'scraper', def: true, tags: ['4K', 'Mainstream', 'Classics'] },
    { id: 'hdhub4u', label: 'HDHub4u', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Hindi'] },
    { id: 'vegamovies', label: 'VegaMovies', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Regional'] },
    { id: 'moviesdrive', label: 'MoviesDrive', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Mainstream'] },
    { id: 'moviebox', label: 'MovieBox', kind: 'scraper', def: true, tags: ['1080p', 'Fast', 'Multi-Audio'] },
    { id: '2embed', label: '2Embed', kind: 'scraper', def: true, tags: ['1080p', 'HLS', 'MP4'] },
    { id: 'cinejoy', label: 'Cinejoy', kind: 'scraper', def: true, tags: ['1080p', 'HLS', 'Multi-Server'] },
    { id: 'vidy', label: 'Vidy', kind: 'scraper', def: true, tags: ['4K', 'Multi-Server', '1080p'] },
    { id: 'vidsrc', label: 'VidSrc', kind: 'direct', def: true, tags: ['1080p', 'HLS', 'Fast'] },
    { id: 'vidlink', label: 'VidLink', kind: 'direct', def: true, tags: ['4K', 'HLS', 'Mainstream'] },
    { id: 'vidrock', label: 'VidRock', kind: 'direct', def: true, tags: ['1080p', 'HLS', 'Mainstream'] },
    { id: 'vidfast', label: 'VidFast', kind: 'direct', def: true, tags: ['4K', 'HLS', 'Fast'] },
    { id: 'videasy', label: 'Videasy', kind: 'direct', def: true, tags: ['4K', 'Multi-Server', '1080p'] },
    { id: 'vidup', label: 'VidUp', kind: 'direct', def: true, tags: ['1080p', 'HLS', 'Fast'] },
    { id: 'vidzee', label: 'VidZee', kind: 'direct', def: true, tags: ['1080p', 'Multi-Server', 'Multi-Audio'] },
    { id: 'xpass', label: 'XPass', kind: 'direct', def: true, tags: ['1080p', 'Multi-Server', 'HLS'] },
    { id: 'vadapav', label: 'Vadapav', kind: 'direct', def: true, tags: ['1080p', 'Fast', 'Direct'] },
    { id: 'atlantic', label: 'Atlantic', kind: 'direct', def: true, tags: ['4K', 'HLS', 'Multi-Server'] },
  ]],
  ['regional', [
    { id: 'bollyflix', label: 'Bollyflix', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Bollywood'] },
    { id: 'rogmovies', label: 'RogMovies', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Regional'] },
    { id: 'moviesmod', label: 'MoviesMod', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Dual-Audio'] },
    { id: 'uhdmovies', label: 'UHDMovies', kind: 'scraper', def: true, tags: ['4K', '1080p', 'Remux'] },
    { id: 'topmovies', label: 'TopMovies', kind: 'scraper', def: true, tags: ['1080p', 'G-Drive', 'Fast'] },
    { id: 'multimovies', label: 'MultiMovies', kind: 'scraper', def: true, tags: ['1080p', 'HLS', 'Multi-Server'] },
    { id: 'movies4u', label: 'Movies4u', kind: 'scraper', def: true, tags: ['1080p', 'Mainstream', 'Fast'] },
    { id: 'hdmovie2', label: 'Hdmovie2', kind: 'scraper', def: true, tags: ['1080p', 'MP4', 'Regional'] },
    { id: 'hindmoviez', label: 'Hindmoviez', kind: 'scraper', def: true, tags: ['1080p', 'Hindi', 'Regional'] },
  ]],
];
const FALLBACK_CATALOGS = [
  { id: 'streamplay-trending-movies', name: 'Trending Movies', def: true },
  { id: 'streamplay-trending-series', name: 'Trending Series', def: true },
  { id: 'streamplay-anime', name: 'Anime', def: false },
  { id: 'streamplay-indian', name: 'Indian Cinema', def: false },
];
const FALLBACK_SUB_LANGS = [
  { code: 'en', label: 'English' }, { code: 'hi', label: 'Hindi' }, { code: 'es', label: 'Spanish' },
  { code: 'fr', label: 'French' }, { code: 'de', label: 'German' }, { code: 'pt', label: 'Portuguese' },
  { code: 'ar', label: 'Arabic' }, { code: 'ru', label: 'Russian' }, { code: 'ja', label: 'Japanese' },
];
const RESOLUTIONS = [2160, 1080, 720, 480, 360];
const RES_LABELS = { 2160: '4K', 1080: '1080p', 720: '720p', 480: '480p', 360: '360p' };
const PLACEHOLDERS = ['{source}', '{quality}', '{size}', '{title}', '{se}', '{year}', '{lang}', '{host}'];
const FALLBACK_PRESETS = [
  { name: 'Default', nf: '{source}', fd: '{quality} {size} {title}' },
  { name: 'Detailed', nf: '{source} {quality}', fd: '{title} {size} {lang} {host}' },
  { name: 'Minimal', nf: '{source}', fd: '{quality}' },
  { name: 'Plex style', nf: '{quality} {source}', fd: '{title} • {size} • {lang}' },
  { name: 'Tech', nf: '{source} [{quality}]', fd: '{title} {size} {se} {host}' },
];
const DEFAULT_NF = '{source}';
const DEFAULT_FD = '{quality} {size} {title}';
const SAMPLE_MOVIE = { source: 'HDHub4u HubCloud [FSLv2]', title: 'UHD BLURAY HEVC DDP5.1 [18.5GB]', quality: 2160, url: 'https://hubcloud.example/dl' };
const SAMPLE_SERIES = { source: 'VegaMovies V-Cloud', title: 'Slow Horses S01E03 1080p WEB-DL HEVC [2.1GB]', quality: 1080, url: 'https://vcloud.example/dl' };
const SAMPLE = { source: '4KHDHub HubCloud [FSLv2]', title: 'UHD BLURAY HEVC DDP5.1 [2.3GB]', quality: 2160, url: 'https://hubcloud.example/download/file.mkv' };

const VIEWS = {
  formatter: ['Formatter', 'Stream title presets & preview'],
  keys: ['Keys', 'FebBox & debrid credentials'],
  overview: ['Overview', 'Install status & sync'],
  sources: ['Sources', 'Providers & resolutions'],
  filtering: ['Filtering', 'Filesize bounds & stream filters'],
  playback: ['Playback', 'Priority, formatter & subtitles'],
};

let SOURCES = [];          // [{def, cat}]
let CATALOGS = FALLBACK_CATALOGS;
let SUB_LANGS = FALLBACK_SUB_LANGS;
let PRESETS = FALLBACK_PRESETS;
let state = null;
let savedUrl = null;       // last-synced URL
let fmtTouched = false;

const $ = (sel) => document.querySelector(sel);

/* ---------- config codec ---------- */

function allSources() {
  return SOURCES.flatMap(([cat, list]) => list.map((s) => ({ ...s, cat })));
}

function defaultConfig() {
  const s = {};
  const all = allSources();
  for (const src of all) s[src.id] = src.def;
  const ct = {};
  for (const cat of CATALOGS) ct[cat.id] = cat.def;
  return { s, res: [...RESOLUTIONS], nd: false, nf: DEFAULT_NF, fd: DEFAULT_FD, so: 'quality', ord: [], mp: 0, mt: 0, fs: [null, null], sk: false, ct, sl: ['en'], ns: false, k: {} };
}

function normalize(input) {
  const base = defaultConfig();
  const all = allSources();
  if (!input || typeof input !== 'object') return base;
  const out = { ...base };
  if (input.s && typeof input.s === 'object') {
    const s = {};
    for (const src of all) s[src.id] = typeof input.s[src.id] === 'boolean' ? input.s[src.id] : src.def;
    out.s = s;
  }
  if (Array.isArray(input.res)) {
    const allowed = input.res.map(Number).filter((r) => RESOLUTIONS.includes(r));
    if (allowed.length > 0) out.res = [...new Set(allowed)];
  }
  if (typeof input.nd === 'boolean') out.nd = input.nd;
  if (typeof input.nf === 'string' && input.nf.trim()) out.nf = input.nf.trim().slice(0, 160);
  if ((typeof input.fd === 'string' && input.fd.trim())) out.fd = input.fd.trim().slice(0, 160);
  else if (typeof input.f === 'string' && input.f.trim()) out.fd = input.f.trim().slice(0, 160);
  if (['quality', 'size', 'source'].includes(input.so)) out.so = input.so;
  if (Array.isArray(input.ord)) {
    const known = new Set(all.map((d) => d.id));
    out.ord = [...new Set(input.ord.filter((id) => known.has(id)))];
  }
  if (Number.isFinite(input.mp)) out.mp = Math.min(Math.max(Math.floor(input.mp), 0), 200);
  if (Number.isFinite(input.mt)) out.mt = Math.min(Math.max(Math.floor(input.mt), 0), 800);
  if (Array.isArray(input.fs) && input.fs.length === 2) {
    const min = Number.isFinite(input.fs[0]) && input.fs[0] > 0 ? input.fs[0] : null;
    const max = Number.isFinite(input.fs[1]) && input.fs[1] > 0 ? input.fs[1] : null;
    out.fs = [min, max && (!min || max > min) ? max : null];
  }
  if (typeof input.sk === 'boolean') out.sk = input.sk;
  if (input.ct && typeof input.ct === 'object') {
    const ct = {};
    for (const cat of CATALOGS) ct[cat.id] = typeof input.ct[cat.id] === 'boolean' ? input.ct[cat.id] : cat.def;
    out.ct = ct;
  }
  if (Array.isArray(input.sl)) {
    const codes = new Set(SUB_LANGS.map((l) => l.code));
    const sl = input.sl.filter((c) => codes.has(c));
    if (sl.length > 0) out.sl = [...new Set(sl)];
  }
  if (typeof input.ns === 'boolean') out.ns = input.ns;
  if (input.k && typeof input.k === 'object') {
    const k = {};
    if (typeof input.k.febbox === 'string') k.febbox = input.k.febbox.slice(0, 500);
    if (typeof input.k.rd === 'string') k.rd = input.k.rd.slice(0, 200);
    if (typeof input.k.tb === 'string') k.tb = input.k.tb.slice(0, 200);
    out.k = k;
  }
  return out;
}

function readConfigFromUrl() {
  const m = location.pathname.match(/^\/c\/([A-Za-z0-9\-_]+)/);
  if (m) {
    try {
      return normalize(JSON.parse(atob(m[1].replace(/-/g, '+').replace(/_/g, '/'))));
    } catch { /* fall through */ }
  }
  const q = new URLSearchParams(location.search).get('config');
  if (q) {
    try {
      return normalize(JSON.parse(atob(q.replace(/-/g, '+').replace(/_/g, '/'))));
    } catch { /* fall through */ }
  }
  return defaultConfig();
}

function encodeConfig(config) {
  return btoa(unescape(encodeURIComponent(JSON.stringify(config))))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function manifestUrl() {
  return `${location.origin}/c/${encodeConfig(state)}/manifest.json`;
}
function stremioUrl() {
  return manifestUrl().replace(/^https?:\/\//, 'stremio://');
}

/* ---------- sync / save state ---------- */

let syncTimer = null;
function markDirty() {
  if (savedUrl === manifestUrl()) return; // nothing actually changed
  $('#syncDot').classList.remove('saved');
  $('#syncTitle').textContent = 'Unsaved changes';
  $('#syncSub').textContent = 'updating URL...';
  $('#installStatus').textContent = 'Configuration updated — reinstall to apply.';
  clearTimeout(syncTimer);
  syncTimer = setTimeout(sync, 350);
  shortUrl = null;
  const url = manifestUrl();
  document.getElementById('installBtn').href = 'stremio://' + url.slice(url.indexOf('//') + 2);
  document.getElementById('installBtn').dataset.url = url;
}

function sync() {
  savedUrl = manifestUrl();
  $('#syncDot').classList.add('saved');
  $('#syncTitle').textContent = 'All changes saved';
  $('#syncSub').textContent = 'URL synced';
  $('#installStatus').textContent = '✓ Configuration ready';
  profiles.find((p) => p.id === activeProfile).state = state;
  persistProfiles();
  renderOverview();
}

function updateUrlBox() {
  const url = manifestUrl();
  $('#installBtn').href = stremioUrl();
  $('#installBtn').dataset.url = url;
}

/* ---------- formatter preview ---------- */

function fmtApply(template, link) {
  const size = (link.title.match(/\[\s*([\d.]+\s*(?:GB|MB|KB))\s*\]/i) || [])[1] || '';
  const quality = link.quality >= 2160 ? '4K' : link.quality ? `${link.quality}p` : '';
  const map = {
    '{source}': link.source,
    '{quality}': quality,
    '{size}': size,
    '{title}': link.title.replace(/\[[^\]]*\]/g, '').trim(),
    '{se}': 'S01E02',
    '{year}': '2023',
    '{lang}': 'Hindi',
    '{host}': 'hubcloud.example',
  };
  let out = template;
  for (const [k, v] of Object.entries(map)) out = out.split(k).join(v);
  return out.replace(/\s+/g, ' ').trim() || 'StreamPlay';
}

function renderPreview() {
  const wrap = document.getElementById('fmtPreviewCards');
  if (!wrap) return;
  const cards = [
    { kind: '4K movie (direct file)', link: SAMPLE_MOVIE },
    { kind: 'series episode (HLS)', link: SAMPLE_SERIES },
  ];
  wrap.innerHTML = '';
  for (const card of cards) {
    const name = fmtApply(state.nf, card.link);
    const desc = fmtApply(state.fd, card.link);
    const el = document.createElement('div');
    el.className = 'pv-card';
    el.innerHTML =
      '<div class="pv-kind">' + card.kind + '</div>' +
      '<div class="pv-name"></div>' +
      desc.split('\n').map((l) => '<div class="pv-line"></div>').join('');
    el.querySelector('.pv-name').textContent = name;
    el.querySelectorAll('.pv-line').forEach((line, i) => (line.textContent = desc.split('\n')[i]));
    wrap.appendChild(el);
  }
}

/* ---------- views ---------- */

function renderKeys() {
  document.getElementById('keyFebbox').value = state.k.febbox || '';
  document.getElementById('keyRd').value = state.k.rd || '';
  document.getElementById('keyTb').value = state.k.tb || '';
}

function showView(name) {
  for (const key of Object.keys(VIEWS)) {
    const el = $(`#view-${key}`);
    if (el) el.hidden = key !== name;
  }
  document.querySelectorAll('.nav-item[data-view]').forEach((a) => {
    a.classList.toggle('active', a.dataset.view === name);
  });
  const [title, sub] = VIEWS[name] || VIEWS.overview;
  $('#viewTitle').textContent = title;
  $('#viewSubtitle').textContent = sub;
  if (name === 'formatter') renderPreview();
  if (name === 'keys') renderKeys();
  if (name === 'playback') renderOrderList();
  if (name === 'overview') renderOverview();
  if (name === 'filtering') renderActiveFilters();
}

/* ---------- sources view ---------- */

function enabledCount() {
  return allSources().filter((s) => state.s[s.id] && !(s.kind === 'direct' && state.nd)).length;
}

function renderSources() {
  const wrap = $('#sourceGroups');
  const filter = ($('#sourceFilter').value || '').toLowerCase();
  wrap.innerHTML = '';

  for (const [cat, list] of SOURCES) {
    const group = document.createElement('div');
    const visible = list.filter((src) => {
      const matchesSearch = !filter || src.label.toLowerCase().includes(filter);
      const matchesType = activeType === 'all' || (src.types || ['movies', 'series']).includes(activeType);
      return matchesSearch && matchesType;
    });
    const on = visible.filter((s) => state.s[s.id]).length;
    group.innerHTML = `
      <div class="group-head">
        <span class="group-title">${cat}</span>
        <span class="group-count">${on}/${visible.length}</span>
        <span class="group-rule"></span>
      </div>`;
    if (visible.length === 0) {
      group.style.display = 'none';
    }
    const grid = document.createElement('div');
    grid.className = 'pill-grid';

    for (const src of list) {
      const isOn = state.s[src.id];
      const matchesSearch = !filter || src.label.toLowerCase().includes(filter);
      const matchesType = activeType === 'all' || (src.types || ['movies', 'series']).includes(activeType);
      const pill = document.createElement('div');
      pill.className = 'source-pill ' + (isOn ? 'on' : 'off');
      pill.dataset.source = src.id;
      pill.dataset.search = src.label.toLowerCase();
      if (!matchesSearch || !matchesType) pill.classList.add('hidden');
      pill.innerHTML = `
        <span class="check-circle"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"><path d="M5 13l4 4L19 7"/></svg></span>
        <span class="pill-name">${src.label}</span>
        <span class="pill-tags">${(src.tags || []).slice(0, 2).map((t) => `<span class="tag">${t}</span>`).join('')}</span>`;
      pill.addEventListener('click', () => {
        state.s[src.id] = !state.s[src.id];
        pill.classList.toggle('on', state.s[src.id]);
        pill.classList.toggle('off', !state.s[src.id]);
        refreshCounts();
        markDirty();
      });
      grid.appendChild(pill);
    }
    group.appendChild(grid);
    wrap.appendChild(group);
  }
  refreshCounts();
}

let activeType = 'all';

function renderTypeChips() {
  const wrap = $('#typeChips');
  if (!wrap) return;
  wrap.innerHTML = '';
  const all = allSources();
  const chips = [{ id: 'all', label: 'All' }, ...(window.__contentTypes || [])];
  for (const chip of chips) {
    const count =
      chip.id === 'all' ? all.length : all.filter((s) => (s.types || []).includes(chip.id)).length;
    const btn = document.createElement('button');
    btn.className = 'seg-btn small' + (activeType === chip.id ? ' on' : '');
    btn.innerHTML = `${chip.label} <span class="chip-count">${count}</span>`;
    btn.addEventListener('click', () => {
      activeType = chip.id;
      renderTypeChips();
      renderSources();
    });
    wrap.appendChild(btn);
  }
}

function refreshCounts() {
  const total = allSources().length;
  const on = allSources().filter((s) => state.s[s.id]).length;
  const active = enabledCount();
  $('#providerCount').textContent = `${on} of ${total} selected`;
  $('#navSourceCount').textContent = active;
  $('#topStat').textContent = `${active} sources · ${state.res.length} qualities`;
}

function renderResPills(container) {
  container.innerHTML = '';
  for (const res of RESOLUTIONS) {
    const on = state.res.includes(res);
    const pill = document.createElement('div');
    pill.className = 'res-pill' + (on ? '' : ' off');
    pill.innerHTML = `<span>${RES_LABELS[res]}</span>
      <span class="check-circle ${on ? 'on' : ''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"><path d="M5 13l4 4L19 7"/></svg></span>`;
    pill.addEventListener('click', () => {
      if (state.res.includes(res)) {
        state.res = state.res.filter((r) => r !== res);
        if (state.res.length === 0) state.res = [...RESOLUTIONS];
      } else {
        state.res.push(res);
        state.res.sort((a, b) => b - a);
      }
      renderResPills($('#resPills'));
      renderResPills($('#resPills2'));
      refreshCounts();
      markDirty();
    });
    container.appendChild(pill);
  }
}

function renderCatalogs() {
  const wrap = $('#catalogPills');
  wrap.innerHTML = '';
  for (const cat of CATALOGS) {
    const on = state.ct[cat.id];
    const pill = document.createElement('div');
    pill.className = 'source-pill ' + (on ? 'on' : 'off');
    pill.innerHTML = `
      <span class="check-circle"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"><path d="M5 13l4 4L19 7"/></svg></span>
      <span class="pill-name">${cat.name}</span>
      <span class="pill-tags"><span class="tag">catalog</span></span>`;
    pill.addEventListener('click', () => {
      state.ct[cat.id] = !state.ct[cat.id];
      pill.classList.toggle('on', state.ct[cat.id]);
      pill.classList.toggle('off', !state.ct[cat.id]);
      markDirty();
    });
    wrap.appendChild(pill);
  }
  const hint = $('#catalogHint');
  hint.textContent = window.__tmdbEnabled
    ? 'Home-page rows shown inside Stremio (TMDB-powered).'
    : 'Home-page rows shown inside Stremio. (Cinemeta fallback — set TMDB_API on the server for TMDB catalogs.)';
}

/* ---------- overview ---------- */

function renderOverview() {
  const total = allSources().length;
  const active = enabledCount();
  $('#statSources').textContent = active;
  $('#statSourcesSub').textContent = `of ${total} available`;
  $('#statQualities').textContent = state.res.length;
  const lo = RES_LABELS[Math.min(...state.res)];
  const hi = RES_LABELS[Math.max(...state.res)];
  $('#statQualitiesSub').textContent = state.res.length ? `${hi} → ${lo}` : '—';
  const catsOn = CATALOGS.filter((c) => state.ct[c.id]).length;
  $('#statCatalogs').textContent = catsOn;

  const fs = state.fs || [null, null];
  const sizeLabel = fs[0] == null && fs[1] == null ? 'Any' : `${fs[0] ?? '0'} – ${fs[1] ?? '∞'} GB`;
  const kv = [
    ['Sort mode', { quality: 'Best quality', size: 'Largest size', source: 'By source' }[state.so]],
    ['Per-source cap', state.mp > 0 ? state.mp : 'Unlimited'],
    ['Total cap', state.mt > 0 ? state.mt : 'Unlimited'],
    ['Subtitles', state.ns ? 'Off' : state.sl.map((c) => c.toUpperCase()).join(', ')],
    ['File size', sizeLabel],
    ['Non-seekable', state.sk ? 'Hidden' : 'Shown'],
    ['Direct providers', state.nd ? 'Off' : 'On'],
  ];
  $('#quickStats').innerHTML = kv
    .map(([k, v]) => `<div class="kv-line"><span>${k}</span><strong>${v}</strong></div>`)
    .join('');
  updateUrlBox();
}

/* ---------- filtering ---------- */

function renderActiveFilters() {
  const fs = state.fs || [null, null];
  const kv = [
    ['File size', fs[0] == null && fs[1] == null ? 'Any' : `${fs[0] ?? '0'} – ${fs[1] ?? '∞'} GB`],
    ['Non-seekable files', state.sk ? 'Hidden' : 'Shown'],
    ['Resolutions', state.res.map((r) => RES_LABELS[r]).join(', ') || '—'],
    ['Direct providers', state.nd ? 'Off' : 'On'],
  ];
  $('#activeFilters').innerHTML = kv
    .map(([k, v]) => `<div class="kv-line"><span>${k}</span><strong>${v}</strong></div>`)
    .join('');
}

/* ---------- playback ---------- */

function orderedSources() {
  const all = allSources().filter((s) => state.s[s.id] && !(s.kind === 'direct' && state.nd));
  const inOrd = state.ord.filter((id) => all.some((s) => s.id === id));
  const rest = all.map((s) => s.id).filter((id) => !inOrd.includes(id));
  return [...inOrd, ...rest].map((id) => all.find((s) => s.id === id));
}

function renderOrderList() {
  const list = $('#orderList');
  list.innerHTML = '';
  const items = orderedSources();

  items.forEach((src, i) => {
    const li = document.createElement('li');
    li.className = 'order-item';
    li.innerHTML = `
      <span class="idx">${i + 1}.</span>
      <span class="origin">${src.label}</span>
      <span class="order-arrows">
        <button class="arrow-btn" data-dir="-1" ${i === 0 ? 'disabled' : ''}>↑</button>
        <button class="arrow-btn" data-dir="1" ${i === items.length - 1 ? 'disabled' : ''}>↓</button>
      </span>`;
    li.querySelectorAll('.arrow-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const dir = parseInt(btn.dataset.dir, 10);
        const ids = orderedSources().map((s) => s.id);
        const j = i + dir;
        [ids[i], ids[j]] = [ids[j], ids[i]];
        state.ord = ids;
        renderOrderList();
        markDirty();
      });
    });
    list.appendChild(li);
  });
}

function renderSortSeg() {
  const wrap = $('#sortSeg');
  wrap.innerHTML = '';
  const modes = [['quality', 'Best quality'], ['size', 'Largest size'], ['source', 'By source']];
  for (const [mode, label] of modes) {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.classList.toggle('on', state.so === mode);
    btn.addEventListener('click', () => {
      state.so = mode;
      renderSortSeg();
      markDirty();
    });
    wrap.appendChild(btn);
  }
}

function renderPresets() {
  const sel = document.getElementById('presetSelect');
  if (!sel) return;
  sel.innerHTML = '';
  let matched = false;
  for (const preset of PRESETS) {
    const opt = document.createElement('option');
    opt.value = preset.name;
    opt.textContent = preset.name;
    if (state.nf === preset.nf && state.fd === preset.fd) {
      opt.selected = true;
      matched = true;
    }
    sel.appendChild(opt);
  }
  if (!matched) {
    const custom = document.createElement('option');
    custom.textContent = 'Custom';
    custom.selected = true;
    sel.appendChild(custom);
  }
}

function renderFormatterChips() {
  const wrap = $('#fmtChips');
  wrap.innerHTML = '';
  for (const token of PLACEHOLDERS) {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = token;
    chip.addEventListener('click', () => {
      state.fd = `${state.fd.trimEnd()} ${token}`.trim();
      $('#fmtDesc').value = state.fd;
      renderPresets();
      renderPreview();
      markDirty();
    });
    wrap.appendChild(chip);
  }
}

function renderSubLangs() {
  const wrap = $('#subLangs');
  wrap.innerHTML = '';
  for (const lang of SUB_LANGS) {
    const on = state.sl.includes(lang.code);
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = lang.label;
    chip.style.opacity = on ? '1' : '0.55';
    if (on) chip.style.color = 'var(--accent)';
    chip.addEventListener('click', () => {
      if (state.sl.includes(lang.code)) {
        state.sl = state.sl.filter((c) => c !== lang.code);
        if (state.sl.length === 0) state.sl = ['en'];
      } else {
        state.sl.push(lang.code);
      }
      renderSubLangs();
      markDirty();
    });
    wrap.appendChild(chip);
  }
}

/* ---------- profiles (max 2) ---------- */

// Each profile keeps its own full config state; switching swaps state and
// every view re-renders. Install URL always encodes the ACTIVE profile.
let profiles = [{ id: 'main', name: 'Main', state: null }];
let activeProfile = 'main';

function persistProfiles() {
  try {
    localStorage.setItem(
      'sp-profiles',
      JSON.stringify(profiles.map((p) => ({ id: p.id, name: p.name, state: p.state })))
    );
    localStorage.setItem('sp-active-profile', activeProfile);
  } catch {
    /* ignore */
  }
}

function loadProfiles() {
  try {
    const raw = localStorage.getItem('sp-profiles');
    if (!raw) return;
    const saved = JSON.parse(raw);
    if (Array.isArray(saved) && saved.length > 0) {
      profiles = saved.filter((p) => p && p.id && p.name).slice(0, 2);
      const active = localStorage.getItem('sp-active-profile');
      if (profiles.some((p) => p.id === active)) activeProfile = active;
    }
  } catch {
    /* ignore */
  }
}

function switchProfile(id) {
  if (id === activeProfile) return;
  const target = profiles.find((p) => p.id === id);
  if (!target) return;
  profiles.find((p) => p.id === activeProfile).state = state;
  activeProfile = id;
  state = normalize(target.state || {});
  savedUrl = manifestUrl();
  renderAll();
  persistProfiles();
  $('#profileMenu').hidden = true;
  sync();
}

function addProfile() {
  if (profiles.length >= 2) return;
  profiles.find((p) => p.id === activeProfile).state = state;
  const id = 'profile-' + Date.now().toString(36);
  profiles.push({ id, name: 'Profile ' + (profiles.length + 1), state: normalize(state) });
  activeProfile = id;
  state = normalize(profiles.find((p) => p.id === id).state);
  savedUrl = manifestUrl();
  renderAll();
  persistProfiles();
  $('#profileMenu').hidden = true;
  sync();
}

function renderProfileChip() {
  const active = profiles.find((p) => p.id === activeProfile);
  document.getElementById('profileChipName').textContent = active ? active.name : 'Main';
  const menu = document.getElementById('profileMenu');
  menu.innerHTML = '';
  for (const p of profiles) {
    const btn = document.createElement('button');
    btn.className = p.id === activeProfile ? 'on' : '';
    btn.innerHTML = '<span>' + p.name + '</span>' + (p.id === activeProfile ? '<span>✓</span>' : '');
    btn.addEventListener('click', () => switchProfile(p.id));
    menu.appendChild(btn);
  }
  if (profiles.length < 2) {
    const add = document.createElement('button');
    add.className = 'pm-new';
    add.textContent = '+ New profile';
    add.addEventListener('click', addProfile);
    menu.appendChild(add);
  }
}

function renderAll() {
  renderSources();
  renderResPills(document.getElementById('resPills'));
  renderResPills(document.getElementById('resPills2'));
  renderCatalogs();
  renderTypeChips();
  renderPresets();
  renderPreview();
  renderSubLangs();
  renderOrderList();
  renderSortSeg();
  renderActiveFilters();
  renderOverview();
  renderProfileChip();
  // sync simple controls with state
  document.getElementById('maxPer').value = state.mp;
  document.getElementById('maxTotal').value = state.mt;
  document.getElementById('noDirect').checked = state.nd;
  document.getElementById('noSubs').checked = state.ns;
  document.getElementById('seekFilter').checked = state.sk;
  document.getElementById('sizeMin').value = state.fs[0] ?? '';
  document.getElementById('sizeMax').value = state.fs[1] ?? '';

  document.getElementById('fmtName').value = state.nf;
  document.getElementById('fmtDesc').value = state.fd;
  document.getElementById('keyFebbox').value = state.k.febbox || '';
  document.getElementById('keyRd').value = state.k.rd || '';
  document.getElementById('keyTb').value = state.k.tb || '';
}

/* ---------- boot ---------- */

async function init() {
  try {
    const resp = await fetch('/api/sources');
    const json = await resp.json();
    if (Array.isArray(json.sources) && json.sources.length) {
      const byCat = new Map();
      for (const src of json.sources) {
        const cat = src.cat || 'general';
        if (!byCat.has(cat)) byCat.set(cat, []);
        byCat.get(cat).push(src);
      }
      SOURCES = [...byCat.entries()];
    }
    if (Array.isArray(json.subtitleLangs) && json.subtitleLangs.length) SUB_LANGS = json.subtitleLangs;
    if (Array.isArray(json.formatPresets) && json.formatPresets.length) PRESETS = json.formatPresets;
    if (Array.isArray(json.contentTypes) && json.contentTypes.length) window.__contentTypes = json.contentTypes;
    window.__tmdbEnabled = Boolean(json.tmdbEnabled);
    if (json.discord) {
      const d = document.getElementById('navDiscord');
      const dt = document.getElementById('discordTop');
      if (d) { d.href = json.discord; d.hidden = false; }
      if (dt) { dt.href = json.discord; dt.hidden = false; }
    }
    if (json.coffee) {
      const c = document.getElementById('navCoffee');
      if (c) { c.href = json.coffee; c.hidden = false; }
    }
  } catch { /* fallbacks */ }

  loadProfiles();
  const activeP = profiles.find((p) => p.id === activeProfile);
  if (activeP && activeP.state) {
    state = normalize(activeP.state);
  } else {
    state = readConfigFromUrl();
    profiles.find((p) => p.id === activeProfile).state = state;
  }
  savedUrl = manifestUrl();
  document.getElementById('profileChipBtn').addEventListener('click', () => {
    const menu = document.getElementById('profileMenu');
    menu.hidden = !menu.hidden;
    renderProfileChip();
  });
  document.addEventListener('click', (e) => {
    const menu = document.getElementById('profileMenu');
    if (!menu.hidden && !e.target.closest('.profile-wrap')) menu.hidden = true;
  });

  // theme
  const theme = localStorage.getItem('sp-theme') || 'dark';
  document.documentElement.dataset.theme = theme;
  $('#themeToggle').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    localStorage.setItem('sp-theme', next);
  });

  // sidebar collapse
  const sidebar = document.getElementById('sidebar');
  const setCollapsed = (v) => {
    document.body.classList.toggle('sb-collapsed', v);
    localStorage.setItem('sp-sidebar', v ? 'collapsed' : 'open');
  };
  setCollapsed(localStorage.getItem('sp-sidebar') === 'collapsed');
  $('#sidebarCollapse').addEventListener('click', () => {
    setCollapsed(!document.body.classList.contains('sb-collapsed'));
  });

  // nav
  document.querySelectorAll('.nav-item[data-view]').forEach((a) => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      location.hash = a.dataset.view;
    });
  });
  window.addEventListener('hashchange', () => showView((location.hash || '#overview').slice(1)));

  // sources
  $('#sourceFilter').addEventListener('input', () => renderSources());
  $('#allBtn').addEventListener('click', () => {
    for (const src of allSources()) state.s[src.id] = true;
    renderSources();
    markDirty();
  });
  $('#noneBtn').addEventListener('click', () => {
    for (const src of allSources()) state.s[src.id] = false;
    renderSources();
    markDirty();
  });
  $('#clearSources').addEventListener('click', () => $('#noneBtn').click());

  // resolutions / caps
  renderResPills($('#resPills'));
  renderResPills($('#resPills2'));
  $('#clearRes').addEventListener('click', () => {
    state.res = [...RESOLUTIONS];
    renderResPills($('#resPills'));
    renderResPills($('#resPills2'));
    markDirty();
  });
  $('#maxPer').value = state.mp;
  $('#maxTotal').value = state.mt;
  $('#maxPer').addEventListener('change', (e) => {
    state.mp = Math.min(Math.max(parseInt(e.target.value, 10) || 0, 0), 200);
    e.target.value = state.mp;
    markDirty();
  });
  $('#maxTotal').addEventListener('change', (e) => {
    state.mt = Math.min(Math.max(parseInt(e.target.value, 10) || 0, 0), 800);
    e.target.value = state.mt;
    markDirty();
  });
  $('#noDirect').checked = state.nd;
  $('#noDirect').addEventListener('change', (e) => {
    state.nd = e.target.checked;
    refreshCounts();
    markDirty();
  });
  renderCatalogs();
  $('#resetCatalogs').addEventListener('click', () => {
    for (const cat of CATALOGS) state.ct[cat.id] = cat.def;
    renderCatalogs();
    markDirty();
  });

  // filtering
  $('#sizeMin').value = state.fs[0] ?? '';
  $('#sizeMax').value = state.fs[1] ?? '';
  const sizeChange = () => {
    const min = parseFloat($('#sizeMin').value);
    const max = parseFloat($('#sizeMax').value);
    state.fs = [Number.isFinite(min) && min > 0 ? min : null, Number.isFinite(max) && max > 0 ? max : null];
    if (state.fs[0] != null && state.fs[1] != null && state.fs[1] <= state.fs[0]) state.fs[1] = null;
    renderActiveFilters();
    markDirty();
  };
  $('#sizeMin').addEventListener('change', sizeChange);
  $('#sizeMax').addEventListener('change', sizeChange);
  $('#seekFilter').checked = state.sk;
  $('#seekFilter').addEventListener('change', (e) => {
    state.sk = e.target.checked;
    renderActiveFilters();
    markDirty();
  });

  // playback
  $('#resetOrder').addEventListener('click', () => {
    state.ord = [];
    renderOrderList();
    markDirty();
  });
  renderSortSeg();
  renderPresets();
  renderFormatterChips();
  $('#fmtName').value = state.nf;
  $('#fmtDesc').value = state.fd;
  const fmtChange = () => {
    state.nf = $('#fmtName').value.trim() || DEFAULT_NF;
    state.fd = $('#fmtDesc').value.trim() || DEFAULT_FD;
    renderPresets();
    renderPreview();
    markDirty();
  };
  $('#fmtName').addEventListener('input', fmtChange);
  $('#fmtDesc').addEventListener('input', fmtChange);
  document.getElementById('presetSelect').addEventListener('change', (e) => {
    const p = PRESETS.find((x) => x.name === e.target.value);
    if (!p) return;
    state.nf = p.nf;
    state.fd = p.fd;
    document.getElementById('fmtName').value = state.nf;
    document.getElementById('fmtDesc').value = state.fd;
    renderPresets();
    renderPreview();
    markDirty();
  });
  $('#fmtReset').addEventListener('click', () => {
    state.nf = DEFAULT_NF;
    state.fd = DEFAULT_FD;
    $('#fmtName').value = state.nf;
    $('#fmtDesc').value = state.fd;
    renderPresets();
    renderPreview();
    markDirty();
  });
  renderSubLangs();
  $('#noSubs').checked = state.ns;
  $('#noSubs').addEventListener('change', (e) => {
    state.ns = e.target.checked;
    markDirty();
  });

  // keys
  const keyWire = (id, field) => {
    document.getElementById(id).addEventListener('change', (e) => {
      state.k[field] = e.target.value.trim().slice(0, 500) || '';
      markDirty();
    });
  };
  keyWire('keyFebbox', 'febbox');
  keyWire('keyRd', 'rd');
  keyWire('keyTb', 'tb');

  // install
  let shortUrl = null;
  const renderUrl = () => {
    const url = shortUrl || manifestUrl();
    document.getElementById('manifestUrl').value = url;
  document.getElementById('installBtn').href = 'stremio://' + url.slice(url.indexOf('//') + 2);
    document.getElementById('installBtn').dataset.url = url;
    document.getElementById('shortenBtn').textContent = shortUrl ? '✓ Short URL active' : '✂  Shorten URL';
  };
  document.getElementById('shortenBtn').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      const resp = await fetch('/api/shorten', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(state),
      });
      const json = await resp.json();
      if (json.url) {
        shortUrl = json.url;
        renderUrl();
        btn.textContent = '✓ Short URL active';
        document.getElementById('syncSub').textContent = 'short link ready';
      }
    } catch { /* keep long url */ }
    btn.disabled = false;
  });

  $('#copyBtn').addEventListener('click', async (e) => {
    const url = $('#installBtn').dataset.url || manifestUrl();
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const tmp = document.createElement('input');
      tmp.value = url;
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand('copy');
      tmp.remove();
    }
    const btn = e.currentTarget;
    btn.textContent = '✓ Copied';
    setTimeout(() => (btn.textContent = '⧉  Copy Addon URL'), 1500);
  });
  $('#clearBtn').addEventListener('click', () => {
    state = defaultConfig();
    location.hash = '#overview';
    location.reload();
  });

  renderTypeChips();
  renderSources();
  renderPreview();
  refreshCounts();
  renderOverview();
  sync();
  showView((location.hash || '#overview').slice(1));
}

init();
