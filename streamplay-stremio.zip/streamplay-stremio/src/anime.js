// Anime metadata mapping via ani.zip - IMDb ID -> AniList / MAL IDs + episode
// data. Same source StreamPlay uses (api.ani.zip/mappings?imdb_id=).
// Cached 24h; returns null for non-anime titles (ani.zip returns {} for those).
import { cached } from './cache.js';
import { getText } from './http.js';

const ANIZIP = process.env.ANIZIP_API || 'https://api.ani.zip';

// Full mapping for an imdb id (movie or series base).
export async function getAniZipMapping(imdbId) {
  if (!imdbId || !/^tt\d+$/.test(imdbId)) return null;
  return cached(`anizip:${imdbId}`, 24 * 60 * 60 * 1000, async () => {
    try {
      const resp = await getText(`${ANIZIP}/mappings?imdb_id=${imdbId}`, { timeout: 10000 });
      const json = JSON.parse(resp.body);
      if (!json || !json.anilistId) return null; // not an anime title
      return {
        anilistId: json.anilistId || null,
        malId: json.malId || null,
        tvdbId: json.tvdbId || null,
        tmdbId: json.tmdbId || null,
        type: json.type || null,
        isAnime: true,
        episodes: json.episodes || {}, // { "1": { anilistTitle,tvdbTitle,... } }
        episodeCount: json.episodeCount || null,
        title: json.title || null,
      };
    } catch {
      return null;
    }
  });
}

// Convenience: just the AniList id (or null).
export async function getAniListId(imdbId) {
  const mapping = await getAniZipMapping(imdbId);
  return mapping?.anilistId || null;
}
