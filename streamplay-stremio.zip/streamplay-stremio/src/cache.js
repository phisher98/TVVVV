// Simple in-memory TTL cache (key -> {value, expires}).

const store = new Map();

export function cacheGet(key) {
  const hit = store.get(key);
  if (!hit) return undefined;
  if (hit.expires <= Date.now()) {
    store.delete(key);
    return undefined;
  }
  return hit.value;
}

export function cacheSet(key, value, ttlMs) {
  store.set(key, { value, expires: Date.now() + ttlMs });
}

// cached('key', 300000, async () => { ... })
export async function cached(key, ttlMs, fn) {
  const hit = cacheGet(key);
  if (hit !== undefined) return hit;
  const value = await fn();
  if (value !== undefined && value !== null) cacheSet(key, value, ttlMs);
  return value;
}

// Periodic sweep so the map doesn't grow unbounded.
setInterval(() => {
  const now = Date.now();
  for (const [key, hit] of store) {
    if (hit.expires <= now) store.delete(key);
  }
}, 10 * 60 * 1000).unref();
