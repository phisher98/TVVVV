// Catalogs: TMDB-powered when TMDB_API is set (like StreamPlay's home page),
// Cinemeta proxy fallback otherwise (no key needed). Search always available.
import { cached } from './cache.js';
import { getText } from './http.js';
import { CATALOG_DEFS } from './config.js';

const CINEMETA = 'https://v3-cinemeta.strem.io';
const TMDB_API = process.env.TMDB_API || '';

const TMDB_GENRES = {
  Action: 28,
  Comedy: 35,
  Drama: 18,
  Horror: 27,
  'Sci-Fi': 878,
  Romance: 10749,
  Thriller: 53,
  Animation: 16,
  Documentary: 99,
  Family: 10751,
};

// Genres a catalog exposes; "Trending/Popular/Top Rated/New" map to endpoints.
const STANDARD_EXTRA_NAMES = ['Trending', 'Popular', 'Top Rated', 'New'];

function tmdbUrl(path, params = {}) {
  const u = new URL(`https://api.themoviedb.org/3${path}`);
  u.searchParams.set('api_key', TMDB_API);
  u.searchParams.set('language', 'en-US');
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, String(v));
  return u.toString();
}

// Resolve TMDB id -> IMDb id (cached).
async function tmdbToImdb(type, tmdbId) {
  return cached(`tmdbext:${type}:${tmdbId}`, 7 * 24 * 60 * 60 * 1000, async () => {
    try {
      const resp = await getText(tmdbUrl(`/${type}/${tmdbId}/external_ids`));
      return JSON.parse(resp.body)?.imdb_id || null;
    } catch {
      return null;
    }
  });
}

async function tmdbCatalog(catalogId, type, extraName, skip) {
  let path;
  const params = { page: Math.floor((skip || 0) / 20) + 1 };

  if (catalogId === 'streamplay-anime') {
    path = '/discover/tv';
    params.with_genres = 16;
    params.with_keywords = '210024|222243';
    params.sort_by =
      extraName === 'New Anime' ? 'first_air_date.desc' : 'popularity.desc';
  } else if (catalogId === 'streamplay-indian') {
    path = '/discover/movie';
    params.with_original_language = 'hi';
    params.sort_by = extraName === 'Trending' ? 'popularity.desc' : 'popularity.desc';
  } else if (TMDB_GENRES[extraName]) {
    // Real genre filter
    path = type === 'movie' ? '/discover/movie' : '/discover/tv';
    params.with_genres = TMDB_GENRES[extraName];
    params.sort_by = 'popularity.desc';
  } else {
    // Trending / Popular / Top Rated / New
    const base = type === 'movie' ? 'movie' : 'tv';
    switch (extraName) {
      case 'Top Rated':
        path = `/${base}/top_rated`;
        break;
      case 'New':
        path = type === 'movie' ? '/movie/now_playing' : '/tv/airing_today';
        break;
      case 'Popular':
        path = `/${base}/popular`;
        break;
      default:
        path = `/trending/${base}/day`;
    }
  }

  const results = await cached(`tmdbcat:${path}:${JSON.stringify(params)}`, 30 * 60 * 1000, async () => {
    try {
      const resp = await getText(tmdbUrl(path, params));
      const json = JSON.parse(resp.body);
      return (json.results || []).filter((r) => !r.adult);
    } catch {
      return [];
    }
  });

  const metas = [];
  for (const r of results.slice(0, 30)) {
    const imdb = await tmdbToImdb(type === 'movie' ? 'movie' : 'tv', r.id);
    if (!imdb || !/^tt\d+$/.test(imdb)) continue;
    metas.push({
      id: imdb,
      type,
      name: r.title || r.name || '',
      poster: r.poster_path ? `https://image.tmdb.org/t/p/w500${r.poster_path}` : null,
      background: r.backdrop_path ? `https://image.tmdb.org/t/p/w780${r.backdrop_path}` : null,
      description: r.overview || '',
      releaseInfo: (r.release_date || r.first_air_date || '').slice(0, 4),
      imdbRating: r.vote_average ? r.vote_average.toFixed(1) : null,
    });
  }
  return metas;
}

// Cinemeta proxy fallback (no TMDB key needed).
async function cinemetaCatalog(type, extraName, skip) {
  const STANDARD = ['Trending', 'Popular', 'Top Rated', 'New'];
  const endpoint = (() => {
    switch (extraName) {
      case 'Top Rated':
        return 'imdbRating';
      case 'New':
        return 'last-videos';
      default:
        return 'top';
    }
  })();
  // Only pass real genres to Cinemeta ("Trending"/"Popular" map to the plain top list).
  const genrePart = extraName && !STANDARD.includes(extraName) ? `/genre=${encodeURIComponent(extraName)}` : '';
  const skipPart = skip ? `${genrePart ? '&' : '/'}skip=${skip}` : '';
  const url = `${CINEMETA}/catalog/${type}/${endpoint}${genrePart || ''}${skipPart}.json`;
  return cached(`cmcat:${url}`, 30 * 60 * 1000, async () => {
    try {
      const resp = await getText(url, { timeout: 10000 });
      const metas = JSON.parse(resp.body)?.metas || [];
      return metas.map((m) => ({
        id: m.id,
        type: m.type || type,
        name: m.name,
        poster: m.poster,
        background: m.background || m.poster,
        description: m.description || '',
        releaseInfo: m.releaseInfo || '',
        imdbRating: m.imdbRating || null,
      }));
    } catch {
      return [];
    }
  });
}

// Search catalog (Cinemeta search - always available, no key).
async function searchCatalog(type, query, skip) {
  const url = `${CINEMETA}/catalog/${type}/search/query=${encodeURIComponent(query)}.json`;
  return cached(`cmsearch:${url}`, 10 * 60 * 1000, async () => {
    try {
      const resp = await getText(url, { timeout: 10000 });
      const metas = JSON.parse(resp.body)?.metas || [];
      return metas.map((m) => ({
        id: m.id,
        type: m.type || type,
        name: m.name,
        poster: m.poster,
        background: m.background || m.poster,
        description: m.description || '',
        releaseInfo: m.releaseInfo || '',
        imdbRating: m.imdbRating || null,
      }));
    } catch {
      return [];
    }
  });
}

export function hasTmdbKey() {
  return Boolean(TMDB_API);
}

// Fetch metas for one of our catalog ids.
// extraName: first segment of extras (Trending / Popular / genre...) or null.
export async function fetchCatalog(catalogId, type, extraName, skip) {
  if (TMDB_API) return tmdbCatalog(catalogId, type, extraName, skip);
  // Cinemeta fallback ignores our custom ids and serves top/popular/rating lists.
  const genre = STANDARD_EXTRA_NAMES.includes(extraName) ? extraName : 'Trending';
  return cinemetaCatalog(type, genre, skip);
}

export async function searchMetas(type, query, skip) {
  return searchCatalog(type, query, skip);
}

// Manifest catalog entries for the enabled set (+ the search catalog).
export function manifestCatalogs(config) {
  const catalogs = [];
  for (const def of CATALOG_DEFS) {
    if (!config.ct[def.id]) continue;
    catalogs.push({
      id: def.id,
      type: def.type,
      name: def.name,
      extra: [
        { name: 'genre', options: def.genres, isRequired: false },
        { name: 'skip', isRequired: false },
      ],
      extraSupported: ['genre', 'skip'],
    });
  }
  if (catalogs.length > 0 || true) {
    // Search support for both types.
    for (const type of ['movie', 'series']) {
      if (!catalogs.some((c) => c.type === type)) {
        catalogs.push({
          id: `streamplay-search-${type}`,
          type,
          name: 'StreamPlay Search',
          extra: [{ name: 'search', isRequired: true }, { name: 'skip', isRequired: false }],
          extraSupported: ['search', 'skip'],
        });
      } else {
        const cat = catalogs.find((c) => c.type === type);
        if (!cat.extra.some((e) => e.name === 'search')) {
          cat.extra.push({ name: 'search', isRequired: false });
          cat.extraSupported.push('search');
        }
      }
    }
  }
  return catalogs;
}

export { CATALOG_DEFS };
