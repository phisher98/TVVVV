// User configuration: base64url JSON carried in the URL path prefix
// (/c/<cfg>/manifest.json), Torrentio-style - stateless, no database.
//
// Schema (compact keys keep install URLs short):
// {
//   s:  { <sourceId>: boolean },    // which sources are enabled
//   res: number[],                  // allowed resolutions
//   nd: boolean,                    // disable direct providers master switch
//   nf: string,                     // stream name template (bold badge)
//   fd: string,                     // stream description template
//   so: 'quality'|'size'|'source',  // sort strategy
//   ord: string[],                  // source priority order (enabled ids)
//   mp: number, mt: number,         // per-source / total caps
//   fs: [number|null, number|null], // file size bounds in GB (null = open)
//   sk: boolean,                    // hide non-seekable direct downloads
//   ct: { <catalogId>: boolean },   // catalogs in the manifest
//   sl: string[],                   // preferred subtitle languages
//   ns: boolean                     // disable subtitles resource
//   k: { febbox, rd, tb }          // user keys (FebBox token, debrid API keys)
// }

export const SOURCE_DEFS = [
  // --- GENERAL --- (types: what content each source covers)
  { id: 'k4hdhub', label: '4KHDHub', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', 'Mainstream', 'Classics'], desc: '4KHDHub download-site scraper -> HubCloud / GDFlix / Pixeldrain' },
  { id: 'hdhub4u', label: 'HDHub4u', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Hindi'], desc: 'HDHub4u scraper (pingora search API) -> HubCloud / GDFlix' },
  { id: 'vegamovies', label: 'VegaMovies', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Regional'], desc: 'VegaMovies scraper -> V-Cloud servers' },
  { id: 'moviesdrive', label: 'MoviesDrive', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Mainstream'], desc: 'MoviesDrive scraper -> HubCloud / GDFlix servers' },
  { id: 'moviebox', label: 'MovieBox', kind: 'scraper', cat: 'general', types: ['movies', 'series', 'kdrama', 'anime'], def: true, tags: ['1080p', 'Fast', 'Multi-Audio'], desc: 'MovieBox app API: movies, series, K-drama & anime, MP4 + DASH dubs' },
  { id: '2embed', label: '2Embed', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['1080p', 'HLS', 'MP4'], desc: '2Embed / vidcore.io HLS servers' },
  { id: 'cinejoy', label: 'Cinejoy', kind: 'scraper', cat: 'general', types: ['movies', 'series', 'kdrama'], def: true, tags: ['1080p', 'HLS', 'Multi-Server'], desc: 'Cinejoy multi-server HLS (incl. Asian cinema)' },
  { id: 'vidy', label: 'Vidy', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', 'Multi-Server', '1080p'], desc: 'Vidy multi-city servers (custom keystream cipher)' },
  { id: 'vidsrc', label: 'VidSrc', kind: 'direct', cat: 'general', types: ['movies', 'series', 'anime'], def: true, tags: ['1080p', 'HLS', 'Fast'], desc: 'vidsrc.sh direct HLS (IMDb keyed, carries anime too)' },
  { id: 'vidlink', label: 'VidLink', kind: 'direct', cat: 'general', types: ['movies', 'series', 'anime'], def: true, tags: ['4K', 'HLS', 'Mainstream'], desc: 'vidlink.pro multi-quality HLS (TMDB keyed, anime via TV ids)' },
  { id: 'vidrock', label: 'VidRock', kind: 'direct', cat: 'general', types: ['movies', 'series'], def: true, tags: ['1080p', 'HLS', 'Mainstream'], desc: 'vidrock.ru AES-GCM HLS (TMDB keyed)' },
  { id: 'vidfast', label: 'VidFast', kind: 'direct', cat: 'general', types: ['movies', 'series', 'anime'], def: true, tags: ['4K', 'HLS', 'Fast'], desc: 'vidfast.vc HLS servers (TMDB keyed, anime via TV ids)' },
  { id: 'videasy', label: 'Videasy', kind: 'direct', cat: 'general', types: ['movies', 'series', 'anime'], def: true, tags: ['4K', 'Multi-Server', '1080p'], desc: 'player.videasy.to 9 servers (TMDB keyed, anime via TV ids)' },
  { id: 'vidup', label: 'VidUp', kind: 'direct', cat: 'general', types: ['movies', 'series'], def: true, tags: ['1080p', 'HLS', 'Fast'], desc: 'vidup.to HLS servers via enc-dec (TMDB keyed)' },
  { id: 'vidzee', label: 'VidZee', kind: 'direct', cat: 'general', types: ['movies', 'series', 'kdrama'], def: true, tags: ['1080p', 'Multi-Server', 'Multi-Audio'], desc: 'core.vidzee.wtf multi-server (Dcloud/Doppler/Acme/TCloud)' },
  { id: 'xpass', label: 'XPass', kind: 'direct', cat: 'general', types: ['movies', 'series'], def: true, tags: ['1080p', 'Multi-Server', 'HLS'], desc: 'play.xpass.top encrypted multi-server playlists' },
  { id: 'vadapav', label: 'Vadapav', kind: 'direct', cat: 'general', types: ['movies', 'series'], def: true, tags: ['1080p', 'Fast', 'Direct'], desc: 'stremio.vadapav.mov direct streams (IMDb keyed)' },
  { id: 'atlantic', label: 'Atlantic', kind: 'direct', cat: 'general', types: ['movies', 'series', 'anime'], def: true, tags: ['4K', 'HLS', 'Multi-Server'], desc: 'hls.lol family: 7 sub-flows incl. nesterov AES-GCM' },

  // --- REGIONAL (Indian cinema & dubbed) ---
  { id: 'bollyflix', label: 'Bollyflix', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Bollywood'], desc: 'Bollyflix scraper -> HubCloud servers (sidexfee decode)' },
  { id: 'rogmovies', label: 'RogMovies', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Regional'], desc: 'RogMovies search API -> V-Cloud / G-Direct / M4uplay' },
  { id: 'moviesmod', label: 'MoviesMod', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Dual-Audio'], desc: 'MoviesMod scraper -> hrefli bypass -> HubCloud/GDFlix' },
  { id: 'uhdmovies', label: 'UHDMovies', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['4K', '1080p', 'Remux'], desc: 'UHDMovies scraper -> Driveleech/HubCloud servers' },
  { id: 'topmovies', label: 'TopMovies', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['1080p', 'G-Drive', 'Fast'], desc: 'TopMovies scraper -> g-drive fast servers' },
  { id: 'multimovies', label: 'MultiMovies', kind: 'scraper', cat: 'regional', types: ['movies', 'series', 'anime'], def: true, tags: ['1080p', 'HLS', 'Multi-Server'], desc: 'MultiMovies server chips -> modiplay/filemoon HLS (has anime section)' },
  { id: 'movies4u', label: 'Movies4u', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['1080p', 'Mainstream', 'Fast'], desc: 'Movies4u lookup API + download pages -> HubCloud' },
  { id: 'hdmovie2', label: 'Hdmovie2', kind: 'scraper', cat: 'regional', types: ['movies', 'series', 'kdrama'], def: true, tags: ['1080p', 'MP4', 'K-Drama'], desc: 'Hdmovie2 dooplay player -> GDFlix (carries K-drama/Asian)' },
  { id: 'hindmoviez', label: 'Hindmoviez', kind: 'scraper', cat: 'regional', types: ['movies', 'series'], def: true, tags: ['1080p', 'Hindi', 'Regional'], desc: 'Hindmoviez scraper -> signed dl pages -> HubCloud/GDFlix' },
  { id: 'xdmovies', label: 'XDMovies', kind: 'scraper', cat: 'general', types: ['movies', 'series'], def: true, tags: ['4K', 'Remux', 'H265'], desc: 'XDMovies 4K/remux scraper (Firecrawl CF-bypass for pages)' },
  { id: 'kisskh', label: 'KissKH', kind: 'scraper', cat: 'general', types: ['series', 'kdrama', 'movies'], def: true, tags: ['K-Drama', '1080p', 'HLS'], desc: 'KissKH Asian dramas & movies (key-server signed HLS)' },
  { id: 'nyaa', label: 'Nyaa (Debrid)', kind: 'scraper', cat: 'general', types: ['anime'], def: false, tags: ['Anime', 'Debrid', '4K'], desc: 'Nyaa torrents resolved via Real-Debrid - needs RD key in the Keys tab (ani.zip matching)' },
  { id: 'superstream', label: 'SuperStream', kind: 'scraper', cat: 'general', types: ['movies', 'series', 'anime', 'kdrama'], def: false, tags: ['4K', 'Multi-Audio', 'Key Required'], desc: 'SuperStream app API - paste your FebBox token in the Keys tab' },
  { id: 'anikoto', label: 'AniKoto', kind: 'scraper', cat: 'general', types: ['anime'], def: true, tags: ['Anime', 'Sub & Dub', 'HLS'], desc: 'AniKoto anime (ani.zip matching, MegaPlay HLS via Firecrawl-ready flow)' },
];

export const SOURCE_CATEGORIES = [
  { id: 'general', label: 'General' },
  { id: 'regional', label: 'Regional' },
];

// Content-type taxonomy (pengu-style General / Regional / K-Drama / Anime).
// `types` drives both the UI filter chips and the per-medium source filter.
export const CONTENT_TYPES = [
  { id: 'movies', label: 'Movies' },
  { id: 'series', label: 'Series' },
  { id: 'kdrama', label: 'K-Drama' },
  { id: 'anime', label: 'Anime' },
];

export const RESOLUTIONS = [2160, 1080, 720, 480, 360];

export const RES_LABELS = { 2160: '4K', 1080: '1080p', 720: '720p', 480: '480p', 360: '360p' };

const STANDARD_CATALOG_GENRES = ['Trending', 'Popular', 'Top Rated', 'New', 'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi'];

export const CATALOG_DEFS = [
  {
    id: 'streamplay-trending-movies',
    type: 'movie',
    name: 'StreamPlay Trending Movies',
    def: true,
    genres: STANDARD_CATALOG_GENRES,
  },
  {
    id: 'streamplay-trending-series',
    type: 'series',
    name: 'StreamPlay Trending Series',
    def: true,
    genres: STANDARD_CATALOG_GENRES,
  },
  {
    id: 'streamplay-anime',
    type: 'series',
    name: 'StreamPlay Anime',
    def: false,
    genres: ['Anime', 'Popular Anime', 'New Anime'],
  },
  {
    id: 'streamplay-indian',
    type: 'movie',
    name: 'StreamPlay Indian Cinema',
    def: false,
    genres: ['Bollywood', 'Trending'],
  },
];

export const SUBTITLE_LANGS = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'Hindi' },
  { code: 'es', label: 'Spanish' },
  { code: 'fr', label: 'French' },
  { code: 'de', label: 'German' },
  { code: 'pt', label: 'Portuguese' },
  { code: 'ar', label: 'Arabic' },
  { code: 'ru', label: 'Russian' },
  { code: 'it', label: 'Italian' },
  { code: 'tr', label: 'Turkish' },
  { code: 'ja', label: 'Japanese' },
  { code: 'ko', label: 'Korean' },
  { code: 'zh', label: 'Chinese' },
  { code: 'ta', label: 'Tamil' },
  { code: 'te', label: 'Telugu' },
];

export const DEFAULT_NAME_FORMAT = '{source} • {quality}';
export const DEFAULT_DESC_FORMAT = '🎬 {title}\n📌 {source} {lang}\n💾 {size}';
export const SORT_MODES = ['quality', 'size', 'source'];

// Formatter presets shown in the Playback view. "\n" renders as a new line
// in Stremio's stream description.
export const FORMAT_PRESETS = [
  {
    name: 'StreamPlay Modern',
    nf: '{source} • {quality}',
    fd: '🎬 {title}\n📌 {source} {lang}\n💾 {size}',
  },
  { name: 'Detailed', nf: '{source} {quality}', fd: '{title} {size} {lang} {host}' },
  { name: 'Minimal', nf: '{source}', fd: '{quality}' },
  { name: 'Plex style', nf: '{quality} {source}', fd: '{title} • {size} • {lang}' },
  { name: 'Tech', nf: '{source} [{quality}]', fd: '{title} {size} {se} {host}' },
  {
    name: 'Rich Multi-line',
    nf: '{source} • {quality}',
    fd: '🎬 {title}\n🏷 {se} {year}\n🎞 {title}\n📌 {source}\n💾 {size} • {lang}\n🔗 {host}',
  },
];

export function defaultConfig() {
  const s = {};
  for (const src of SOURCE_DEFS) s[src.id] = src.def;
  const ct = {};
  for (const cat of CATALOG_DEFS) ct[cat.id] = cat.def;
  return {
    s,
    res: [...RESOLUTIONS],
    nd: false,
    nf: DEFAULT_NAME_FORMAT,
    fd: DEFAULT_DESC_FORMAT,
    so: 'quality',
    ord: [],
    mp: 0,
    mt: 0,
    fs: [null, null],
    sk: false,
    ct,
    sl: ['en'],
    ns: false,
    k: {},
  };
}

function b64urlEncode(str) {
  return Buffer.from(str, 'utf8').toString('base64url');
}

function b64urlDecode(str) {
  return Buffer.from(str, 'base64url').toString('utf8');
}

// Compact + validate an arbitrary object into a config.
export function normalizeConfig(input) {
  const base = defaultConfig();
  if (!input || typeof input !== 'object') return base;

  const out = { ...base };

  if (input.s && typeof input.s === 'object') {
    const s = {};
    for (const src of SOURCE_DEFS) {
      s[src.id] = typeof input.s[src.id] === 'boolean' ? input.s[src.id] : src.def;
    }
    out.s = s;
  }
  if (Array.isArray(input.res)) {
    const allowed = input.res.map(Number).filter((r) => RESOLUTIONS.includes(r));
    if (allowed.length > 0) out.res = [...new Set(allowed)];
  }
  if (typeof input.nd === 'boolean') out.nd = input.nd;
  if (typeof input.nf === 'string' && input.nf.trim()) out.nf = input.nf.trim().slice(0, 160);
  else if (typeof input.f === 'string' && input.f.trim()) out.fd = input.f.trim().slice(0, 160); // legacy single template
  if (typeof input.fd === 'string' && input.fd.trim()) out.fd = input.fd.trim().slice(0, 160);
  if (SORT_MODES.includes(input.so)) out.so = input.so;
  if (Array.isArray(input.ord)) {
    const known = new Set(SOURCE_DEFS.map((d) => d.id));
    out.ord = [...new Set(input.ord.filter((id) => known.has(id)))];
  }
  if (Number.isFinite(input.mp)) out.mp = Math.min(Math.max(Math.floor(input.mp), 0), 200);
  if (Number.isFinite(input.mt)) out.mt = Math.min(Math.max(Math.floor(input.mt), 0), 800);
  if (Array.isArray(input.fs) && input.fs.length === 2) {
    const min = Number.isFinite(input.fs[0]) && input.fs[0] > 0 ? input.fs[0] : null;
    const max = Number.isFinite(input.fs[1]) && input.fs[1] > 0 ? input.fs[1] : null;
    out.fs = [min, max && (!min || max > min) ? max : null];
  }
  if (typeof input.sk === 'boolean') out.sk = input.sk;
  if (input.ct && typeof input.ct === 'object') {
    const ct = {};
    for (const cat of CATALOG_DEFS) {
      ct[cat.id] = typeof input.ct[cat.id] === 'boolean' ? input.ct[cat.id] : cat.def;
    }
    out.ct = ct;
  }
  if (Array.isArray(input.sl)) {
    const codes = new Set(SUBTITLE_LANGS.map((l) => l.code));
    const sl = input.sl.filter((c) => codes.has(c));
    if (sl.length > 0) out.sl = [...new Set(sl)];
  }
  if (typeof input.ns === 'boolean') out.ns = input.ns;
  if (input.k && typeof input.k === 'object') {
    const k = {};
    if (typeof input.k.febbox === 'string') k.febbox = input.k.febbox.slice(0, 500);
    if (typeof input.k.rd === 'string') k.rd = input.k.rd.slice(0, 200);
    if (typeof input.k.tb === 'string') k.tb = input.k.tb.slice(0, 200);
    out.k = k;
  }
  return out;
}

export function encodeConfig(config) {
  return b64urlEncode(JSON.stringify(normalizeConfig(config)));
}

export function decodeConfig(str) {
  try {
    return normalizeConfig(JSON.parse(b64urlDecode(str)));
  } catch {
    return null;
  }
}

// Returns { config, rest, hadConfig } for a request path.
export function splitConfigPath(pathname) {
  let path = pathname;
  try {
    path = decodeURIComponent(pathname);
  } catch {
    /* keep raw */
  }
  const m = path.match(/^\/c\/([A-Za-z0-9\-_]+)(?=\/|$)(\/.*)?$/);
  if (m) {
    const config = decodeConfig(m[1]);
    if (config) return { config, rest: m[2] || '/', hadConfig: true };
  }
  return { config: defaultConfig(), rest: path, hadConfig: false };
}

export function buildConfigPath(config) {
  return `/c/${encodeConfig(config)}`;
}

export function isDirectSource(id) {
  const def = SOURCE_DEFS.find((s) => s.id === id);
  return def ? def.kind === 'direct' : false;
}

// Filter helper honouring the "disable direct" master switch and, when a
// content medium is known ('movies' | 'series'), skipping sources that do
// not cover it at all.
export function enabledSources(config, medium) {
  return SOURCE_DEFS.filter((def) => {
    if (!config.s[def.id]) return false;
    if (def.kind === 'direct' && config.nd) return false;
    if (medium && Array.isArray(def.types) && !def.types.includes(medium)) return false;
    return true;
  }).map((def) => def.id);
}

export function enabledCatalogs(config) {
  return CATALOG_DEFS.filter((cat) => config.ct[cat.id]);
}
