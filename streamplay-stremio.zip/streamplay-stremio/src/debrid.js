// Real-Debrid bridge - turns torrents/magnets into direct streams using the
// user's RD API key (Keys tab -> config.k.rd, or REALDEBRID_KEY env).
// Flow: /torrents/add-magnet -> /torrents/info -> pick biggest video ->
// /torrents/select-files/{id} -> /unrestrict/torrent_link.
const RD_API = 'https://api.real-debrid.com/rest/1.0';

export function rdKeyFrom(config) {
  return config?.k?.rd || process.env.REALDEBRID_KEY || '';
}

export function rdConfigured(config) {
  return Boolean(rdKeyFrom(config));
}

async function rd(path, key, { method = 'GET', body } = {}) {
  if (!key) return null;
  const resp = await fetch(RD_API + path, {
    method,
    headers: {
      authorization: `Bearer ${key}`,
      ...(body ? { 'content-type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!resp.ok) return { error: resp.status };
  return resp.json();
}

export async function rdAccount(key) {
  return rd('/user', key);
}

// Magnet -> direct download URL of the largest video file.
export async function rdResolveMagnet(magnet, key) {
  const added = await rd('/torrents/add-magnet', key, { method: 'POST', body: { magnet } });
  if (!added || added.error || !added.id) return null;

  const info = await rd(`/torrents/info/${added.id}`, key);
  if (!info || info.error) return null;

  const files = (info.files || []).filter((f) => /\.(mkv|mp4|avi|ts|m2ts|mov|flv|wmv)$/i.test(f.path));
  if (files.length === 0) return null;
  const best = files.sort((a, b) => b.bytes - a.bytes)[0];

  await rd(`/torrents/select-files/${added.id}`, key, { method: 'POST', body: { files: String(best.id) } });

  const ready = await rd(`/torrents/info/${added.id}`, key);
  const link = ready?.links?.[ready.links.length - 1];
  if (!link) return null;

  const unrestricted = await rd('/unrestrict/link', key, { method: 'POST', body: { link } });
  if (!unrestricted || unrestricted.error || !unrestricted.download) return null;
  return { url: unrestricted.download, filename: unrestricted.filename || best.path };
}

// Direct hoster-link unrestrict for RD-supported hosters.
export async function rdUnrestrictLink(url, key) {
  const unrestricted = await rd('/unrestrict/link', key, { method: 'POST', body: { link: url } });
  if (!unrestricted || unrestricted.error || !unrestricted.download) return null;
  return { url: unrestricted.download, filename: unrestricted.filename || '' };
}
