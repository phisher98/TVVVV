// Live domain resolution, same source of truth as the Cloudstream extension:
// https://raw.githubusercontent.com/phisher98/TVVVV/refs/heads/main/domains.json
// (parsed by StreamPlayParser.kt -> DomainsParser)
import { cached } from './cache.js';
import { http } from './http.js';

export const DOMAINS_URL =
  process.env.STREAMPLAY_DOMAINS_URL ||
  'https://raw.githubusercontent.com/phisher98/TVVVV/refs/heads/main/domains.json';

const FALLBACKS = {
  hubcloud: 'https://hubcloud.foo',
  moviesdrive: 'https://new4.moviesdrive.christmas',
};

export async function getDomains() {
  return cached('domains', 30 * 60 * 1000, async () => {
    try {
      const resp = await http(DOMAINS_URL, { timeout: { request: 8000 } });
      const json = JSON.parse(resp.body);
      // Trim every value like the Kotlin side does.
      for (const k of Object.keys(json)) {
        if (typeof json[k] === 'string') json[k] = json[k].trim();
      }
      return json;
    } catch (err) {
      console.warn('[domains] failed to fetch domains.json:', err.message);
      return { ...FALLBACKS };
    }
  });
}

export async function getDomain(key) {
  const domains = await getDomains();
  const value = domains?.[key];
  return value && value !== '' ? value : FALLBACKS[key] || null;
}
