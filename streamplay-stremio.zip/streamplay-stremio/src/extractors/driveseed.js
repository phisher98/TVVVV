// Driveseed / Driveleech extractor - port of Extractors.kt "open class Driveseed"
// (:1560-1736). Cloud Download, Instant Download (video-seed/leech/plex API),
// Resume Worker Bot (PHPSESSID + token POST), Direct Links (CF type=1/2), Resume Cloud.
import { getDoc, getText, postText, baseUrlOf } from '../http.js';
import { cleanTitle, indexQuality } from '../quality.js';

function fixUrl(link, base) {
  if (/^https?:/i.test(link)) return link;
  return `${base.replace(/\/$/, '')}/${link.replace(/^\//, '')}`;
}

export async function driveseed(url, originLabel, emit) {
  try {
    const baseUrl = baseUrlOf(url);
    const name = originLabel || 'Driveseed';

    let doc;
    if (url.includes('r?key=')) {
      const res = await getText(url);
      const temp =
        res.body.match(/replace\(\s*["']([^"']+)["']/)?.[1] ||
        res.body.match(/replace\("([^"]+)"\)/)?.[1] ||
        '';
      const target = fixUrl(temp.replace(/\\\//g, '/'), baseUrl);
      doc = (await getDoc(target)).doc;
    } else {
      doc = (await getDoc(url)).doc;
    }

    const qualityText = doc('li.list-group-item')
      .filter((_i, el) => doc(el).text().includes('Name'))
      .first()
      .text();
    const rawFileName = qualityText.split('Name : ').pop().trim();
    const fileName = cleanTitle(rawFileName);
    const fileSize = doc('li.list-group-item')
      .filter((_i, el) => doc(el).text().includes('Size'))
      .first()
      .text()
      .split('Size : ')
      .pop()
      .trim();
    const quality = indexQuality(fileName || rawFileName);

    const labelExtras = [fileName ? `[${fileName}]` : '', fileSize ? `[${fileSize}]` : ''].filter(Boolean).join('');

    const myCallback = (link, server = '') => {
      if (!link) return;
      emit({
        source: `${name} ${server}`.trim(),
        title: `${name} ${server} ${labelExtras}`.trim(),
        url: link,
        quality,
        kind: 'video',
      });
    };

    const jobs = [];

    doc('div.text-center > a, a.btn').each((_i, el) => {
      const text = doc(el).text() || '';
      const href = doc(el).attr('href') || '';

      if (/Cloud Download/i.test(text)) {
        myCallback(href, '[Cloud]');
      } else if (/Instant Download/i.test(text)) {
        jobs.push(
          instantLink(href)
            .then((instant) => {
              if (instant) myCallback(instant, '[Instant(Download)]');
            })
            .catch(() => {})
        );
      } else if (/Resume Worker Bot|ResumeBot/i.test(text)) {
        jobs.push(
          resumeBot(href)
            .then((resumeLink) => {
              if (resumeLink) myCallback(resumeLink, '[ResumeBot]');
            })
            .catch(() => {})
        );
      } else if (/Direct Links/i.test(text)) {
        jobs.push(
          (async () => {
            const link = fixUrl(href, baseUrl);
            for (const t of ['1', '2']) {
              try {
                const cfDoc = (await getDoc(`${link}?type=${t}`)).doc;
                cfDoc('a.btn-success').each((_j, btn) => {
                  const href2 = cfDoc(btn).attr('href');
                  if (href2 && /^https?:/i.test(href2)) myCallback(href2, '[CF]');
                });
              } catch {
                /* skip type */
              }
            }
          })()
        );
      } else if (/Resume Cloud/i.test(text)) {
        jobs.push(
          (async () => {
            try {
              const resumeCloudUrl = fixUrl(href, baseUrl);
              const resumeDoc = (await getDoc(resumeCloudUrl)).doc;
              const resume = resumeDoc('a.btn-success').first().attr('href');
              if (resume && /^https?:/i.test(resume)) myCallback(resume, '[ResumeCloud]');
            } catch {
              /* skip */
            }
          })()
        );
      }
      // gofile omitted (guest-token API).
    });

    await Promise.allSettled(jobs);
  } catch (err) {
    console.warn(`[driveseed] failed for ${url}: ${err.message}`);
  }
}

async function instantLink(finallink) {
  const noRedirect = await getText(finallink, { followRedirect: false });
  const loc = noRedirect.headers.location || '';
  const target = loc || finallink;
  const token = target.includes('?url=') ? target.split('?url=').pop() : null;

  if (token && !/^https?:/i.test(token)) {
    let host = 'video-seed.xyz';
    if (target.includes('video-leech')) host = 'video-leech.xyz';
    else if (target.includes('video-plex')) host = 'video-plex.xyz';

    try {
      const resp = await postText(`https://${host}/api`, {
        form: { keys: token },
        referer: target,
        headers: {
          'x-token': host,
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        },
      });
      const apiRes = JSON.parse(resp.body)?.url || '';
      if (apiRes) return apiRes.replace(/\\\//g, '/');
    } catch {
      /* fall through */
    }
  }
  return token || target;
}

async function resumeBot(url) {
  const resp = await getText(url);
  const ssid = parseCookie(resp.headers['set-cookie'], 'PHPSESSID') || '';
  const body = resp.body || '';
  const token = body.match(/formData\.append\('token', '([a-f0-9]+)'\)/)?.[1] || '';
  const path = body.match(/fetch\('\/download\?id=([a-zA-Z0-9/+]+)'/)?.[1] || '';
  const baseUrl = url.split('/download')[0];

  if (!token || !path) return null;

  const json = await postText(`${baseUrl}/download?id=${path}`, {
    form: { token },
    headers: {
      Accept: '*/*',
      Origin: baseUrl,
      'Sec-Fetch-Site': 'same-origin',
      Cookie: `PHPSESSID=${ssid}`,
    },
    referer: url,
  });
  const parsed = JSON.parse(json.body)?.url || '';
  return /^https?:/i.test(parsed) ? parsed : null;
}

function parseCookie(setCookieHeader, name) {
  if (!setCookieHeader) return null;
  const items = Array.isArray(setCookieHeader) ? setCookieHeader : [setCookieHeader];
  for (const item of items) {
    const m = item.match(new RegExp(`${name}=([^;]+)`));
    if (m) return m[1];
  }
  return null;
}
