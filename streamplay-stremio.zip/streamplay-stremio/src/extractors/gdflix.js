// GDFlix extractor - port of Extractors.kt "open class GDFlix" (:2136-2341).
// Index-style page: Name/Size rows + text-center buttons (FSL V2, Direct DL,
// Cloud Download, Fast Cloud, Instant DL, Pixeldrain, GD Index).
import { getDoc, getText, getNoRedirect, baseUrlOf } from '../http.js';
import { getDomain } from '../domains.js';
import { cleanTitle, indexQuality } from '../quality.js';

export async function gdflix(url, originLabel, emit) {
  try {
    let baseUrl = baseUrlOf(url);
    let newUrl = url;

    // Latest gdflix domain override (domains.json first, then SaurabhKaperwan urls.json).
    let latest = ((await getDomain('gdflix')) || '').trim().replace(/\/$/, '');
    if (!latest) {
      try {
        const resp = await getText('https://raw.githubusercontent.com/SaurabhKaperwan/Utils/refs/heads/main/urls.json', {
          timeout: 8000,
        });
        const dyn = JSON.parse(resp.body)?.gdflix;
        if (dyn) latest = dyn.trim().replace(/\/$/, '');
      } catch {
        /* keep current */
      }
    }
    if (baseUrl && latest && baseUrl !== latest) {
      newUrl = url.replace(baseUrl, latest);
      baseUrl = latest;
    }

    const headers = { Referer: `${baseUrl}/` };

    let doc = null;
    let resp = null;
    for (const candidate of [newUrl, url]) {
      for (const withHeaders of [true, false]) {
        try {
          const out = await getDoc(candidate, withHeaders ? { headers } : {});
          doc = out.doc;
          resp = out.resp;
          break;
        } catch {
          /* try next */
        }
      }
      if (doc) break;
    }
    if (!doc) return;

    const fileName = doc('ul > li.list-group-item')
      .filter((_i, el) => doc(el).text().includes('Name'))
      .first()
      .text()
      .split('Name : ')
      .pop()
      .trim();
    const fileSizeRaw = doc('ul > li.list-group-item')
      .filter((_i, el) => doc(el).text().includes('Size'))
      .first()
      .text();
    const fileSize = fileSizeRaw.split('Size : ').pop().split('|')[0].trim();
    const headerDetails = cleanTitle(fileName);
    const quality = indexQuality(fileName, 2160);

    const labelExtras = [headerDetails, fileSize ? `[${fileSize}]` : ''].filter(Boolean).join(' ');
    const ref = originLabel && !originLabel.toLowerCase().includes('gdflix') ? `${originLabel} ` : '';

    const jobs = [];

    const myCallback = (link, server = '') => {
      const cleanLink = (link || '').trim();
      if (!cleanLink) return;
      const sName = server.trim().replace(/^\[/, '').replace(/\]$/, '').trim();
      const serverTag = sName ? `[${sName}]` : '';
      const name = 'GDFlix';
      const displayName = [ref && !ref.toLowerCase().includes(name.toLowerCase()) ? ref.trim() : '', name, serverTag, labelExtras]
        .filter(Boolean)
        .join(' ');
      emit({
        source: sName ? `${ref}${name} ${sName}`.trim() : `${ref}${name}`.trim(),
        title: displayName,
        url: cleanLink,
        quality,
        kind: 'video',
      });
    };

    doc('div.text-center a').each((_i, el) => {
      const anchor = doc(el);
      const text = (anchor.text() || '').trim();
      const link = (anchor.attr('href') || '').trim();
      if (!link) return;

      if (/FSL V2/i.test(text)) {
        myCallback(link, '[FSL V2]');
      } else if (/DIRECT DL|DIRECT SERVER/i.test(text)) {
        myCallback(link, '[Direct]');
      } else if (/CLOUD DOWNLOAD/i.test(text)) {
        const r2Link =
          link.includes('url=') ? decodeURIComponent(link.split('url=').pop()) || link : link;
        myCallback(r2Link, '[Cloud]');
      } else if (/FAST CLOUD/i.test(text)) {
        jobs.push(
          (async () => {
            const fcUrl = /^https?:/i.test(link) ? link : baseUrl + link;
            let fcDoc = null;
            try {
              fcDoc = (await getDoc(fcUrl, { headers })).doc;
            } catch {
              try {
                fcDoc = (await getDoc(fcUrl)).doc;
              } catch {
                return;
              }
            }
            const dlink =
              fcDoc('a:contains(Cloud Resume Download)').first().attr('href') ||
              fcDoc('div.card-body a').first().attr('href') ||
              fcDoc('div.text-center a.btn-success').first().attr('href') ||
              fcDoc('a.btn-success').first().attr('href') ||
              '';
            if (dlink) myCallback(dlink, '[FAST CLOUD]');
          })()
        );
      } else if (/Instant DL/i.test(text)) {
        jobs.push(
          (async () => {
            try {
              const instantResp = await getNoRedirect(link, { headers });
              const loc = instantResp.headers.location || '';
              const instantLink = loc.includes('url=') ? loc.split('url=').pop() || loc : loc;
              if (instantLink) myCallback(instantLink, '[Instant Download]');
            } catch {
              /* skip */
            }
          })()
        );
      } else if (/pixeldra/i.test(link) || /pixeldra/i.test(text)) {
        const base = baseUrlOf(link);
        const finalURL = /download/i.test(link) ? link : `${base}/api/file/${link.split('/').pop()}?download`;
        myCallback(finalURL, '[Pixeldrain]');
      } else if (/GD Index/i.test(text)) {
        jobs.push(
          (async () => {
            const cfLink = /^https?:/i.test(link) ? link : baseUrl + link;
            for (const cfType of [1, 2]) {
              try {
                let cfDoc = null;
                try {
                  cfDoc = (await getDoc(`${cfLink}?type=${cfType}`, { headers })).doc;
                } catch {
                  cfDoc = (await getDoc(`${cfLink}?type=${cfType}`)).doc;
                }
                cfDoc('a.btn-success').each((_j, btn) => {
                  const source = cfDoc(btn).attr('href');
                  if (source) myCallback(source, '[CF]');
                });
              } catch {
                /* skip type */
              }
            }
          })()
        );
      }
      // GoFile branch intentionally omitted (needs guest-token API); rare on GDFlix pages.
    });

    await Promise.allSettled(jobs);
  } catch (err) {
    console.warn(`[gdflix] failed for ${url}: ${err.message}`);
  }
}
