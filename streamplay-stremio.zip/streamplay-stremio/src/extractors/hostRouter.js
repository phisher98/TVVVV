// Host router - port of StreamPlayUtils.loadSourceNameExtractor (:308),
// restricted to the hosters used by the addon's sources. Routes a resolved
// URL to the right extractor; unresolvable embed-only hosts are unpacked
// (filemoon family) or skipped - never emitted raw (Stremio can't play
// iframe embeds).
import { hubcloud } from './hubcloud.js';
import { vcloud } from './vcloud.js';
import { gdflix } from './gdflix.js';
import { driveseed } from './driveseed.js';
import { m4uplay } from './m4uplay.js';
import { qualityFromUrl } from '../quality.js';
import { getAndUnpack } from './jsunpack.js';
import { getText } from '../http.js';

const DIRECT_FILE_RE = /\.(mp4|mkv|m3u8|avi|webm|mpd)(\?|$)/i;
// Embed-only players we can unpack to an HLS stream.
const UNPACKABLE_RE = /filemoon|moonplayer|uqloads|byse|vidmoly/i;
// Known-embed players we cannot resolve server-side: skip silently.
const SKIP_RE =
  /youtube|dailymotion|streamtape|dood\.|mixdrop|mp4upload|streamsb|upstream|embtaku|awish|ztoon|heist|megacloud|hubplay|smoothpre|modiplay|oneupload|filelions|vidhide|streamwish|vidlook|kinolive|supervideo|vinovo|zplayer|luluvdo|pinkbird|catflix/i;

export async function routeExtractor(url, originLabel, emit) {
  if (!url) return;
  const u = url.toLowerCase();

  if (u.includes('gdflix') || u.includes('gdlink')) return gdflix(url, originLabel, emit);
  if (u.includes('hubcloud')) return hubcloud(url, originLabel, emit);
  if (u.includes('hubdrive')) return hubcloud(url, originLabel, emit); // same layout family
  if (u.includes('m4uplay')) return m4uplay(url, originLabel, emit);
  if (u.includes('vcloud') || u.includes('cloud.unblockedgames')) return vcloud(url, originLabel, emit);
  if (u.includes('driveseed') || u.includes('driveleech')) return driveseed(url, originLabel, emit);

  if (u.includes('pixeldrain')) {
    const base = new URL(url).origin;
    const fileId = url.split('/').pop().split('?')[0];
    const finalUrl = u.includes('download') ? url : `${base}/api/file/${fileId}?download`;
    emit({
      source: `${originLabel} [Pixeldrain]`.trim(),
      title: `${originLabel} [Pixeldrain]`.trim(),
      url: finalUrl,
      quality: qualityFromUrl(url),
      kind: 'video',
    });
    return;
  }

  // Direct media files pass through.
  if (DIRECT_FILE_RE.test(url)) {
    emit({
      source: originLabel,
      title: originLabel,
      url,
      quality: qualityFromUrl(url),
      kind: /\.m3u8/i.test(url) ? 'm3u8' : /\.mpd/i.test(url) ? 'dash' : 'video',
    });
    return;
  }

  // filemoon-family embeds: try unpacking to the raw HLS.
  if (UNPACKABLE_RE.test(u)) {
    try {
      const resp = await getText(url, { referer: url });
      const unpacked = getAndUnpack(resp.body || '');
      const m3u8 =
        unpacked?.match(/https?:\/\/[^\s'"<>]+\.m3u8[^\s'"<>]*/)?.[0] ||
        (resp.body || '').match(/https?:\/\/[^\s'"<>]+\.m3u8[^\s'"<>]*/)?.[0];
      if (m3u8) {
        emit({
          source: originLabel,
          title: `${originLabel} [HLS]`,
          url: m3u8,
          quality: null,
          kind: 'm3u8',
          referer: new URL(url).origin,
        });
      }
    } catch {
      /* skip */
    }
    return;
  }

  // Anything else that looks like an embed page: skip silently instead of
  // emitting a link Stremio cannot play.
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    if (SKIP_RE.test(host) || !DIRECT_FILE_RE.test(url)) {
      console.log(`[router] skipping unresolvable: ${host}`);
      return;
    }
  } catch {
    /* not a URL at all - skip */
  }
}
