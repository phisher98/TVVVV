// Link-protector bypass - port of StreamPlayUtils.bypassHrefli (Utils:88-225).
// Handles href.li / driveseed / unblockedgames-style intermediate pages:
// cookie jar + _lp/_wp form POST chains + lp_go tokens + ?go= tokens +
// meta-refresh / location.replace destinations.
import { loadDoc, getText, postText, getNoRedirect, baseUrlOf, USER_AGENT } from '../http.js';

const HREFLI_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

export async function bypassHrefli(url) {
  const host = baseUrlOf(url);
  const jar = new Map();
  let currentUrl = url;

  const absorbHeaders = (headers) => {
    const setCookies = headers['set-cookie'];
    if (!setCookies) return;
    const items = Array.isArray(setCookies) ? setCookies : [setCookies];
    for (const setCookie of items) {
      const kv = setCookie.split(';')[0].trim();
      const eqIdx = kv.indexOf('=');
      if (eqIdx <= 0) continue;
      const k = kv.slice(0, eqIdx).trim();
      const v = kv.slice(eqIdx + 1).trim();
      if (v.toLowerCase() === 'deleted' || v === '') jar.delete(k);
      else jar.set(k, v);
    }
  };

  const cookieHeader = () => [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');

  async function fetchManual(fetchUrl, { isPost = false, postData = null, referer } = {}) {
    let nextUrl = fetchUrl;
    let usePost = isPost;
    let lastRes = null;
    for (let i = 0; i < 10; i++) {
      const hdrs = { 'User-Agent': HREFLI_UA };
      if (referer) hdrs.Referer = referer;
      const ck = cookieHeader();
      if (ck) hdrs.Cookie = ck;

      let res;
      try {
        if (usePost && postData) {
          res = await postText(nextUrl, { form: postData, headers: hdrs, followRedirect: false });
        } else {
          res = await getNoRedirect(nextUrl, { headers: hdrs });
        }
      } catch {
        break;
      }
      absorbHeaders(res.headers);
      lastRes = res;

      const code = res.statusCode || 0;
      if (code < 300 || code > 399) break;
      const location = res.headers.location;
      if (!location) break;
      nextUrl = fixUrl(location, baseUrlOf(nextUrl));
      usePost = false;
    }
    return lastRes;
  }

  try {
    const initialRes = await fetchManual(currentUrl);
    if (!initialRes) return null;
    let doc = loadDoc(initialRes.body || '');
    let res = initialRes;

    const findForm = ($doc) =>
      $doc('form')
        .toArray()
        .find((f) =>
          $doc(f)
            .find('input')
            .toArray()
            .some((input) => {
              const name = $doc(input).attr('name') || '';
              return name.startsWith('_lp') || name.startsWith('_wp');
            })
        );

    let form = findForm(doc);
    let count = 0;
    let lastFormData = {};

    while (form && count < 5) {
      const action = doc(form).attr('action') || currentUrl;
      const formUrl = fixUrl(action, host);
      const formData = {};
      doc(form)
        .find('input')
        .each((_i, el) => {
          formData[doc(el).attr('name')] = doc(el).attr('value') || '';
        });
      if (Object.keys(formData).length === 0) break;
      lastFormData = formData;

      const postRes = await fetchManual(formUrl, { isPost: true, postData: formData, referer: currentUrl });
      if (!postRes) return null;
      currentUrl = formUrl;
      res = postRes;
      doc = loadDoc(postRes.body || '');
      form = findForm(doc);
      count++;
    }

    const docText = res.body || '';

    // lp_go token path
    const lpToken = docText.match(/lp_go=(lp-[a-zA-Z0-9]+)/)?.[1];
    if (lpToken) {
      const cookieVal = docText.match(
        new RegExp(`sc\\(\\s*["']${lpToken.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["']\\s*,\\s*["']([^"']+)["']`)
      )?.[1];
      if (cookieVal) {
        const cleanVal = cookieVal.replace(/\\\//g, '/').replace(/ /g, '+').trim();
        jar.set(lpToken, cleanVal);
        const targetUrl = `${host}/?lp_go=${lpToken}`;
        const targetRes = await fetchManual(targetUrl, { referer: currentUrl });
        if (!targetRes) return null;
        const targetBody = targetRes.body || '';

        const destination =
          targetBody.match(/replace\(\s*["']([^"']+)["']\s*\)/)?.[1] ||
          targetBody.match(/replace\(\s*["']([^"']+)["']/)?.[1] ||
          loadDoc(targetBody)('meta[http-equiv=refresh]').attr('content')?.split('url=').pop() ||
          targetBody.match(/window\.location(?:\.href)?\s*=\s*["']([^"']+)["']/)?.[1] ||
          targetBody.match(/location\.href\s*=\s*["']([^"']+)["']/)?.[1] ||
          targetRes.headers.location ||
          '';

        if (destination) {
          const cleaned = destination.replace(/\\\//g, '/').trim();
          if (cleaned !== '/404') {
            const base = baseUrlOf(targetRes.url || targetUrl);
            return fixUrl(cleaned, base);
          }
        }
        if (targetRes.url && targetRes.url !== targetUrl && !targetRes.url.includes('lp_go=')) {
          return targetRes.url;
        }
      }
    }

    // ?go= token path
    const skToken = (() => {
      const scripts = doc('script')
        .toArray()
        .map((el) => doc(el).html() || '');
      for (const text of scripts) {
        const idx = text.indexOf('?go=');
        if (idx >= 0) {
          const rest = text.slice(idx + 4);
          return rest.split('"')[0].split("'")[0];
        }
      }
      return null;
    })();
    if (skToken) {
      const wpHttp = lastFormData._wp_http2 || '';
      if (wpHttp) jar.set(skToken, wpHttp);
      const driveRes = await fetchManual(`${host}?go=${skToken}`, { referer: currentUrl });
      if (!driveRes) return null;
      const driveDoc = loadDoc(driveRes.body || '');
      const driveUrl =
        driveDoc('meta[http-equiv=refresh]').attr('content')?.split('url=').pop() || driveRes.url || '';
      if (!driveUrl) return null;
      const page = (await getText(driveUrl)).body || '';
      const path = page.match(/replace\("([^"]+)"/)?.[1] || '';
      const cleaned = path.replace(/\\\//g, '/');
      if (cleaned === '/404') return null;
      return fixUrl(cleaned, baseUrlOf(driveUrl));
    }

    // Direct replace / meta-refresh destination
    const directDest =
      docText.match(/replace\(\s*["']([^"']+)["']/)?.[1] ||
      doc('meta[http-equiv=refresh]').attr('content')?.split('url=').pop() ||
      '';
    if (directDest) {
      const cleaned = directDest.replace(/\\\//g, '/').trim();
      if (
        cleaned !== '/404' &&
        !cleaned.includes('{') &&
        !cleaned.includes('}') &&
        (cleaned.startsWith('http') || cleaned.startsWith('/'))
      ) {
        return fixUrl(cleaned, host);
      }
    }

    return null;
  } catch {
    return null;
  }
}

export function fixUrl(link, base) {
  if (/^https?:/i.test(link)) return link;
  return `${(base || '').replace(/\/$/, '')}/${link.replace(/^\//, '')}`;
}
