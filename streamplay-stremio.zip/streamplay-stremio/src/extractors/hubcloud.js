// HubCloud extractor - port of Extractors.kt "open class HubCloud" (:1213-1504).
// Resolves hubcloud.php pages to direct file links across all server variants
// (FSL/FSLv2, Instant, BuzzServer/fuckingfast, Pixeldrain, S3, Mega, PDL, 10Gbps, Watch Online).
import { getDoc, getText, getNoRedirect, baseUrlOf } from '../http.js';
import { getDomain } from '../domains.js';
import { cleanTitle, indexQuality } from '../quality.js';
import { routeExtractor } from './hostRouter.js';

const BLOCKED = ['tinyurl', 'telegram', 'hubcloud.cx/tg', 'hubcloud.foo/tg'];

const DESKTOP_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
  'Sec-Ch-Ua-Platform': '"Windows"',
  'Sec-Ch-Ua-Mobile': '?0',
};

async function resolveFinalUrl(link) {
  try {
    const resp = await getText(link, { followRedirect: true });
    return resp.url || link;
  } catch {
    return null;
  }
}

// Resolve `document.getElementById("x").href = Y` inside inline scripts.
function resolveScriptHref(elementId, html) {
  const escaped = elementId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = html.match(
    new RegExp(`document\\.getElementById\\(["']${escaped}["']\\)\\.href\\s*=\\s*([^;]+)`)
  );
  if (!match) return null;
  const target = match[1].trim().replace(/^["']+|["']+$/g, '');
  if (target.startsWith('http')) return target;
  const varMatch = html.match(
    new RegExp(`(?:var|let|const)?\\s*${target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*=\\s*["']([^"']+)["']`)
  );
  return varMatch && varMatch[1].startsWith('http') ? varMatch[1] : null;
}

export async function hubcloud(url, originLabel, emit) {
  try {
    let baseUrl = baseUrlOf(url);
    let realUrl = url;

    const latestDomain = (await getDomain('hubcloud')) || '';
    if (latestDomain && baseUrl && baseUrl.toLowerCase() !== latestDomain.toLowerCase()) {
      realUrl = url.replace(baseUrl, latestDomain);
      baseUrl = latestDomain;
    }

    // Find the hubcloud.php hop when given an intermediate page.
    let href = realUrl;
    if (!realUrl.includes('hubcloud.php')) {
      try {
        const { doc } = await getDoc(realUrl);
        const raw = doc("a[href*='hubcloud.php']").first().attr('href') || '';
        if (raw) {
          href = /^https?:/i.test(raw) ? raw : `${baseUrl.replace(/\/$/, '')}/${raw.replace(/^\//, '')}`;
        }
      } catch {
        /* fall through with realUrl */
      }
    }
    if (!href) return;

    const { doc, resp } = await getDoc(href);
    const html = resp.body || '';

    const size = doc('i#size').first().text() || '';
    const cleanSize = size.split('|')[0].trim();
    const header = doc('div.card-header').first().text() || '';
    const headerDetails = cleanTitle(header);
    const quality = indexQuality(header, 2160);

    const labelExtras = [headerDetails, cleanSize ? `[${cleanSize}]` : ''].filter(Boolean).join(' ');

    const ref = originLabel && !originLabel.toLowerCase().includes('hubcloud') ? `${originLabel} ` : '';
    const prefix = `${ref}HubCloud`.trim();

    const jobs = [];

    doc('a.btn').each((_i, el) => {
      try {
        const elementId = doc(el).attr('id') || '';
        let link = doc(el).attr('href') || '';
        if (elementId) {
          const resolved = resolveScriptHref(elementId, html);
          if (resolved) link = resolved;
        }
        if (!link || BLOCKED.some((b) => link.includes(b))) return;

        const text = (doc(el).text() || '').trim();
        const label = text.toLowerCase();
        const withExtras = (s) => [s, labelExtras].filter(Boolean).join(' ');

        if (label.includes('fslv2')) {
          const isR2 = /r2\.cloudflarestorage\.com/i.test(link);
          const name = isR2 ? `${prefix} [FSLv2 (Cloudflare R2)]` : `${prefix} [FSLv2]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (label.includes('fsl server') || (label.includes('fsl') && !label.includes('v2'))) {
          const isR2 = /r2\.cloudflarestorage\.com/i.test(link);
          const name = isR2 ? `${prefix} [FSL Server (Cloudflare R2)]` : `${prefix} [FSL Server]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (label.includes('download file') || label.includes('instant download') || label.includes('instant')) {
          const name = `${prefix} [Instant Download]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (
          label.includes('buzzserver') ||
          label.includes('buzz server') ||
          label.includes('buzz') ||
          label.includes('fuckingfast')
        ) {
          jobs.push(resolveBuzz(link, prefix, quality, labelExtras, emit));
        } else if (
          label.includes('pixeldra') ||
          label.includes('pixelserver') ||
          label.includes('pixel server') ||
          label.includes('pixeldrain')
        ) {
          let pLink = link;
          if (pLink.toLowerCase().includes('negn6f') || (!pLink.includes('/u/') && !pLink.includes('/api/'))) {
            const pxlMatch =
              html.match(/(?:var|let|const)?\s*pxl\w*\s*=\s*["']([^"']+)["']/) ||
              [...html.matchAll(/https?:\/\/pixeldrain\.[a-z]+\/u\/([a-zA-Z0-9]+)/g)]
                .map((m) => m[0])
                .find((u) => !u.toLowerCase().includes('negn6f'));
            if (pxlMatch) pLink = pxlMatch;
          }
          const base = baseUrlOf(pLink) || 'https://pixeldrain.dev';
          const fileId = pLink.split('/').pop().split('?')[0];
          const finalUrl = pLink.toLowerCase().includes('download') ? pLink : `${base}/api/file/${fileId}?download`;
          const name = `${prefix} [Pixeldrain]`;
          emit({ source: name, title: withExtras(name), url: finalUrl, quality, kind: 'video' });
        } else if (label.includes('s3 server')) {
          const isR2 = /r2\.cloudflarestorage\.com/i.test(link);
          const name = isR2 ? `${prefix} [S3 Server (Cloudflare R2)]` : `${prefix} [S3 Server]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (label.includes('mega server')) {
          const name = `${prefix} [Mega Server]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (label.includes('pdl server')) {
          const name = `${prefix} [PDL Server]`;
          emit({ source: name, title: withExtras(name), url: link, quality, kind: 'video' });
        } else if (label.includes('10gbps')) {
          jobs.push(
            resolveFinalUrl(link).then((redirectUrl) => {
              if (!redirectUrl) return;
              const target = redirectUrl.includes('link=') ? redirectUrl.split('link=').pop() : redirectUrl;
              const name = `${prefix} 10Gbps [Download]`;
              emit({ source: name, title: withExtras(name), url: target, quality, kind: 'video' });
            })
          );
        } else if (label.includes('watch online') || link.includes('hbplay')) {
          let streamUrl = link;
          if (link.includes('u=')) {
            const uParam = link.split('u=').pop().split('&')[0];
            try {
              streamUrl = Buffer.from(uParam, 'base64').toString('utf8');
            } catch {
              streamUrl = link;
            }
          }
          if (streamUrl) {
            const name = `${prefix} [Watch Online]`;
            emit({ source: name, title: withExtras(name), url: streamUrl, quality, kind: 'video' });
          }
        } else {
          // Unknown button: try routing it through the generic host router.
          jobs.push(routeExtractor(link, prefix, emit));
        }
      } catch (err) {
        console.warn(`[hubcloud] button error: ${err.message}`);
      }
    });

    await Promise.allSettled(jobs);
  } catch (err) {
    console.warn(`[hubcloud] failed for ${url}: ${err.message}`);
  }
}

// BuzzServer / FuckingFast: hx-get download endpoint + HX-Redirect header.
async function resolveBuzz(link, prefix, quality, labelExtras, emit) {
  try {
    let dlPath = null;
    try {
      const { doc: dlDoc, resp: dlResp } = await getDoc(link, { headers: DESKTOP_HEADERS });
      dlPath =
        dlDoc("a[hx-get*='download']").first().attr('hx-get') ||
        (dlResp.body || '').match(/copyDownloadLink\(['"]([^'"]+)['"]\)/)?.[1]?.replace(/\\\//g, '/') ||
        null;
    } catch {
      dlPath = null;
    }

    const dlUrl = dlPath
      ? /^https?:/i.test(dlPath)
        ? dlPath
        : `${baseUrlOf(link).replace(/\/$/, '')}/${dlPath.replace(/^\//, '')}`
      : link.endsWith('/download')
        ? link
        : `${link}/download`;

    const resp = await getNoRedirect(dlUrl, {
      headers: { ...DESKTOP_HEADERS, Referer: link, 'HX-Request': 'true' },
    });
    const dlink = resp.headers['hx-redirect'] || resp.headers['hx-redirect'.toLowerCase()] || resp.headers.location || '';

    if (dlink) {
      emit({
        source: `${prefix} [BuzzServer]`,
        title: [`${prefix} [BuzzServer]`, labelExtras].filter(Boolean).join(' '),
        url: dlink,
        quality,
        kind: 'video',
      });
    }
  } catch (err) {
    console.warn(`[hubcloud] buzz: ${err.message}`);
  }
}
