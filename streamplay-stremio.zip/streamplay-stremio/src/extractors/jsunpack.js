// JavascriptUnpacker port (p,a,c,k,e,d eval unpacking) used by
// uqloads/filemoon-family players. Port of cloudstream JsUnpacker / getAndUnpack.

function unpack(source) {
  const matches = source
    .match(/}\s*\('(.*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*)'\.split\('\|'\)/);
  if (!matches) return null;

  let payload = matches[1].replace(/\\'/g, "'").replace(/\\"/g, '"').replace(/\\\\/g, '\\');
  const radixRaw = matches[2];
  const count = parseInt(matches[3], 10);
  const keys = matches[4].split('|');

  let radix = parseInt(radixRaw, 10);
  if (isNaN(radix) || radix < 2 || radix > 36) radix = 36;

  const unbase = (str) => {
    let result = 0;
    for (let i = 0; i < str.length; i++) {
      result = result * radix + parseInt(str[i], radix);
    }
    return result;
  };

  let replaced = payload;
  for (let i = count - 1; i >= 0; i--) {
    const key = keys[i] !== undefined ? keys[i] : i.toString(radix);
    const token = i.toString(radix);
    const regex = new RegExp(`\\b${token}\\b`, 'g');
    replaced = replaced.replace(regex, key);
  }

  // The unpacked body usually still needs eval'ing; return as-is and let
  // callers regex whatever they need out of it.
  return replaced;
}

export function getPacked(html) {
  const m = html.match(/eval\(function\(p,a,c,k,e,[dr]\)\{.*?\}\(.*\)\)/s);
  return m ? m[0] : null;
}

export function getAndUnpack(html) {
  const packed = getPacked(html);
  if (!packed) return null;
  return unpack(packed);
}

export { unpack };
