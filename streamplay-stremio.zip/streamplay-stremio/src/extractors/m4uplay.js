// M4uplay mini-extractor - port of "open class M4uplay" (Extractors.kt:122-230).
// Packed-JS player page: unpack, grab the iframe/embed m3u8 and subtitle tracks.
import { getDoc, getText } from '../http.js';
import { getAndUnpack, getPacked } from './jsunpack.js';

export async function m4uplay(url, originLabel, emit) {
  try {
    const pageHeaders = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      Referer: url,
    };
    const resp = await getText(url, { headers: pageHeaders });
    const html = resp.body || '';

    const packed = getPacked(html);
    const unpacked =
      (packed ? getAndUnpack(packed) : null) ||
      (html.includes('eval(function(p,a,c,k,e,d)') ? getAndUnpack(html) : null) ||
      html;

    // Main stream: m3u8 inside the unpacked payload or an iframe hop.
    let m3u8 =
      unpacked.match(/file:\s*["']([^"']+\.m3u8[^"']*)["']/)?.[1] ||
      unpacked.match(/(https?:\/\/[^\s'"<>]+\.m3u8[^\s'"<>]*)/)?.[1] ||
      '';

    if (!m3u8) {
      // Some variants hide the stream behind an iframe - try one hop.
      try {
        const iframeSrc = getDoc(html)('iframe').first().attr('src');
        if (iframeSrc && /^https?:/i.test(iframeSrc)) {
          const inner = (await getText(iframeSrc, {
            headers: { ...pageHeaders, Referer: url },
          })).body;
          const innerUnpacked = getAndUnpack(inner) || inner;
          m3u8 =
            innerUnpacked.match(/file:\s*["']([^"']+\.m3u8[^"']*)["']/)?.[1] ||
            innerUnpacked.match(/(https?:\/\/[^\s'"<>]+\.m3u8[^\s'"<>]*)/)?.[1] ||
            '';
        }
      } catch {
        /* no iframe hop */
      }
    }

    if (!m3u8) return;

    const quality = m3u8.match(/(\d{3,4})[pP]/)?.[1];
    emit({
      source: `${originLabel} M4uplay`.trim(),
      title: `${originLabel} M4uplay`.trim(),
      url: m3u8,
      quality: quality ? parseInt(quality, 10) : null,
      kind: 'm3u8',
      referer: url,
      headers: pageHeaders,
    });
  } catch (err) {
    console.warn(`[m4uplay] failed for ${url}: ${err.message}`);
  }
}
