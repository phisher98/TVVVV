// Port of StreamPlayUtils.extractMdrive (StreamPlayUtils.kt:1027).
// MoviesDrive pages: resolves the search-recover.php listing or scrapes
// hubcloud/gdflix links out of the given page.
import { getDoc, getText } from '../http.js';

export async function extractMdrive(url) {
  if (!url) return [];

  const hostRe = /hubcloud|gdflix|gdlink/i;

  // HubCloud search-recover.php listing
  if (/search-recover\.php/i.test(url)) {
    try {
      const page = await getText(url, { timeout: 15000 });
      const qInitial = page.body.match(/const\s+Q_INITIAL\s*=\s*["']([^"']+)["']/)?.[1];
      const fromAc = page.body.match(/const\s+FROM_AC_TOKEN\s*=\s*["']([^"']+)["']/)?.[1];

      if (qInitial && fromAc) {
        const base = url.split('/drive/')[0];
        const apiUrl = `${base}/drive/search-recover.php?api=search&q=${encodeURIComponent(qInitial)}&page=1&from_ac=${encodeURIComponent(fromAc)}`;
        const res = await getText(apiUrl, {
          headers: { Accept: 'application/json', Referer: url },
          timeout: 15000,
        });
        const hits = JSON.parse(res.body)?.hits;
        if (Array.isArray(hits) && hits.length > 0) {
          return hits.map((h) => h?.url).filter((u) => u && u !== '');
        }
      }
      return [];
    } catch (err) {
      console.warn(`[mdrive] search-recover: ${err.message}`);
      return [];
    }
  }

  // Already a direct drive/file link on hubcloud or gdflix
  if (hostRe.test(url) && (url.includes('/drive/') || url.includes('/file/'))) {
    return [url];
  }

  // Scrape matching links out of the page
  try {
    const doc = (await getDoc(url, { timeout: 15000 })).doc;
    const out = [];
    doc('a[href]').each((_i, el) => {
      const href = doc(el).attr('href') || '';
      if (hostRe.test(href)) out.push(href);
    });
    return out;
  } catch (err) {
    console.warn(`[mdrive] failed: ${err.message}`);
    return [];
  }
}
