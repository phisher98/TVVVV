// Port of StreamPlayUtils.getRedirectLinks (StreamPlayUtils.kt:1889) +
// hdhubpen ROT13 (:1921). Used by the 4KHDHub flow to peel the obfuscated
// WordPress redirect pages down to the real hoster link.
import { getText } from '../http.js';

const REDIRECT_RE = /s\('o','([A-Za-z0-9+/=]+)'|ck\('_wp_http_\d+','([^']+)'/g;

function rot13(value) {
  return value.replace(/[a-zA-Z]/g, (c) => {
    const base = c <= 'Z' ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
  });
}

const b64d = (s) => Buffer.from(s, 'base64').toString('utf8');

export async function getRedirectLinks(url) {
  try {
    const resp = await getText(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });
    const doc = resp.body || '';

    let combined = '';
    for (const match of doc.matchAll(REDIRECT_RE)) {
      const value = match[1] || match[2] || '';
      if (value) combined += value;
    }

    const decodedJson = b64d(rot13(b64d(b64d(combined))));
    const json = JSON.parse(decodedJson);

    const encodedUrl = b64d(json.o || '').trim();
    const data = b64d(json.data || '').trim();
    const wphttp1 = (json.blog_url || '').trim();

    let directLink = '';
    try {
      const resp2 = await getText(`${wphttp1}?re=${data}`.trim());
      directLink = resp2.body.trim();
    } catch {
      directLink = '';
    }

    return encodedUrl || directLink || url;
  } catch {
    return url;
  }
}
