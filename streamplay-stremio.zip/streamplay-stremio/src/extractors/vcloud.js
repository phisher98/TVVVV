// V-Cloud extractor - port of Extractors.kt "class VCloud" (:427-650).
// VegaMovies' host: double-atob URL hiding, then the same server-variant
// buttons as HubCloud (FSL, BuzzServer, Pixeldrain, PDL, 10Gbps, S3, Mega).
import { getDoc, getText, getNoRedirect, baseUrlOf } from '../http.js';
import { cleanTitle, indexQuality } from '../quality.js';
import { routeExtractor } from './hostRouter.js';

const DESKTOP_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
  'Sec-Ch-Ua-Platform': '"Windows"',
  'Sec-Ch-Ua-Mobile': '?0',
};

function resolveScriptHref(elementId, html) {
  const escaped = elementId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = html.match(
    new RegExp(`document\\.getElementById\\(["']${escaped}["']\\)\\.href\\s*=\\s*([^;]+)`)
  );
  if (!match) return null;
  const target = match[1].trim().replace(/^["']+|["']+$/g, '');
  if (target.startsWith('http')) return target;
  const varMatch = html.match(
    new RegExp(`(?:var|let|const)?\\s*${target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*=\\s*["']([^"']+)["']`)
  );
  return varMatch && varMatch[1].startsWith('http') ? varMatch[1] : null;
}

async function resolveFinalUrl(link) {
  try {
    const resp = await getText(link, { followRedirect: true });
    return resp.url || link;
  } catch {
    return null;
  }
}

export async function vcloud(url, originLabel, emit) {
  try {
    let href = url;

    if (href.includes('api/index.php')) {
      try {
        const { doc } = await getDoc(url);
        href = doc('div.main h4 a').first().attr('href') || '';
      } catch {
        return;
      }
      if (!href) return;
    }

    const { doc: page, resp: pageResp } = await getDoc(href);
    const scriptTag =
      page('script')
        .toArray()
        .map((el) => page(el).html() || '')
        .find((s) => s.includes('url')) || '';

    let urlValue = '';
    const doubleB64 = scriptTag.match(/atob\(atob\('([^']+)'\)\)/);
    if (doubleB64) {
      try {
        urlValue = Buffer.from(Buffer.from(doubleB64[1], 'base64').toString('utf8'), 'base64').toString('utf8');
      } catch {
        urlValue = '';
      }
    }
    if (!urlValue) {
      urlValue = scriptTag.match(/var\s+url\s*=\s*'([^']*)'/)?.[1] || '';
    }
    if (!urlValue) return;

    const { doc, resp: docResp } = await getDoc(urlValue);
    const html = docResp.body || '';
    const size = doc('i#size').first().text() || '';
    const header = doc('div.card-header').first().text() || '';
    const headerDetails = cleanTitle(header);
    const quality = indexQuality(header);

    const labelExtras = [headerDetails, size ? `[${size}]` : ''].filter(Boolean).join(' ');
    const ref = originLabel && !originLabel.toLowerCase().includes('v-cloud') ? `${originLabel} ` : '';

    const jobs = [];
    const prefix = `${ref}V-Cloud`.trim();

    doc('div.card-body h2 a.btn, div.card-body a.btn').each((_i, el) => {
      try {
        const elementId = doc(el).attr('id') || '';
        let link = doc(el).attr('href') || '';
        if (elementId) {
          const resolved = resolveScriptHref(elementId, html);
          if (resolved) link = resolved;
        }
        if (!link) return;

        const text = (doc(el).text() || '').trim();
        const withExtras = (s) => [s, labelExtras].filter(Boolean).join(' ');

        if (/FSLv2/i.test(text)) {
          emit({ source: `${ref}FSLv2`.trim(), title: withExtras(`${ref}FSLv2`.trim()), url: link, quality, kind: 'video' });
        } else if (/FSL/i.test(text)) {
          emit({ source: `${ref}FSL Server`.trim(), title: withExtras(`${ref}FSL Server`.trim()), url: link, quality, kind: 'video' });
        } else if (/BuzzServer|Buzz Server|fuckingfast/i.test(text)) {
          jobs.push(resolveBuzz(link, prefix, quality, labelExtras, emit));
        } else if (/pixeldra|pixel|PixeLServer/i.test(text)) {
          let pLink = link;
          if (pLink.toLowerCase().includes('negn6f') || (!pLink.includes('/u/') && !pLink.includes('/api/'))) {
            const pxlMatch =
              html.match(/(?:var|let|const)?\s*pxl\w*\s*=\s*["']([^"']+)["']/) ||
              [...html.matchAll(/https?:\/\/pixeldrain\.[a-z]+\/u\/([a-zA-Z0-9]+)/g)]
                .map((m) => m[0])
                .find((u) => !u.toLowerCase().includes('negn6f'));
            if (pxlMatch) pLink = pxlMatch;
          }
          const base = baseUrlOf(pLink) || 'https://pixeldrain.dev';
          const fileId = pLink.split('/').pop().split('?')[0];
          const finalUrl = /download/i.test(pLink) ? pLink : `${base}/api/file/${fileId}?download`;
          emit({ source: `${ref}Pixeldrain`.trim(), title: withExtras(`${ref}Pixeldrain`.trim()), url: finalUrl, quality, kind: 'video' });
        } else if (/PDL Server/i.test(text)) {
          emit({ source: `${ref}PDL Server`.trim(), title: withExtras(`${ref}PDL Server`.trim()), url: link, quality, kind: 'video' });
        } else if (/10Gbps/i.test(text)) {
          jobs.push(
            resolveFinalUrl(link).then((redirectUrl) => {
              if (!redirectUrl) return;
              const target = redirectUrl.includes('link=') ? redirectUrl.split('link=').pop() : redirectUrl;
              emit({
                source: `${ref}10Gbps [Download]`.trim(),
                title: withExtras(`${ref}10Gbps [Download]`.trim()),
                url: target,
                quality,
                kind: 'video',
              });
            })
          );
        } else if (/S3 Server/i.test(text)) {
          emit({ source: `${ref}S3 Server`.trim(), title: withExtras(`${ref}S3 Server`.trim()), url: link, quality, kind: 'video' });
        } else if (/Mega Server/i.test(text)) {
          emit({ source: `${ref}Mega Server`.trim(), title: withExtras(`${ref}Mega Server`.trim()), url: link, quality, kind: 'video' });
        } else {
          jobs.push(routeExtractor(link, prefix, emit));
        }
      } catch (err) {
        console.warn(`[vcloud] button error: ${err.message}`);
      }
    });

    await Promise.allSettled(jobs);
  } catch (err) {
    console.warn(`[vcloud] failed for ${url}: ${err.message}`);
  }
}

async function resolveBuzz(link, prefix, quality, labelExtras, emit) {
  try {
    let dlPath = null;
    try {
      const { doc: dlDoc, resp: dlResp } = await getDoc(link, { headers: DESKTOP_HEADERS });
      dlPath =
        dlDoc("a[hx-get*='download']").first().attr('hx-get') ||
        (dlResp.body || '').match(/copyDownloadLink\(['"]([^'"]+)['"]\)/)?.[1]?.replace(/\\\//g, '/') ||
        null;
    } catch {
      dlPath = null;
    }

    const dlUrl = dlPath
      ? /^https?:/i.test(dlPath)
        ? dlPath
        : `${baseUrlOf(link).replace(/\/$/, '')}/${dlPath.replace(/^\//, '')}`
      : link.endsWith('/download')
        ? link
        : `${link}/download`;

    const resp = await getNoRedirect(dlUrl, {
      headers: { ...DESKTOP_HEADERS, Referer: link, 'HX-Request': 'true' },
    });
    const dlink = resp.headers['hx-redirect'] || resp.headers.location || '';
    if (dlink) {
      emit({
        source: `${prefix} [BuzzServer]`,
        title: [`${prefix} [BuzzServer]`, labelExtras].filter(Boolean).join(' '),
        url: dlink,
        quality,
        kind: 'video',
      });
    }
  } catch (err) {
    console.warn(`[vcloud] buzz: ${err.message}`);
  }
}
