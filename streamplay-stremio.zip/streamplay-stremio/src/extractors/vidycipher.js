// Vidy cipher module - shared by the Vidy and Videasy sources.
// Port of StreamPlayExtractor.kt :2621-2796 (custom uint32 keystream, magic "mvm1").
import { getText, USER_AGENT } from '../http.js';

export const VIDY_MAGIC = Buffer.from([109, 118, 109, 49]); // "mvm1"

const u32 = (x) => x >>> 0;
// Kotlin UInt ops wrap mod 2^32; Math.imul is the only JS multiply that does.
const mul32 = (a, b) => Math.imul(a, b) >>> 0;

function vidyRot(e, t) {
  const s = t & 31;
  if (s === 0) return u32(e);
  return u32((e << s) | (e >>> (32 - s)));
}

function vidyL(e) {
  let v = u32(e);
  v = u32(v ^ (v >>> 16));
  v = mul32(v, 0x85ebca6b);
  v = u32(v ^ (v >>> 13));
  v = mul32(v, 0xc2b2ae35);
  return u32(v ^ (v >>> 16));
}

function vidyFnv1a(str) {
  let t = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    t = mul32(u32(t ^ str.charCodeAt(i)), 0x1000193);
  }
  return vidyL(t);
}

function vidyInitState(seed, tmdbId) {
  const s = new Uint32Array(61);
  const isSet = new Array(61).fill(false);
  // Kotlin: vidyL(vidyFnv1a(seed) xor vidyL(tmdbId xor 0x9e3779b9)) - note the inner vidyL.
  let r = vidyL(u32(vidyFnv1a(seed) ^ vidyL(u32(tmdbId ^ 0x9e3779b9))));
  for (let e = 0; e < 8; e++) {
    const t = r % 61;
    r = vidyRot(u32(r + 0x9e3779b9), 7 + (7 & e));
    s[t] = u32(r ^ vidyL(r));
    isSet[t] = true;
    r = vidyL(u32(r + t));
  }
  return { s, isSet, acc: vidyL(u32(0xa5a5a5a5 ^ r)) };
}

function vidyNextWord(state, t) {
  const r = state.s;
  const n = state.acc;
  const i = n % 61;
  const oVal = state.isSet[i] ? 0xffffffff : 0;
  const d = state.isSet[i] ? r[i] : 0;
  const c = mul32(u32(t + 1), 0x9e3779b9);
  const sVal = u32(d ^ c);
  const h = u32((n ^ sVal) | (n & sVal & oVal));
  const term1 = vidyRot(u32(h + n), 31 & i);
  const term2 = vidyRot(n, 31 & (i * 7));
  const n2 = vidyL(u32((term1 ^ term2) + 0x9e3779b9));
  r[i] = n2;
  state.isSet[i] = true;
  state.acc = n2;
  return n2;
}

function vidyKeystream(seed, tmdbId, len) {
  const st = vidyInitState(seed, tmdbId);
  const out = Buffer.alloc(len);
  let wi = 0;
  let bi = 0;
  while (bi < len) {
    const w = vidyNextWord(st, wi++);
    for (const shift of [0, 8, 16, 24]) {
      if (bi >= len) break;
      out[bi++] = (w >>> shift) & 0xff;
    }
  }
  return out;
}

export function decryptVidy(cipherB64, seed, tmdbId) {
  let bytes;
  try {
    bytes = Buffer.from(cipherB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
  } catch {
    return null;
  }
  if (bytes.length <= VIDY_MAGIC.length) return null;
  const ks = vidyKeystream(seed, tmdbId, bytes.length);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = bytes[i] ^ ks[i];
  }
  for (let k = 0; k < VIDY_MAGIC.length; k++) {
    if (bytes[k] !== VIDY_MAGIC[k]) return null;
  }
  return bytes.toString('utf8', VIDY_MAGIC.length);
}

// Shared seed fetch + quality mapping used by Vidy and Videasy.
export function qualityOf(qualityStr) {
  const s = qualityStr || '';
  if (/4K|2160/i.test(s)) return 2160;
  if (/1080/.test(s)) return 1080;
  if (/720/.test(s)) return 720;
  if (/480/.test(s)) return 480;
  if (/360/.test(s)) return 360;
  const m = s.match(/(\d{3,4})p/);
  return m ? parseInt(m[1], 10) : null;
}

export async function fetchSeed(api, mediaId, headers) {
  try {
    const resp = await getText(`${api}/seed?mediaId=${mediaId}`, { headers, timeout: 10000 });
    if (resp.statusCode >= 400) return null;
    return JSON.parse(resp.body)?.seed?.toString() || null;
  } catch {
    return null;
  }
}

export const VIDY_HEADERS = {
  'User-Agent': USER_AGENT,
  Referer: 'https://www.vidy.st/',
  Origin: 'https://www.vidy.st',
};

// Headers for the vidy.st site itself (server discovery).
export const VIDY_BASE_HEADERS = {
  'User-Agent': USER_AGENT,
};
