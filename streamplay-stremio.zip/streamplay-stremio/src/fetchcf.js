// Cloudflare-bypass fetcher using the Firecrawl playground trick
// (tools/firecrawl_fetch.py): mints a reCAPTCHA token in a real Chromium and
// fetches the target's rawHtml through Firecrawl's preview API, which clears
// CF challenges server-side. Tested against m1.multimovies.courses (118 KB
// HTML returned, challenge gone).
//
// Serialized (one python run at a time), 30-min per-URL cache, graceful null
// on any failure. Disable with CF_SOLVER=off; override interpreter with
// CF_PYTHON (defaults to "python").
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as cheerio from 'cheerio';
import { cacheGet, cacheSet } from './cache.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PY = process.env.CF_PYTHON || 'python';
const SCRIPT = path.join(__dirname, '..', 'tools', 'firecrawl_fetch.py');
export const cfEnabled = process.env.CF_SOLVER !== 'off';

let chain = Promise.resolve(); // simple mutex: one chromium run at a time

// Resolves a cheerio doc, or null on any failure / CF_SOLVER=off.
export function getDocCF(url, { timeoutMs = 100000 } = {}) {
  const key = `cfc:${url}`;
  const hit = cacheGet(key);
  if (hit) return Promise.resolve(hit);
  if (!cfEnabled) return Promise.resolve(null);

  const run = chain
    .catch(() => {})
    .then(
      () =>
        new Promise((resolve) => {
          const out = path.join(os.tmpdir(), `cf-${Date.now()}-${Math.random().toString(36).slice(2)}.json`);
          let done = false;
          const finish = (value) => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            try {
              fs.unlinkSync(out);
            } catch {
              /* ignore */
            }
            resolve(value);
          };
          const timer = setTimeout(() => {
            try {
              proc.kill();
            } catch {
              /* ignore */
            }
            finish(null);
          }, timeoutMs);

          console.log(`[cf] firecrawl fetching: ${url}`);
          const proc = spawn(PY, [SCRIPT, url, out], { windowsHide: true });
          let stderrBuf = '';
          proc.stderr.on('data', (d) => (stderrBuf += d));
          proc.stdout.on('data', () => {});
          proc.on('error', (err) => {
            console.warn(`[cf] spawn error: ${err.message}`);
            finish(null);
          });
          proc.on('close', (code) => {
            try {
              const j = JSON.parse(fs.readFileSync(out, 'utf8'));
              const html = j?.data?.rawHtml || '';
              if (j.success && html) {
                const doc = cheerio.load(html);
                cacheSet(key, doc, 30 * 60 * 1000);
                console.log(`[cf] ok: ${html.length} bytes`);
                finish(doc);
              } else {
                console.warn(`[cf] failed (code ${code}): ${(j?.error || stderrBuf || 'unknown').slice(0, 120)}`);
                finish(null);
              }
            } catch (e) {
              console.warn(`[cf] no result file (code ${code}): ${stderrBuf.slice(-120) || e.message}`);
              finish(null);
            }
          });
        })
    );
  chain = run;
  return run;
}

// True when the html looks like a Cloudflare interstitial.
export function isCfChallenge(html) {
  return /just a moment|cf-browser-verification|checking your browser|challenge-platform/i.test(html || '');
}
