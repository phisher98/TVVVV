// Stream title formatter - the "Formatter" feature. Users define a template
// with placeholders; each stream title is rendered from it.
//
// Supported placeholders:
//   {source}   -> source + server label, e.g. "4KHDHub HubCloud [FSLv2]"
//   {quality}  -> 4K / 1080p / 720p ... (empty when unknown)
//   {size}     -> file size parsed from the release label, e.g. "2.3GB"
//   {title}    -> release tag string, e.g. "UHD BLURAY HEVC DDP5.1"
//   {se}       -> S01E02 (series only)
//   {year}     -> release year (when known)
//   {lang}     -> audio language hint if present in the source label
//   {host}     -> hoster keyword detected from the URL
import { qualityLabel } from './quality.js';

export const PLACEHOLDERS = [
  { token: '{source}', desc: 'source + server label' },
  { token: '{quality}', desc: '4K / 1080p ...' },
  { token: '{size}', desc: 'file size' },
  { token: '{title}', desc: 'release tags' },
  { token: '{se}', desc: 'S01E02' },
  { token: '{year}', desc: 'year' },
  { token: '{lang}', desc: 'audio language' },
  { token: '{host}', desc: 'hoster' },
];

export function parseSize(title) {
  if (!title) return null;
  const m = title.match(/\[\s*([\d.]+)\s*(GB|MB|KB)\s*\]/i);
  if (m) return `${m[1]}${m[2].toUpperCase()}`;
  const m2 = title.match(/([\d.]+)\s*(GB|MB)(?![a-z])/i);
  if (m2) return `${m2[1]}${m2[2].toUpperCase()}`;
  return null;
}

export function sizeToBytes(size) {
  if (!size) return 0;
  const m = size.match(/([\d.]+)\s*(GB|MB|KB)/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  const unit = m[2].toUpperCase();
  if (unit === 'GB') return n * 1024 ** 3;
  if (unit === 'MB') return n * 1024 ** 2;
  return n * 1024;
}

function hostFromUrl(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

function langFromSource(source) {
  const m = (source || '').match(/\((Hindi|Tamil|Telugu|Malayalam|Kannada|Bengali|Punjabi|English|Original|ptbr)\s+Audio\)/i);
  return m ? m[1] : '';
}

// Render the user template for one link. Returns {title, size, sizeBytes}.
export function formatLink(link, template, ctx = {}) {
  const size = link.size || parseSize(link.title) || '';
  const quality = link.quality ? qualityLabel(link.quality) : '';
  const titleTags = link.tags || '';

  const replacements = {
    '{source}': link.source || '',
    '{quality}': quality,
    '{size}': size,
    '{title}': titleTags,
    '{se}': ctx.season != null ? `S${String(ctx.season).padStart(2, '0')}E${String(ctx.episode ?? 0).padStart(2, '0')}` : '',
    '{year}': ctx.year ? String(ctx.year) : '',
    '{lang}': langFromSource(link.source),
    '{host}': hostFromUrl(link.url),
  };

  let out = template;
  for (const [token, value] of Object.entries(replacements)) {
    out = out.split(token).join(value);
  }
  // Collapse horizontal whitespace per line but PRESERVE newlines - Stremio
  // renders multi-line stream descriptions.
  out = out
    .split('\n')
    .map((l) => l.replace(/[ \t]+/g, ' ').trim())
    .filter((l) => l !== '')
    .join('\n');
  if (!out) out = link.source || link.title || 'Stream';

  return { title: out, size, sizeBytes: sizeToBytes(size) };
}
