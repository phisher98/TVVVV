// HTTP helpers around got with browser-ish defaults.
import got from 'got';
import * as cheerio from 'cheerio';

export const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

export const http = got.extend({
  headers: {
    'user-agent': USER_AGENT,
    'accept-language': 'en-US,en;q=0.9',
  },
  timeout: { request: 15000 },
  retry: { limit: 1, methods: ['GET'], statusCodes: [408, 429, 500, 502, 503, 504] },
  followRedirect: true,
  throwHttpErrors: false, // Kotlin-style: inspect statusCode instead of catching
  decompress: true,
  https: { rejectUnauthorized: false },
});

export function loadDoc(html) {
  return cheerio.load(html);
}

export async function getText(url, { headers = {}, referer, timeout, followRedirect = true } = {}) {
  const resp = await http(url, {
    headers: referer ? { referer, ...headers } : headers,
    timeout: timeout ? { request: timeout } : undefined,
    followRedirect,
  });
  return resp;
}

export async function getDoc(url, opts = {}) {
  const resp = await getText(url, opts);
  return { doc: loadDoc(resp.body), resp };
}

export async function postText(url, { headers = {}, body, form, json, referer, followRedirect = true } = {}) {
  const resp = await http.post(url, {
    headers: referer ? { referer, ...headers } : headers,
    body,
    form,
    json,
    followRedirect,
  });
  return resp;
}

// No-redirect GET returning headers (used for HX-Redirect / Location tricks).
export async function getNoRedirect(url, { headers = {}, referer } = {}) {
  const resp = await http(url, {
    headers: referer ? { referer, ...headers } : headers,
    followRedirect: false,
  });
  return resp;
}

export function baseUrlOf(url) {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}`;
  } catch {
    return '';
  }
}

export function encUrl(s) {
  return encodeURIComponent(s).replace(/%20/g, '%20');
}
