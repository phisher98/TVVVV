// Internal stream-link helpers: shape emitted by sources/extractors,
// formatter application, filtering (resolution / size / seekability),
// priority ordering, limits, conversion to Stremio streams.
import { formatLink, sizeToBytes, parseSize } from './formatter.js';
import { qualityLabel } from './quality.js';

// Internal link shape:
// { source: "4KHDHub HubCloud", title: "... [2.1GB]", url, quality: 1080|null,
//   kind: 'video' | 'm3u8' | 'dash', headers?: {}, referer?: string }

export function makeCollector() {
  const links = [];
  const seen = new Set();
  return {
    links,
    emit(link) {
      if (!link || !link.url || !/^https?:\/\//i.test(link.url)) return;
      if (link.url.startsWith('magnet:')) return;
      const key = link.url.split('?')[0];
      if (seen.has(key)) return;
      seen.add(key);
      links.push(link);
    },
  };
}

export function filterByResolution(links, allowedRes) {
  if (!Array.isArray(allowedRes) || allowedRes.length === 0) return links;
  const set = new Set(allowedRes);
  // Links with unknown quality always pass.
  return links.filter((l) => !l.quality || set.has(l.quality));
}

// Keep streams between min/max GB (parsed from the release label); unknown
// sizes always pass.
export function filterBySize(links, fs) {
  if (!Array.isArray(fs)) return links;
  const [minGB, maxGB] = fs;
  if (minGB == null && maxGB == null) return links;
  const min = minGB != null ? minGB * 1024 ** 3 : null;
  const max = maxGB != null ? maxGB * 1024 ** 3 : null;
  return links.filter((l) => {
    const bytes = sizeToBytes(parseSize(l.title) || l.size || '');
    if (!bytes) return true; // unknown size passes
    if (min != null && bytes < min) return false;
    if (max != null && bytes > max) return false;
    return true;
  });
}

// Approximate pengu's "non-seekable files" filter: drop direct-download
// style files (instant download / direct server / 10gbps hops) that usually
// can't seek in Stremio's player. HLS/DASH stay untouched.
export function filterSeekable(links, hideNonSeekable) {
  if (!hideNonSeekable) return links;
  const NON_SEEKABLE = /\[Instant( Download)?\]|\[Direct\]|10Gbps \[Download\]|\[Pixeldrain\]|\[Instant\(/i;
  return links.filter(
    (l) => l.kind === 'm3u8' || l.kind === 'dash' || !NON_SEEKABLE.test(`${l.source} ${l.title}`)
  );
}

function withSizeBytes(link) {
  return { ...link, sizeBytes: sizeToBytes(parseSize(link.title) || link.size || '') };
}

// Origin = first word of the source label ("4KHDHub HubCloud" -> "4KHDHub").
function originOf(link) {
  return (link.source || '').split(' ')[0].toLowerCase();
}

export function sortLinks(links, mode = 'quality', ord = []) {
  const prepared = links.map(withSizeBytes);
  const ordIndex = new Map((ord || []).map((id, i) => [id.toLowerCase(), i]));
  const FALLBACK = 1000;
  const byOrd = (a, b) =>
    (ordIndex.get(originOf(a)) ?? FALLBACK) - (ordIndex.get(originOf(b)) ?? FALLBACK);
  const byQuality = (a, b) => (b.quality || 0) - (a.quality || 0);
  const bySize = (a, b) => b.sizeBytes - a.sizeBytes;
  const comparators = {
    quality: (a, b) => byOrd(a, b) || byQuality(a, b) || bySize(a, b),
    size: (a, b) => byOrd(a, b) || bySize(a, b) || byQuality(a, b),
    source: (a, b) => byOrd(a, b) || (a.source || '').localeCompare(b.source || '') || byQuality(a, b),
  };
  const cmp = comparators[mode] || comparators.quality;
  return prepared.sort(cmp);
}

// Enforce per-source caps (keyed by origin) before the global cap.
export function capPerSource(links, maxPer) {
  if (!maxPer) return links;
  const counts = new Map();
  return links.filter((l) => {
    const key = originOf(l);
    const n = counts.get(key) || 0;
    if (n >= maxPer) return false;
    counts.set(key, n + 1);
    return true;
  });
}

export function toStremio(link, config, ctx = {}) {
  const nf = config?.nf || '{source}';
  const fd = config?.fd || config?.f || '{quality} {size} {title}';

  const name = formatLink(link, nf, ctx).title;
  const desc = formatLink(link, fd, ctx).title;
  const qLabel = qualityLabel(link.quality);

  const behaviorHints = { notWebReady: true };
  const headers = {};
  if (link.referer) headers.Referer = link.referer;
  if (link.headers) Object.assign(headers, link.headers);
  if (Object.keys(headers).length > 0) {
    behaviorHints.proxyHeaders = { request: headers };
  }

  const titleParts = [desc, !/\{quality\}/i.test(fd) && !/\{quality\}/i.test(nf) ? qLabel : ''].filter(Boolean);
  return {
    name: (name || 'StreamPlay').slice(0, 40),
    title: titleParts.join(' '),
    url: link.url,
    behaviorHints,
  };
}
