// Stremio manifest builder - resources and catalogs reflect the user config.
import { enabledCatalogs } from './config.js';
import { manifestCatalogs } from './catalogs.js';

export const ADDON_ID = 'community.phisher98.streamplay';
export const ADDON_VERSION = '1.3.0';

export function buildManifest(baseUrl, config) {
  const catalogs = manifestCatalogs(config);
  const resources = [{ name: 'stream', types: ['movie', 'series'], idPrefixes: ['tt'] }];
  if (!config.ns) {
    resources.push({ name: 'subtitles', types: ['movie', 'series'], idPrefixes: ['tt'] });
  }

  return {
    id: ADDON_ID,
    version: ADDON_VERSION,
    name: 'StreamPlay',
    description:
      'Multi-source streams ported from the StreamPlay Cloudstream extension: ' +
      '4KHDHub, HDHub4u, VegaMovies, MoviesDrive, MovieBox, 2Embed, Cinejoy, Vidy + direct providers. ' +
      'Configurable sources, stream title formatter, catalogs and subtitles.',
    logo: `${baseUrl}/logo.jpg`,
    background: `${baseUrl}/logo.jpg`,
    resources,
    types: ['movie', 'series'],
    catalogs,
    idPrefixes: ['tt'],
    behaviorHints: {
      configurable: true,
      configurationRequired: false,
      adult: false,
    },
    contactEmail: 'phisher98@users.noreply.github.com',
  };
}
