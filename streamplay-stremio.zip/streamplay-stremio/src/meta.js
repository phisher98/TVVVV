// Metadata via Cinemeta, with a TMDB fallback. Cinemeta's live host
// occasionally returns wrong data for some IDs (observed: tt6323592 resolved
// to a completely unrelated title), which poisons every title-searching
// source. When Cinemeta looks wrong and TMDB_API is set, we re-resolve via
// TMDB find-by-imdb (source of truth) and also grab the TMDB id there.
import { cached } from './cache.js';
import { getText } from './http.js';

const CINEMETA_HOSTS = ['https://v3-cinemeta.strem.io', 'https://cinemeta-live.strem.io'];
const TMDB_API = process.env.TMDB_API || '';

async function fromCinemeta(type, imdbId) {
  for (const host of CINEMETA_HOSTS) {
    try {
      const resp = await getText(`${host}/meta/${type}/${imdbId}.json`, { timeout: 8000 });
      const meta = JSON.parse(resp.body)?.meta;
      if (meta && (meta.name || meta.title)) {
        return {
          name: meta.name || meta.title || '',
          year: typeof meta.year === 'number' ? meta.year : parseInt(meta.year, 10) || null,
          imdbId: meta.imdb_id || imdbId,
          tmdbId: meta.moviedb_id ? parseInt(meta.moviedb_id, 10) : null,
        };
      }
    } catch {
      /* next host */
    }
  }
  return null;
}

async function fromTmdb(type, imdbId) {
  if (!TMDB_API) return null;
  const tType = type === 'series' ? 'tv' : 'movie';
  try {
    const resp = await getText(
      `https://api.themoviedb.org/3/find/${imdbId}?external_source=imdb_id&api_key=${TMDB_API}`,
      { timeout: 8000 }
    );
    const json = JSON.parse(resp.body);
    const r = json?.[tType === 'tv' ? 'tv_results' : 'movie_results']?.[0];
    if (!r) return null;
    return {
      name: r.title || r.name || '',
      year: parseInt((r.release_date || r.first_air_date || ''), 10) || null,
      imdbId,
      tmdbId: r.id || null,
    };
  } catch {
    return null;
  }
}

export async function getMeta(type, imdbId) {
  if (!imdbId || !/^tt\d+$/.test(imdbId)) return null;
  return cached(`meta:${type}:${imdbId}`, 60 * 60 * 1000, async () => {
    const cinemeta = await fromCinemeta(type, imdbId);
    if (cinemeta && cinemeta.name) {
      // Cinemeta sanity: absurd future year or missing name -> distrust.
      const saneYear = !cinemeta.year || (cinemeta.year >= 1900 && cinemeta.year <= new Date().getFullYear() + 2);
      if (saneYear) return { ...cinemeta, tmdbId: cinemeta.tmdbId || null };
    }
    const tmdb = await fromTmdb(type, imdbId);
    return tmdb || cinemeta || null;
  });
}
