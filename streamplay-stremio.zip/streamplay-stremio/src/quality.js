// Quality parsing + the "cleanTitle" tag extractor, ported from
// StreamPlay Extractors.kt (extractCleanTitle / extractIndexQuality).

const TITLE_EXTENSION_RE = /\.[a-zA-Z0-9]{2,4}$/;

const TITLE_PATTERNS = [
  /(WEB[- ]?DL|WEB[- ]?RIP|WEBDL|WEBRIP|BLURAY|BDRIP|BRRIP|REMUX|HDRIP|DVDRIP|HDTV|UHD|CAM|TS|TC)/i,
  /(H[ .]?264|H[ .]?265|X264|X265|HEVC|AVC|AV1|VP9|XVID)/i,
  /(DDP?[ .]?[0-9]\.[0-9]|DD[ .]?[0-9]\.[0-9]|AAC[ .]?[0-9]\.[0-9]|AC3|DTS[- ]?HD|DTS|EAC3|TRUEHD|ATMOS|FLAC|MP3|OPUS)/i,
  /(HDR10\+?|HDR|DV|DOLBY[ .]?VISION)/i,
  /\b(NF|AMZN|DSNP|HULU|CRAV|ATVP|HMAX|PCOK|STAN)\b/i,
  /\b(REPACK|PROPER|REAL|EXTENDED|UNCUT|REMASTERED|LIMITED|MULTI|DUAL)\b/i,
];

const normalizeRes = (value) =>
  value
    .replace(/WEB[-_. ]?DL/gi, 'WEB-DL')
    .replace(/WEB[-_. ]?RIP/gi, 'WEBRIP')
    .replace(/H[ .]?265/gi, 'H265')
    .replace(/H[ .]?264/gi, 'H264')
    .replace(/DOLBY[ .]?VISION/gi, 'DOLBYVISION')
    .replace(/2160P/i, '4K');

// "Movie.2023.2160p.WEB-DL.DDP5.1.H.265" -> "2160P WEB-DL H265 DDP5.1" style tag string
export function cleanTitle(title) {
  if (!title) return '';
  const name = title.replace(TITLE_EXTENSION_RE, '');
  const results = new Set();
  for (const pattern of TITLE_PATTERNS) {
    for (const match of name.matchAll(new RegExp(pattern.source, 'gi'))) {
      results.add(normalizeRes(match[0].toUpperCase()));
    }
  }
  return [...results].join(' ');
}

// extractIndexQuality: "Movie.2023.1080p..." -> 1080 ; "4K" -> 2160 ; "8K" -> 4320
export function indexQuality(str, fallback = null) {
  const s = str || '';
  const m = s.match(/(\d{3,4})[pP]/);
  if (m) {
    const v = parseInt(m[1], 10);
    if (Number.isFinite(v)) return v;
  }
  const lower = s.toLowerCase();
  if (lower.includes('8k')) return 4320;
  if (lower.includes('4k')) return 2160;
  if (lower.includes('2k')) return 1440;
  return fallback;
}

// Guess quality from a plain URL when nothing else is available.
export function qualityFromUrl(url) {
  return indexQuality(url);
}

export function qualityLabel(quality) {
  if (!quality) return '';
  if (quality >= 4320) return '8K';
  if (quality >= 2160) return '4K';
  return `${quality}p`;
}
