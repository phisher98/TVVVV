// StreamPlay Stremio addon server.
//
// Config is carried statelessly in the URL path prefix:
//   /c/<base64url-config>/manifest.json
//   /c/<base64url-config>/stream/movie/tt123.json
//   /c/<base64url-config>/catalog/movie/streamplay-trending-movies/genre=Action.json
//   /c/<base64url-config>/subtitles/series/tt0944947:1:1.json
// Plain paths use default config.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';

import { splitConfigPath, enabledSources, SOURCE_DEFS, SOURCE_CATEGORIES, CONTENT_TYPES, SUBTITLE_LANGS, FORMAT_PRESETS, DEFAULT_NAME_FORMAT, DEFAULT_DESC_FORMAT, SORT_MODES, CATALOG_DEFS, RES_LABELS } from './config.js';
import { buildManifest } from './manifest.js';
import { getMeta } from './meta.js';
import { SOURCES } from './sources/index.js';
import { makeCollector, filterByResolution, filterBySize, filterSeekable, sortLinks, capPerSource, toStremio } from './links.js';
import { fetchCatalog, searchMetas } from './catalogs.js';
import { shorten, lookup } from './store.js';
import { rdResolveMagnet, rdKeyFrom } from './debrid.js';
import { normalizeConfig } from './config.js';
import { getSubtitles } from './subtitles.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// --- minimal .env loader (no dependency) --------------------------------
(function loadDotEnv() {
  const envPath = path.join(__dirname, '..', '.env');
  try {
    if (fs.existsSync(envPath)) {
      for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
        const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
        if (!m || line.trim().startsWith('#')) continue;
        const value = m[2].replace(/^["']|["']$/g, '');
        if (!(m[1] in process.env)) process.env[m[1]] = value;
      }
    }
  } catch {
    /* ignore */
  }
})();

const PORT = parseInt(process.env.PORT || '7000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const SOURCE_TIMEOUT_MS = parseInt(process.env.SOURCE_TIMEOUT_MS || '20000', 10);
const MAX_STREAMS = parseInt(process.env.MAX_STREAMS || '120', 10);

const app = express();
app.disable('x-powered-by');

// Never let a stray error take the whole addon down (VPS resilience).
process.on('uncaughtException', (err) => console.error('[uncaught]', err));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));

// Stremio (web + desktop) refuses addons without permissive CORS headers.
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// --- config-prefix middleware -----------------------------------------

app.use((req, _res, next) => {
  const { config, rest, hadConfig } = splitConfigPath(req.path);
  req.streamplayConfig = config;
  req.hadConfig = hadConfig;
  req.url = rest + (req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '');
  next();
});

function baseUrlOfReq(req) {
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

// --- short URLs (/s/<id>/...) ------------------------------------------

app.use((req, _res, next) => {
  if (req.path.startsWith('/s/')) {
    const rest0 = req.path.slice(3);
    const slash = rest0.indexOf('/');
    const id = slash >= 0 ? rest0.slice(0, slash) : rest0;
    const rest = slash >= 0 ? rest0.slice(slash) : '/';
    if (/^[A-Za-z0-9_-]+$/.test(id)) {
      const stored = lookup(id);
      if (stored) {
        req.streamplayConfig = stored;
        req.hadConfig = true;
        req.url = rest + (req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '');
      }
    }
  }
  next();
});

app.use(express.json({ limit: '64kb' }));
app.post('/api/shorten', (req, res) => {
  try {
    const config = normalizeConfig(req.body);
    const id = shorten(config);
    res.json({ id, url: `${baseUrlOfReq(req)}/s/${id}/manifest.json` });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// --- health ------------------------------------------------------------

app.get('/health', (_req, res) => {
  res.json({ ok: true, uptime: Math.round(process.uptime()), version: 2 });
});

// --- manifest ----------------------------------------------------------

app.get('/manifest.json', (req, res) => {
  res.json(buildManifest(baseUrlOfReq(req), req.streamplayConfig));
});

// --- streams -----------------------------------------------------------

app.get('/stream/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  if (type !== 'movie' && type !== 'series') {
    return res.status(404).json({ streams: [] });
  }

  // Stremio ids: movie -> "tt123"; series -> "tt123:1:2".
  const parts = id.split(':');
  const imdbId = parts[0];
  const season = type === 'series' ? parseInt(parts[1], 10) || null : null;
  const episode = type === 'series' ? parseInt(parts[2], 10) || null : null;

  if (!/^tt\d+$/.test(imdbId)) {
    return res.json({ streams: [] });
  }

  const config = req.streamplayConfig;
  const medium = type === 'movie' ? 'movies' : 'series';
  const meta = await getMeta(type, imdbId);
  const ctx = {
    type,
    imdbId,
    tmdbId: meta?.tmdbId || null,
    title: meta?.name || '',
    year: meta?.year || null,
    orgTitle: meta?.originalTitle || meta?.name || null,
    keys: config.k || {},
    season,
    episode,
  };

  const sourceIds = enabledSources(config, medium);
  const collector = makeCollector();

  const withTimeout = (fn) =>
    Promise.race([
      fn(),
      new Promise((resolve) => setTimeout(() => resolve('timeout'), SOURCE_TIMEOUT_MS)),
    ]);

  const jobs = sourceIds.map(async (sourceId) => {
    const source = SOURCES[sourceId];
    if (!source) return;
    const started = Date.now();
    try {
      const result = await withTimeout(() => source.find(ctx, (link) => collector.emit(link)));
      if (result === 'timeout') {
        console.warn(`[stream] source ${sourceId} timed out after ${SOURCE_TIMEOUT_MS}ms`);
      } else {
        console.log(`[stream] ${sourceId}: done in ${Date.now() - started}ms`);
      }
    } catch (err) {
      console.warn(`[stream] source ${sourceId} error: ${err.message}`);
    }
  });

  await Promise.allSettled(jobs);

  let links = collector.links;

  // Real-Debrid resolution for torrent entries (nyaa etc.)
  const rdKeyVal = rdKeyFrom(config);
  if (rdKeyVal) {
    const torrentLinks = links.filter((l) => l.debrid === 'rd').slice(0, 15);
    await Promise.allSettled(
      torrentLinks.map(async (l) => {
        try {
          const res = await rdResolveMagnet(l.url, rdKeyVal);
          if (res && res.url) {
            l.url = res.url;
            l.title = (l.title || '') + ' • RD';
            l.debrid = 'resolved';
          }
        } catch { /* skip */ }
      })
    );
    links = links.filter((l) => l.debrid !== 'rd' || l.debrid === 'resolved');
  }

  links = filterByResolution(links, config.res);
  links = filterBySize(links, config.fs);
  links = filterSeekable(links, config.sk);
  links = capPerSource(links, config.mp);
  links = sortLinks(links, config.so, config.ord);
  if (config.mt > 0) links = links.slice(0, Math.min(config.mt, MAX_STREAMS));

  res.json({ streams: links.map((l) => toStremio(l, config, ctx)) });
});

// --- catalogs ----------------------------------------------------------

app.get('/catalog/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  const metas = await catalogHandler(type, id, null, 0);
  res.json({ metas });
});

app.get('/catalog/:type/:id/:extras.json', async (req, res) => {
  const { type, id, extras } = req.params;
  // extras like "genre=Action&skip=20" (Stremio joins with &)
  const parsed = Object.fromEntries(
    extras.split('&').map((kv) => {
      const idx = kv.indexOf('=');
      return idx >= 0 ? [kv.slice(0, idx), decodeURIComponent(kv.slice(idx + 1))] : [kv, ''];
    })
  );
  const skip = parseInt(parsed.skip, 10) || 0;
  const metas = await catalogHandler(type, id, parsed, skip);
  res.json({ metas });
});

async function catalogHandler(type, catalogId, extras, skip) {
  try {
    if (extras?.search) {
      return await searchMetas(type, extras.search, skip);
    }
    if (!CATALOG_DEFS.some((c) => c.id === catalogId)) return [];
    const genre = extras?.genre && extras.genre !== 'top' ? extras.genre : null;
    return await fetchCatalog(catalogId, type, genre, skip);
  } catch (err) {
    console.warn(`[catalog] ${catalogId} failed: ${err.message}`);
    return [];
  }
}

// --- subtitles ---------------------------------------------------------

app.get('/subtitles/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  const parts = id.split(':');
  const imdbId = parts[0];
  if (!/^tt\d+$/.test(imdbId)) return res.json({ subtitles: [] });

  const config = req.streamplayConfig;
  try {
    const subtitles = await getSubtitles(type, imdbId, parseInt(parts[1], 10) || null, parseInt(parts[2], 10) || null, config.sl);
    res.json({ subtitles });
  } catch (err) {
    console.warn(`[subtitles] failed for ${imdbId}: ${err.message}`);
    res.json({ subtitles: [] });
  }
});

// --- configure UI + static --------------------------------------------

app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/configure', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'configure', 'index.html'));
});
app.get('/logo.jpg', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'logo.jpg'));
});

// Feature/source metadata for the configure page.
app.get('/api/sources', (_req, res) => {
  res.json({
    sources: SOURCE_DEFS,
    categories: SOURCE_CATEGORIES,
    contentTypes: CONTENT_TYPES,
    resolutions: [2160, 1080, 720, 480, 360],
    resLabels: RES_LABELS,
    defaultNameFormat: DEFAULT_NAME_FORMAT,
    defaultDescFormat: DEFAULT_DESC_FORMAT,
    formatPresets: FORMAT_PRESETS,
    sortModes: SORT_MODES,
    subtitleLangs: SUBTITLE_LANGS,
    tmdbEnabled: Boolean(process.env.TMDB_API),
    discord: process.env.DISCORD_URL || null,
    coffee: process.env.COFFEE_URL || 'https://buymeacoffee.com/phisher98',
  });
});

// --- boot / graceful shutdown ------------------------------------------

const server = app.listen(PORT, HOST, () => {
  console.log(`StreamPlay Stremio addon running at http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log(`Configure:  http://localhost:${PORT}/configure`);
  console.log(`Health:     http://localhost:${PORT}/health`);
  console.log(`TMDB catalogs: ${process.env.TMDB_API ? 'enabled (TMDB_API set)' : 'Cinemeta fallback (set TMDB_API for TMDB catalogs)'}`);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    console.log(`\n${signal} received, shutting down...`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000).unref();
  });
}
