// 2Embed source - port of invoke2embed (StreamPlayExtractor.kt:148-313).
// Primary: vidcore.io flow via enc-dec.app enc/dec helpers.
// Fallback: 2embed.cc embed page -> uqloads player -> unpacked HLS.
import { getDoc, getText, postText, baseUrlOf, USER_AGENT } from '../http.js';
import { getAndUnpack } from '../extractors/jsunpack.js';

export const id = '2embed';

const ENC_DEC_API = 'https://enc-dec.app/api';
const VIDCORE_API = 'https://vidcore.io';
const TWO_EMBED_API = 'https://www.2embed.cc';

// Matches \"en\" / \"token\" values in the vidcore page payload.
const EN_TOKEN_RE = /\\?"(?:en|token)\\?"\s*:\s*\\?"([^\\"]+)\\?"/;

async function vidcoreFlow(ctx, emit) {
  const id = ctx.tmdbId || ctx.imdbId;
  if (!id) return false;

  const requestUrl =
    ctx.season == null ? `${VIDCORE_API}/movie/${id}` : `${VIDCORE_API}/tv/${id}/${ctx.season}/${ctx.episode}`;

  const baseHeaders = {
    'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    Referer: `${VIDCORE_API}/`,
  };

  try {
    const pageText = (await getText(requestUrl, { headers: baseHeaders })).body;
    const encodedText = pageText.match(EN_TOKEN_RE)?.[1];
    if (!encodedText) return false;

    const encJson = JSON.parse(
      (await getText(`${ENC_DEC_API}/enc-vidcore?text=${encodeURIComponent(encodedText)}`)).body
    );
    const result = encJson?.result;
    if (!result || !result.servers || !result.stream) return false;

    const withAjax = { ...baseHeaders, 'X-Requested-With': 'XMLHttpRequest' };
    if (result.token) withAjax['X-CSRF-Token'] = result.token;

    const serversEncrypted = (await postText(result.servers, { headers: withAjax })).body;
    if (!serversEncrypted) return false;

    const serversRoot = JSON.parse((await postText(`${ENC_DEC_API}/dec-vidcore`, { json: { text: serversEncrypted } })).body);
    const serversList = serversRoot?.result || [];
    if (!Array.isArray(serversList) || serversList.length === 0) return false;

    for (const [index, server] of serversList.entries()) {
      const name = server.name || `Server ${index + 1}`;
      const data = server.data;
      if (!data) continue;

      const streamUrl = `${result.stream}/${data}`;
      const streamEncrypted = await postText(streamUrl, { headers: withAjax }).then((r) => r.body).catch(() => '');
      if (!streamEncrypted) continue;

      const streamRoot = JSON.parse(
        (await postText(`${ENC_DEC_API}/dec-vidcore`, { json: { text: streamEncrypted } })).body
      );
      const finalUrl = streamRoot?.result?.url;
      if (!finalUrl) continue;

      const noRef = streamRoot.result.noReferrer === true;
      const is4k =
        /4K/i.test(name) ||
        /Premier/i.test(name) ||
        /4K/i.test(server.description || '') ||
        /4k/i.test(server.image || '');
      const quality = is4k ? 2160 : 1080;

      emit({
        source: '2Embed',
        title: `2Embed [${name}]`,
        url: finalUrl,
        quality,
        kind: /\.m3u8/i.test(finalUrl) ? 'm3u8' : 'video',
        referer: noRef ? '' : `${VIDCORE_API}/`,
      });
    }
    return serversList.length > 0;
  } catch {
    return false;
  }
}

async function fallbackFlow(ctx, emit) {
  const id = ctx.imdbId;
  if (!id) return;

  const url =
    ctx.season == null ? `${TWO_EMBED_API}/embed/${id}` : `${TWO_EMBED_API}/embedtv/${id}&s=${ctx.season}&e=${ctx.episode}`;

  try {
    const resp = await postText(url, {
      form: { pls: 'pls' },
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Referer: url, 'User-Agent': USER_AGENT },
    });
    const doc = (await import('cheerio')).load(resp.body);

    const candidateUrls = [];
    const iframe = doc('iframe#iframesrc').first();
    if (iframe.length > 0) {
      const dataSrc = iframe.attr('data-src');
      const src = iframe.attr('src');
      if (dataSrc) candidateUrls.push(dataSrc);
      if (src && src !== 'about:blank') candidateUrls.push(src);
    }

    doc("a[onclick*='go(']").each((_i, el) => {
      const target = (doc(el).attr('onclick') || '').match(/go\(['"]([^'"]+)['"]\)/)?.[1];
      if (target) candidateUrls.push(target);
    });

    for (const embedLink of [...new Set(candidateUrls)]) {
      if (embedLink.includes('id=') && /uqloads/i.test(embedLink)) {
        const ref = baseUrlOf(embedLink);
        const uqId = embedLink.split('id=').pop().split('&')[0];
        if (uqId) {
          await uqloads(`https://uqloads.xyz/e/${uqId}`, ref ? `${ref}/` : TWO_EMBED_API, emit);
        }
      }
      // Other embed hosts are not covered in v1.
    }
  } catch {
    /* skip fallback */
  }
}

// Port of UqloadsXyz (Extractors.kt:2446): unpacked player -> hls2/hls4 links.
async function uqloads(url, referer, emit) {
  try {
    let resp = await getText(url.replace('/download/', '/e/'), { referer });
    let html = resp.body;

    const iframeSrc = (await import('cheerio')).load(html)('iframe').first().attr('src');
    if (iframeSrc) {
      resp = await getText(iframeSrc, {
        headers: { 'Accept-Language': 'en-US,en;q=0.5', 'Sec-Fetch-Dest': 'iframe' },
        referer: resp.url || url,
      });
      html = resp.body;
    }

    let script = getAndUnpack(html);
    if (!script) {
      const $ = (await import('cheerio')).load(html);
      script =
        $('script')
          .toArray()
          .map((el) => $(el).html() || '')
          .find((s) => s.includes('sources:')) || '';
    }
    if (!script) return;

    const links = [];
    for (const m of script.matchAll(/hls2":"(?<hls2>[^"]+)"|hls4":"(?<hls4>[^"]+)"/g)) {
      if (m.groups.hls2) links.push(m.groups.hls2);
      else if (m.groups.hls4) links.push(`https://uqloads.xyz${m.groups.hls4}`);
    }

    for (const m3u8 of links) {
      emit({
        source: '2Embed Uqloads',
        title: '2Embed [Uqloads]',
        url: m3u8,
        quality: null,
        kind: 'm3u8',
        referer: 'https://uqloads.xyz/',
      });
    }
  } catch {
    /* skip */
  }
}

export async function find(ctx, emit) {
  const primary = await vidcoreFlow(ctx, emit);
  if (!primary) {
    await fallbackFlow(ctx, emit);
  }
}
