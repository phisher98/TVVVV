// AniKoto source - port of the AniKoto Cloudstream module (Provider.kt +
// Extractors.kt). Anime matching via ani.zip (imdb -> anilist/mal + titles).
// Flow: filter search -> watch page data-id -> episode servers ajax ->
// MegaPlay family embeds -> AES-CBC sources decrypt + HMAC-signed HLS token.
import crypto from 'node:crypto';
import * as cheerio from 'cheerio';
import { getDoc, getText, USER_AGENT } from '../http.js';
import { getAniZipMapping } from '../anime.js';

export const id = 'anikoto';

const MAIN = 'https://anikototv.to';
const MEGAPLAY_ENC_KEY = 'i?LMTAx0Q6,:}50U';
const MEGAPLAY_ENC_IV = "W0;27ToaUpl_P%'c";
const MEGAPLAY_TOKEN_SECRET = 'MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s';

const BROWSER_HEADERS = {
  'User-Agent': USER_AGENT,
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
};

const ajaxHeaders = (referer) => ({
  'User-Agent': USER_AGENT,
  'X-Requested-With': 'XMLHttpRequest',
  Accept: 'application/json, text/javascript, */*; q=0.01',
  Referer: referer,
});

const b64url = (buf) => Buffer.from(buf).toString('base64url');

// JSON helpers: anikoto ajax returns {status, result:"<html>"} or {status, result:{url}}
function jsonResultString(json) {
  try {
    const obj = JSON.parse(json);
    return obj.status === 200 ? obj.result || '' : '';
  } catch {
    return '';
  }
}
function jsonResultUrl(json) {
  try {
    const obj = JSON.parse(json);
    return obj.status === 200 ? obj.result?.url || null : null;
  } catch {
    return null;
  }
}

function signMegaPlayUrl(url) {
  if (url.includes('token=')) return url;
  const m = url.match(/\/([a-f0-9]{32})\/([a-f0-9]{32})\//i);
  if (!m) return url;
  const payload = `${Math.floor(Date.now() / 1000) + 90}|${m[1]}/${m[2]}`;
  const sig = crypto.createHmac('sha256', MEGAPLAY_TOKEN_SECRET).update(payload, 'utf8').digest();
  return `${url}${url.includes('?') ? '&' : '?'}token=${b64url(payload)}.${b64url(sig)}`;
}

function decryptMegaPlaySources(enc) {
  try {
    const normalized = enc.replace(/-/g, '+').replace(/_/g, '/');
    const keyBytes = Buffer.from(MEGAPLAY_ENC_KEY, 'utf8');
    const key = Buffer.concat([keyBytes, Buffer.alloc(32 - keyBytes.length)]);
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(MEGAPLAY_ENC_IV, 'utf8'));
    const json = Buffer.concat([decipher.update(Buffer.from(normalized, 'base64')), decipher.final()]).toString('utf8');
    return json;
  } catch {
    return null;
  }
}

// Resolve a megaplay-family embed to a signed HLS URL.
async function extractMegaPlay(embedUrl, host, label, referer, emit) {
  try {
    const pageHeaders = { 'User-Agent': USER_AGENT, Referer: referer || 'https://anikototv.to/' };
    const page = (await getText(embedUrl, { headers: pageHeaders })).body;
    const playerEl = cheerio.load(page)('#megaplay-player').first();
    const streamId =
      playerEl.attr('data-id') ||
      page.match(/data-id=["'](\d+)["']/)?.[1] ||
      playerEl.attr('data-realid') ||
      embedUrl.match(/\/stream\/s-\d+\/(\d+)/)?.[1];
    if (!streamId) return;

    const endpoints = host.includes('megaplay.buzz')
      ? ['/stream/getSourcesNew', '/stream/getSources']
      : ['/stream/getSources', '/stream/getSourcesNew'];

    for (const ep of endpoints) {
      const resp = await getText(`${host}${ep}?id=${streamId}&type=sub`, {
        headers: { ...ajaxHeaders(embedUrl), Origin: host },
      }).catch(() => null);
      if (!resp) continue;
      let candidate;
      try {
        candidate = JSON.parse(resp.body);
      } catch {
        continue;
      }
      let m3u8 = '';
      const el = candidate?.sources;
      if (el && typeof el === 'object' && !Array.isArray(el)) m3u8 = el.file || '';
      else if (Array.isArray(el) && el.length > 0) m3u8 = el[0]?.file || '';
      if (!m3u8 && candidate?.enc) {
        const dec = decryptMegaPlaySources(candidate.enc);
        if (dec) {
          try {
            const dj = JSON.parse(dec);
            m3u8 = dj?.file || dj?.source || dj?.url || (typeof dec === 'string' && dec.startsWith('http') ? dec : '');
          } catch {
            m3u8 = dec.startsWith('http') ? dec : '';
          }
        }
      }
      if (!m3u8) continue;

      const signed = signMegaPlayUrl(m3u8);
      emit({
        source: 'AniKoto',
        title: label,
        url: signed,
        quality: 1080,
        kind: 'm3u8',
        referer: `${host}/`,
        headers: { 'User-Agent': USER_AGENT, Accept: '*/*', Origin: host, Referer: `${host}/` },
      });
      return;
    }
  } catch {
    /* skip embed */
  }
}

async function resolveServers(serverIds, referer, audioType, emit) {
  try {
    const listResp = (await getText(`${MAIN}/ajax/server/list?servers=${encodeURIComponent(serverIds)}`, {
      headers: ajaxHeaders(referer),
    })).body;
    const serverHtml = jsonResultString(listResp);
    if (!serverHtml) return false;

    const sd = cheerio.load(serverHtml);
    const selectors =
      audioType === 'dub' ? ['div.type[data-type=dub]'] : ['div.type[data-type=sub]', 'div.type[data-type=hsub]'];

    let entries = [];
    for (const sel of selectors) {
      sd(`${sel} li[data-link-id]`).each((_i, li) => {
        entries.push({ linkId: sd(li).attr('data-link-id'), name: sd(li).text().trim() || 'Server', type: audioType });
      });
    }
    if (entries.length === 0) {
      sd('li[data-link-id]').each((_i, li) => {
        entries.push({ linkId: sd(li).attr('data-link-id'), name: sd(li).text().trim() || 'Server', type: audioType });
      });
    }
    if (entries.length === 0) return false;

    const jobs = entries.slice(0, 6).map(async (entry) => {
      try {
        let embedUrl = jsonResultUrl(
          (await getText(`${MAIN}/ajax/server?get=${encodeURIComponent(entry.linkId)}`, { headers: ajaxHeaders(referer) })).body
        );
        if (!embedUrl) return;
        if (entry.type === 'dub' && embedUrl.includes('/sub')) embedUrl = embedUrl.replace('/sub', '/dub');
        else if (entry.type !== 'dub' && embedUrl.includes('/dub')) embedUrl = embedUrl.replace('/dub', '/sub');

        const host = new URL(embedUrl).origin;
        if (/megaplay|vidwish|vidtube/i.test(host)) {
          await extractMegaPlay(embedUrl, host, `${entry.name} [${entry.type.toUpperCase()}]`, referer, emit);
        }
        // Other embed families are skipped (unresolvable server-side).
      } catch {
        /* skip */
      }
    });
    await Promise.allSettled(jobs);
    return true;
  } catch {
    return false;
  }
}

export async function find(ctx, emit) {
  if (!ctx.title) return;

  // ani.zip mapping when this is a known anime (titles help match, ep data future)
  const mapping = ctx.imdbId ? await getAniZipMapping(ctx.imdbId).catch(() => null) : null;

  let doc;
  try {
    doc = (await getDoc(`${MAIN}/filter?keyword=${encodeURIComponent(ctx.title)}`, { headers: BROWSER_HEADERS })).doc;
  } catch {
    return;
  }

  // The filter page is client-side rendered for plain fetches - use the
  // Firecrawl CF/render fallback when no items came back.
  if (doc('div.ani.items > div.item').length === 0) {
    doc = (await getDocCF(`${MAIN}/filter?keyword=${encodeURIComponent(ctx.title)}`)) || doc;
  }

  const candidates = [];
  doc('div.ani.items > div.item').each((_i, item) => {
    const a = doc(item).find('a.name.d-title, a[title]').first();
    const href = a.attr('href') || doc(item).find('a').first().attr('href');
    const label = a.attr('title') || a.text() || doc(item).find('.title').first().text();
    if (href && label) candidates.push({ href, label: label.trim() });
  });
  if (candidates.length === 0) return;

  const needle = ctx.title.toLowerCase().replace(/[^a-z0-9]/g, '');
  const altTitles = mapping?.title ? [mapping.title].filter(Boolean) : [];
  const match =
    candidates.find((c) => {
      const clean = c.label.toLowerCase().replace(/[^a-z0-9]/g, '');
      return clean === needle || clean.includes(needle) || needle.includes(clean);
    }) ||
    candidates.find((c) =>
      altTitles.some((t) => t && c.label.toLowerCase().includes(String(t).toLowerCase()))
    ) ||
    candidates[0];

  const pageUrl = /^https?:/i.test(match.href) ? match.href : `${MAIN}${match.href}`;

  // Watch page -> data-id
  let animeId = null;
  try {
    const watchUrl = pageUrl.includes('/watch') ? pageUrl : pageUrl; // filter links go to info pages
    const infoDoc = (await getDoc(watchUrl, { headers: BROWSER_HEADERS })).doc;
    animeId =
      infoDoc('#watch-main').attr('data-id') ||
      infoDoc('[data-id]').first().attr('data-id') ||
      infoDoc.html().match(/data-id=["'](\d+)["']/)?.[1];

    // info pages may link straight to the watch page
    if (!animeId) {
      const watchHref = infoDoc("a[href*='/watch']").first().attr('href');
      if (watchHref) {
        const wUrl = /^https?:/i.test(watchHref) ? watchHref : `${MAIN}${watchHref}`;
        const wDoc = (await getDoc(wUrl, { headers: BROWSER_HEADERS })).doc;
        animeId = wDoc('#watch-main').attr('data-id') || wDoc.html().match(/data-id=["'](\d+)["']/)?.[1];
      }
    }
  } catch {
    return;
  }
  if (!animeId) return;

  // Episode list -> server ids for this episode
  try {
    const epHtml = jsonResultString(
      (
        await getText(`${MAIN}/ajax/episode/list/${animeId}`, {
          headers: ajaxHeaders(pageUrl),
          referer: pageUrl,
        })
      ).body
    );
    if (!epHtml) return;
    const ed = cheerio.load(epHtml);
    const epEl =
      ed('a[data-ids]')
        .toArray()
        .find((el) => parseInt(ed(el).attr('data-num'), 10) === ctx.episode) ||
      ed('a[data-ids]').first().get(0);
    if (!epEl) return;
    const serverIds = ed(epEl).attr('data-ids');
    if (!serverIds) return;
    const audioType = ctx.episode != null && ed(epEl).attr('data-dub') === '1' && !ed(epEl).attr('data-sub')
      ? 'dub'
      : 'sub';

    await resolveServers(serverIds, pageUrl, audioType, emit);
  } catch {
    /* skip */
  }
}
