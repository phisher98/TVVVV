// Atlantic source - port of invokeAtlantic (StreamPlayExtractor.kt:3059-3259)
// + decryptNesterov (:2925-2951). Seven sub-flows across the hls.lol family,
// incl. AES-GCM "nesterov/moscow" URL decryption and m3u8 master splitting.
import crypto from 'node:crypto';
import { getText } from '../http.js';

export const id = 'atlantic';

const KEY_HEX = '117c358bcfcaf8fe2cfca57c9d2238a300e1c4de2efb83a5012ba84d8a31f1dd';
const KEY_FALLBACK_HEX = 'e4b8a1d6f2c9037b5a8e4d1c6f9b2085a7c3e9f6d1b4a8c2e5f7a0d3b6c9e2f5';
const MOSCOW_KEY_HEX = '55060a042823f51a94c296894a58a0db15f3baef807155140983083fa799ef47';

const HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  Referer: 'https://atlantic.st/',
  Origin: 'https://atlantic.st',
  Accept: '*/*',
  'Accept-Language': 'en-US,en;q=0.9',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'cross-site',
};

function atlanticQuery(tmdbId, type, season, episode, seasonKey = 'seasonId', episodeKey = 'episodeId') {
  const base = `tmdbId=${tmdbId}&type=${type}`;
  if (season == null) return base;
  return `${base}&${seasonKey}=${season}&${episodeKey}=${episode ?? 1}`;
}

// ms_/hl_/ns_ prefixed hex blobs are AES-GCM encrypted URLs.
function decryptNesterov(url) {
  let keys;
  if (url.startsWith('hl_') || url.startsWith('ns_')) keys = [KEY_HEX, KEY_FALLBACK_HEX];
  else if (url.startsWith('ms_')) keys = [MOSCOW_KEY_HEX];
  else return url;

  let blob;
  try {
    blob = Buffer.from(url.slice(3), 'hex');
  } catch {
    return url;
  }
  if (blob.length < 28) return url;

  for (const kHex of keys) {
    try {
      const key = Buffer.from(kHex, 'hex');
      const nonce = blob.subarray(0, 12);
      const data = blob.subarray(12);
      const tag = data.subarray(data.length - 16);
      const decipher = crypto.createDecipheriv('aes-256-gcm', key, nonce);
      decipher.setAuthTag(tag);
      const decrypted = Buffer.concat([
        decipher.update(data.subarray(0, data.length - 16)),
        decipher.final(),
      ]).toString('utf8');
      if (decrypted.startsWith('http')) return decrypted;
    } catch {
      /* try next key */
    }
  }
  return url;
}

function normalizeQuality(width, height) {
  if (!height || height <= 0) return null;
  if ((width && width >= 3800) || height >= 2000) return 2160;
  if (height >= 1300) return 1440;
  if (height >= 750) return 1080;
  if (height >= 500) return 720;
  if (height >= 400) return 480;
  if (height >= 200) return 360;
  return null;
}

// Fetch the master playlist and emit one entry per variant (quality-aware).
async function addAtlanticLink(server, streamUrl, emit) {
  if (!streamUrl || !streamUrl.startsWith('http')) return;

  let master = '';
  try {
    master = (await getText(streamUrl, { headers: HEADERS, timeout: 15000 })).body || '';
  } catch {
    master = '';
  }

  const variants = master.includes('#EXT-X-STREAM-INF')
    ? master.split('#EXT-X-STREAM-INF:').slice(1)
    : [];

  if (variants.length === 0) {
    emit({
      source: 'Atlantic',
      title: `Atlantic [${server}]`,
      url: streamUrl,
      quality: null,
      kind: 'm3u8',
      headers: HEADERS,
      referer: 'https://atlantic.st/',
    });
    return;
  }

  for (const variant of variants) {
    const attrs = variant.split('\n')[0];
    const uri = variant
      .split('\n')
      .find((l) => l.trim() && !l.startsWith('#'));
    if (!uri) continue;
    const resolved = /^https?:/i.test(uri)
      ? uri
      : new URL(uri, streamUrl).toString();
    const resMatch = attrs.match(/RESOLUTION=(\d+)x(\d+)/);
    emit({
      source: 'Atlantic',
      title: `Atlantic [${server}]`,
      url: resolved,
      quality: normalizeQuality(
        resMatch ? parseInt(resMatch[1], 10) : null,
        resMatch ? parseInt(resMatch[2], 10) : null
      ),
      kind: 'm3u8',
      headers: HEADERS,
      referer: 'https://atlantic.st/',
    });
  }
}

async function atlanticMoscow(tmdbId, type, season, episode, emit) {
  for (const endpoint of [
    `https://stream.hls.lol/moscow?${atlanticQuery(tmdbId, type, season, episode)}`,
    `https://stream.hls.lol/helios?${atlanticQuery(tmdbId, type, season, episode)}`,
  ]) {
    try {
      const res = await getText(endpoint, { headers: HEADERS, timeout: 15000 });
      if (res.statusCode >= 400) continue;
      const parsed = JSON.parse(res.body);
      const source = Object.values(parsed?.sources || {}).find((s) => s?.url);
      if (!source) continue;
      const streamUrl = decryptNesterov(source.url);
      if (streamUrl.startsWith('http')) {
        await addAtlanticLink(source.server || 'Moscow', streamUrl, emit);
        return;
      }
    } catch {
      continue;
    }
  }
}

async function atlanticAphrodite(tmdbId, isTv, season, episode, emit) {
  const path = isTv ? `/content/tv/${tmdbId}/${season || 1}/${episode || 1}` : `/content/movie/${tmdbId}`;
  try {
    const res = await getText(`https://cdn.hls.lol${path}`, { headers: HEADERS, timeout: 15000 });
    if (res.statusCode >= 400) return;
    const parsed = JSON.parse(res.body);
    if (parsed?.found !== true) return;
    const streamUrl = parsed.hls || (parsed.type === 'hls' ? parsed.url : null);
    if (streamUrl) await addAtlanticLink('Aphrodite', streamUrl, emit);
  } catch {
    /* skip */
  }
}

async function atlanticAthena(tmdbId, isTv, season, episode, emit) {
  const url =
    `https://zcdn2.6azt0hwr-cf9.workers.dev/cdn?tmdb=${tmdbId}` +
    `&type=${isTv ? 'tv' : 'movie'}` +
    (isTv ? `&season=${season || 1}&episode=${episode || 1}` : '');
  try {
    const res = await getText(url, { headers: HEADERS, timeout: 15000 });
    if (res.statusCode >= 400) return;
    const parsed = JSON.parse(res.body);
    if (parsed?.ready !== true || !parsed.url) return;
    await addAtlanticLink('Athena', parsed.url, emit);
  } catch {
    /* skip */
  }
}

async function atlanticSourceMap(server, url, emit) {
  try {
    const res = await getText(url, { headers: HEADERS, timeout: 15000 });
    if (res.statusCode >= 400) return;
    const parsed = JSON.parse(res.body);
    for (const source of Object.values(parsed?.sources || {})) {
      if (source?.url) await addAtlanticLink(server, source.url, emit);
    }
  } catch {
    /* skip */
  }
}

async function atlanticHorcrux(tmdbId, type, season, episode, emit) {
  try {
    const res = await getText(`https://stream.hls.lol/q62?${atlanticQuery(tmdbId, type, season, episode)}`, {
      headers: HEADERS,
      timeout: 15000,
    });
    if (res.statusCode >= 400) return;
    const parsed = JSON.parse(res.body);
    const master = parsed?.releases?.[0]?.master;
    if (master) await addAtlanticLink('Horcrux', master, emit);
  } catch {
    /* skip */
  }
}

async function atlanticChione(tmdbId, type, season, episode, title, year, emit) {
  if (!title) return;
  const url =
    `https://dash.hls.lol/resolve?type=${type}` +
    `&tmdbId=${tmdbId}` +
    `&title=${encodeURIComponent(title)}` +
    (year != null ? `&year=${year}` : '') +
    (season != null ? `&season=${season}&episode=${episode ?? 1}` : '');
  try {
    const res = await getText(url, { headers: HEADERS, timeout: 20000 });
    if (res.statusCode >= 400) return;
    const parsed = JSON.parse(res.body);
    const tracks = (parsed?.tracks || []).filter((t) => t?.url);
    const best =
      tracks
        .filter((t) => t.mode === 'original')
        .sort((a, b) => (parseInt(b.quality, 10) || 0) - (parseInt(a.quality, 10) || 0))[0] || tracks[0];
    if (!best) return;
    emit({
      source: 'Atlantic',
      title: 'Atlantic [Chione]',
      url: best.url,
      quality: normalizeQuality(null, parseInt(best.quality, 10) || null),
      kind: 'dash',
      headers: HEADERS,
      referer: 'https://atlantic.st/',
    });
  } catch {
    /* skip */
  }
}

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;
  const isTv = ctx.season != null;
  const type = isTv ? 'tv' : 'movie';

  const jobs = [
    atlanticMoscow(ctx.tmdbId, type, ctx.season, ctx.episode, emit).catch(() => {}),
    atlanticAphrodite(ctx.tmdbId, isTv, ctx.season, ctx.episode, emit).catch(() => {}),
    atlanticAthena(ctx.tmdbId, isTv, ctx.season, ctx.episode, emit).catch(() => {}),
    atlanticSourceMap('Silvia', `https://it.hls.lol/resolve?${atlanticQuery(ctx.tmdbId, type, ctx.season, ctx.episode)}`, emit).catch(() => {}),
    atlanticSourceMap('Amnesty', `https://stream.hls.lol/amnesty?${atlanticQuery(ctx.tmdbId, type, ctx.season, ctx.episode)}`, emit).catch(() => {}),
    atlanticHorcrux(ctx.tmdbId, type, ctx.season, ctx.episode, emit).catch(() => {}),
    atlanticChione(ctx.tmdbId, type, ctx.season, ctx.episode, ctx.title, ctx.year, emit).catch(() => {}),
  ];
  await Promise.allSettled(jobs);
}
