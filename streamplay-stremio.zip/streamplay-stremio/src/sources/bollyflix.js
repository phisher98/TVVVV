// Bollyflix source - port of invokeBollyflix (StreamPlayExtractor.kt:4790-4831).
// search -> post pages -> quality headings -> download links (sidexfee id=
// links decode to base64) -> host router. TV: episode page -> Episode NN anchor.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'bollyflix';

export async function find(ctx, emit) {
  const api = (await getDomain('bollyflix')) || '';
  const id = ctx.imdbId || ctx.title;
  if (!api || !id) return;

  let searchDoc;
  try {
    searchDoc = (await getDoc(`${api}/search/${id}`, { timeout: 10000 })).doc;
  } catch {
    return;
  }

  const jobs = [];

  searchDoc('div > article > a').each((_i, el) => {
    const url = searchDoc(el).attr('href');
    if (!url) return;
    jobs.push(processPost(url, api, ctx, emit));
  });

  await Promise.allSettled(jobs);
}

async function processPost(url, api, ctx, emit) {
  try {
    const doc = (await getDoc(url)).doc;
    const hTag = ctx.season == null ? 'h5' : 'h4';
    const sTag = ctx.season == null ? '' : `Season ${ctx.season}`;

    const entries = doc(`div.thecontent.clearfix > ${hTag}`)
      .toArray()
      .filter((el) => {
        const text = doc(el).text();
        return (
          new RegExp(`${sTag}.*(480p|720p|1080p|2160p)`, 'i').test(text) &&
          !text.toLowerCase().includes('download')
        );
      })
      .slice(-4);

    for (const entry of entries) {
      let href = doc(entry).next().find('a').first().attr('href');
      if (!href) continue;

      if (href.includes('id=')) {
        const token = href.split('id=').pop();
        try {
          const resp = await getText(`https://web.sidexfee.com/?id=${token}`);
          const encodedurl = resp.body.split('link":"').pop().split('"};')[0];
          href = Buffer.from(encodedurl, 'base64').toString('utf8');
        } catch {
          continue;
        }
      }

      if (ctx.season == null) {
        await routeExtractor(href, 'Bollyflix', emit);
      } else {
        const episodeText = `Episode ${String(ctx.episode).padStart(2, '0')}`;
        try {
          const epDoc = (await getDoc(href)).doc;
          const link = epDoc('article h3 a')
            .filter((_i, el) => epDoc(el).text().includes(episodeText))
            .first()
            .attr('href');
          if (link) await routeExtractor(link, 'Bollyflix', emit);
        } catch {
          /* skip */
        }
      }
    }
  } catch {
    /* skip post */
  }
}
