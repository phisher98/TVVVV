// Cinejoy source - port of invokeCinejoy (StreamPlayExtractor.kt:3542-3680).
// api.wing.st: server list -> encrypted request flow (enc-dec.app enc-cinejoy,
// binary POST /g, dec-cinejoy with state) -> HLS playlists / quality files.
import { getText, postText, USER_AGENT } from '../http.js';

export const id = 'cinejoy';

const CINEJOY_API = 'https://api.wing.st';
const CINEJOY_BASE = 'https://cinejoy.to';
const ENC_DEC_API = 'https://enc-dec.app/api';

const DEFAULT_SERVERS = ['Lisbon', 'Nebula', 'Solara', 'Athens'];

const b64urlDecode = (s) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const b64urlEncodeNoPad = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

async function getServers(headers) {
  try {
    const resp = await getText(`${CINEJOY_API}/servers`, { headers });
    const servers = (JSON.parse(resp.body)?.servers || [])
      .map((s) => s?.name)
      .filter((n) => n && n !== '');
    return servers.length > 0 ? servers : DEFAULT_SERVERS;
  } catch {
    return DEFAULT_SERVERS;
  }
}

const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

export async function find(ctx, emit) {
  if (!ctx.title) return;
  const isSeries = ctx.season != null && ctx.episode != null;
  const type = isSeries ? 'series' : 'movie';

  const headers = {
    Accept: '*/*',
    Origin: CINEJOY_BASE,
    Referer: `${CINEJOY_BASE}/`,
    'User-Agent': USER_AGENT,
  };

  const servers = await getServers(headers);
  const encTitle = encodeURIComponent(ctx.title);

  const jobs = servers.map(async (server) => {
    try {
      let targetUrl = `${CINEJOY_API}/?title=${encTitle}&type=${type}&year=${ctx.year ?? ''}&imdb=${ctx.imdbId ?? ''}&tmdb=${ctx.tmdbId ?? ''}&server=${server}`;
      if (isSeries) targetUrl += `&season=${ctx.season}&episode=${ctx.episode}`;

      const encResp = JSON.parse(
        (await getText(`${ENC_DEC_API}/enc-cinejoy?url=${encodeURIComponent(targetUrl)}`)).body
      );
      if (encResp?.status !== 200 || !encResp?.result?.data || !encResp?.result?.state) return;

      const requestBody = b64urlDecode(encResp.result.data);
      const encrypted = await postText(`${CINEJOY_API}/g`, {
        headers,
        body: requestBody,
      });
      if (encrypted.statusCode >= 400) return;

      const encryptedBytes = Buffer.isBuffer(encrypted.body)
        ? encrypted.body
        : Buffer.isBuffer(encrypted.rawBody)
          ? encrypted.rawBody
          : Buffer.from(encrypted.body, 'binary');
      const b64Encrypted = b64urlEncodeNoPad(encryptedBytes);
      const decResp = JSON.parse(
        (await postText(`${ENC_DEC_API}/dec-cinejoy`, { json: { text: b64Encrypted, state: encResp.result.state } }))
          .body
      );

      const decData = decResp?.result?.data;
      if (!decData || decData.error) return;

      for (const stream of decData.stream || []) {
        if (stream.type === 'hls' && stream.playlist) {
          emit({
            source: 'Cinejoy',
            title: `Cinejoy - ${cap(server.toLowerCase())}`,
            url: stream.playlist,
            quality: 1080,
            kind: 'm3u8',
            referer: `${CINEJOY_BASE}/`,
          });
        } else if (stream.type === 'file' && stream.qualities) {
          for (const [qualityKey, qualityData] of Object.entries(stream.qualities)) {
            const fileUrl = qualityData?.url;
            if (!fileUrl || !fileUrl.includes('https')) continue;
            const quality =
              qualityKey === '4k' ? 2160 : qualityKey === '1080' ? 1080 : qualityKey === '720' ? 720 : qualityKey === '480' ? 480 : null;
            emit({
              source: 'Cinejoy',
              title: `Cinejoy - ${cap(server.toLowerCase())} (${qualityKey})`,
              url: fileUrl,
              quality,
              kind: /\.m3u8/i.test(fileUrl) ? 'm3u8' : 'video',
              referer: `${CINEJOY_BASE}/`,
            });
          }
        }
      }
    } catch {
      /* skip server */
    }
  });

  await Promise.allSettled(jobs);
}
