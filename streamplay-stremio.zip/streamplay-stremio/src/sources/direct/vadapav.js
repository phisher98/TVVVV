// Vadapav source - port of invokeVadapav (StreamPlayExtractor.kt:7734-7790).
// stremio.vadapav.mov already exposes a Stremio-style stream API - proxy it.
import { getText, USER_AGENT } from '../../http.js';

export const id = 'vadapav';

const VADAPAV_API = 'https://stremio.vadapav.mov';

export async function find(ctx, emit) {
  const imdbId = ctx.imdbId;
  if (!imdbId || !imdbId.startsWith('tt')) return;

  const endpoint =
    ctx.season != null && ctx.episode != null
      ? `${VADAPAV_API}/stream/series/${imdbId}:${ctx.season}:${ctx.episode}.json`
      : `${VADAPAV_API}/stream/movie/${imdbId}.json`;

  let json;
  try {
    json = (
      await getText(endpoint, {
        headers: {
          'User-Agent': USER_AGENT,
          Accept: 'application/json, text/plain, */*',
        },
      })
    ).body;
  } catch {
    return;
  }

  let resp;
  try {
    resp = JSON.parse(json);
  } catch {
    return;
  }

  for (const item of resp?.streams || []) {
    const url = item?.url;
    if (!url || !url.startsWith('http')) continue;
    const rawTitle = item.title || 'Vadapav • Direct Stream';
    const displayTitle = rawTitle.split('\n')[0].trim();
    const qualityMatch = displayTitle.match(/(2160p|1080p|720p|480p)/i)?.[1];

    emit({
      source: 'Vadapav',
      title: `Vadapav ${displayTitle}`,
      url,
      quality: qualityMatch ? parseInt(qualityMatch, 10) : null,
      kind: /\.m3u8/i.test(url) ? 'm3u8' : 'video',
    });
  }
}
