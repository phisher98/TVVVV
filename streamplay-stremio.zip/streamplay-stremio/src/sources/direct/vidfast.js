// VidFast source - port of invokeVidFast (StreamPlayExtractor.kt:6587-6700).
// vidfast.vc page -> token -> enc-dec.app enc/dec-vidfast -> encrypted
// servers/stream endpoints -> HLS links + caption tracks.
import { getText, postText, USER_AGENT } from '../../http.js';

export const id = 'vidfast';

const VIDFAST_API = 'https://vidfast.vc';
const ENC_DEC_API = 'https://enc-dec.app/api';
const VERSION = '1';

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;

  const requestUrl =
    ctx.season == null
      ? `${VIDFAST_API}/movie/${ctx.tmdbId}`
      : `${VIDFAST_API}/tv/${ctx.tmdbId}/${ctx.season}/${ctx.episode}`;

  const baseHeaders = {
    'User-Agent': USER_AGENT,
    Referer: `${VIDFAST_API}/`,
  };

  try {
    const pageText = (await getText(requestUrl, { headers: baseHeaders })).body;
    const encodedText = pageText.match(/\\?"(?:en|token)\\?"\s*:\s*\\?"([^\\"]+)\\?"/)?.[1];
    if (!encodedText) return;

    const encJson = JSON.parse(
      (
        await getText(`${ENC_DEC_API}/enc-vidfast?text=${encodeURIComponent(encodedText)}&version=${VERSION}`)
      ).body
    );
    const result = encJson?.result;
    if (!result || !result.servers || !result.stream) return;

    const withAjax = { ...baseHeaders, 'X-Requested-With': 'XMLHttpRequest' };
    if (result.token) withAjax['X-CSRF-Token'] = result.token;

    const serversEncrypted = await postText(result.servers, { headers: withAjax }).then((r) => r.body).catch(() => '');
    if (!serversEncrypted) return;

    const serversRoot = JSON.parse(
      (
        await postText(`${ENC_DEC_API}/dec-vidfast`, {
          json: { text: serversEncrypted, version: VERSION },
        })
      ).body
    );
    const serversList = serversRoot?.result || [];
    if (!Array.isArray(serversList) || serversList.length === 0) return;

    for (const [index, server] of serversList.entries()) {
      const name = server.name || `Server ${index + 1}`;
      const data = server.data;
      if (!data) continue;

      const streamUrl = `${result.stream}/${data}`;
      const streamEncrypted = await postText(streamUrl, { headers: withAjax }).then((r) => r.body).catch(() => '');
      if (!streamEncrypted) continue;

      const streamRoot = JSON.parse(
        (
          await postText(`${ENC_DEC_API}/dec-vidfast`, {
            json: { text: streamEncrypted, version: VERSION },
          })
        ).body
      );
      const finalUrl = streamRoot?.result?.url;
      if (!finalUrl) continue;

      const noRef = streamRoot.result.noReferrer === true;
      const is4k =
        /4K/i.test(name) ||
        /Premier/i.test(name) ||
        /4K/i.test(server.description || '') ||
        /4k/i.test(server.image || '');
      const quality = is4k ? 2160 : 1080;

      emit({
        source: 'VidFast',
        title: `VidFast [${name}]`,
        url: finalUrl,
        quality,
        kind: /\.m3u8/i.test(finalUrl) ? 'm3u8' : 'video',
        referer: noRef ? '' : `${VIDFAST_API}/`,
      });
    }
  } catch {
    /* skip */
  }
}
