// VidLink source - port of invokeVidlink (StreamPlayExtractor.kt:6510-6585).
// enc-dec.app encrypts the TMDB id, then vidlink.pro returns multi-quality
// HLS streams + captions.
import { getText, USER_AGENT } from '../../http.js';

export const id = 'vidlink';

const VIDLINK = 'https://vidlink.pro';
const ENC_DEC_API = 'https://enc-dec.app/api';

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;

  try {
    const encJson = JSON.parse((await getText(`${ENC_DEC_API}/enc-vidlink?text=${ctx.tmdbId}`)).body);
    const encData = encJson?.result;
    if (!encData) return;

    const headers = {
      'User-Agent':
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
      Connection: 'keep-alive',
      Referer: `${VIDLINK}/`,
      Origin: VIDLINK,
    };

    const epUrl =
      ctx.season == null ? `${VIDLINK}/api/b/movie/${encData}` : `${VIDLINK}/api/b/tv/${encData}/${ctx.season}/${ctx.episode}`;

    const data = JSON.parse((await getText(epUrl, { headers })).body);
    const qualities = data?.stream?.qualities;
    if (!qualities) return;

    const videoHeaders = {
      accept: '*/*',
      'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
      dnt: '1',
      'user-agent': USER_AGENT,
    };

    for (const [quality, qualityData] of Object.entries(qualities)) {
      const videoUrl = qualityData?.url;
      if (!videoUrl) continue;

      let q = null;
      const m = String(quality).match(/(\d{3,4})/);
      if (m) q = parseInt(m[1], 10);
      else if (/4k/i.test(String(quality))) q = 2160;

      emit({
        source: 'Vidlink',
        title: 'Vidlink',
        url: videoUrl,
        quality: q,
        kind: /\.m3u8/i.test(videoUrl) ? 'm3u8' : 'video',
        referer: VIDLINK,
        headers: videoHeaders,
      });
    }
  } catch {
    /* skip */
  }
}
