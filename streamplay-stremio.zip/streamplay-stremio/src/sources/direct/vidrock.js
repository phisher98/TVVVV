// VidRock source - port of invokevidrock (StreamPlayExtractor.kt:6463-6508)
// + decryptVidrockUrl (StreamPlayUtils.kt:3011): AES-GCM decrypt of server URLs.
import crypto from 'node:crypto';
import { getText, USER_AGENT } from '../../http.js';

export const id = 'vidrock';

const VIDROCK = 'https://vidrock.ru';
// AES-GCM key (hex) from decryptVidrockUrl.
const AES_KEY_HEX = '7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f';

function decryptVidrockUrl(encryptedPayload) {
  try {
    const keyBytes = Buffer.from(AES_KEY_HEX, 'hex');
    const standardBase64 = encryptedPayload.replace(/-/g, '+').replace(/_/g, '/');
    const encryptedData = Buffer.from(standardBase64, 'base64');
    if (encryptedData.length < 13) return null;

    const nonce = encryptedData.subarray(0, 12);
    const cipherTextWithTag = encryptedData.subarray(12);

    const decipher = crypto.createDecipheriv('aes-256-gcm', keyBytes, nonce);
    decipher.setAuthTag(cipherTextWithTag.subarray(cipherTextWithTag.length - 16));
    const decrypted = Buffer.concat([
      decipher.update(cipherTextWithTag.subarray(0, cipherTextWithTag.length - 16)),
      decipher.final(),
    ]);
    return decrypted.toString('utf8');
  } catch {
    return null;
  }
}

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;

  const apiUrl =
    ctx.season == null
      ? `${VIDROCK}/api/movie/${ctx.tmdbId}/`
      : `${VIDROCK}/api/tv/${ctx.tmdbId}/${ctx.season}/${ctx.episode}/`;

  const headers = { Origin: VIDROCK, Referer: `${VIDROCK}/`, 'User-Agent': USER_AGENT };

  try {
    const json = JSON.parse((await getText(apiUrl, { headers })).body);

    for (const [serverName, serverData] of Object.entries(json)) {
      if (!serverData || typeof serverData !== 'object') continue;
      const encryptedUrl = serverData?.url || '';
      if (!encryptedUrl || encryptedUrl === 'error' || encryptedUrl === 'null') continue;

      const decryptedUrl = decryptVidrockUrl(encryptedUrl);
      if (!decryptedUrl) continue;

      emit({
        source: 'Vidrock',
        title: `Vidrock [${serverName}]`,
        url: decryptedUrl,
        quality: null,
        kind: decryptedUrl.includes('m3u8') ? 'm3u8' : 'video',
        headers,
      });
    }
  } catch {
    /* skip */
  }
}
