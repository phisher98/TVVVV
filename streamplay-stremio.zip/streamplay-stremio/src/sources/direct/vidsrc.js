// VidSrc source - port of the primary flow of invokeVidSrcXyz
// (StreamPlayExtractor.kt:4980-5071): data.vidsrc.sh API + per-server token.
// The WASM-encrypted fallback path is intentionally not ported.
import { getText, baseUrlOf, USER_AGENT } from '../../http.js';

export const id = 'vidsrc';

const DATA_BASE = 'https://data.vidsrc.sh';
const PLAYER_ORIGIN = 'https://cloudorchestranova.com';

export async function find(ctx, emit) {
  const imdb = ctx.imdbId;
  if (!imdb) return;

  const headers = {
    'User-Agent': USER_AGENT,
    Origin: PLAYER_ORIGIN,
    Referer: `${PLAYER_ORIGIN}/`,
    Accept: 'application/json',
  };

  const apiUrl =
    ctx.season == null
      ? `${DATA_BASE}/api.php?type=movie&imdb=${imdb}&stream_urls`
      : `${DATA_BASE}/api.php?type=tv&imdb=${imdb}&season=${ctx.season}&episode=${ctx.episode}&stream_urls`;

  try {
    const apiText = (await getText(apiUrl, { headers })).body.trim();
    if (!apiText.startsWith('{')) return;

    const root = JSON.parse(apiText);
    const dataObj = root?.data;
    const rawStreams = [];

    const streamUrls = dataObj?.stream_urls;
    if (Array.isArray(streamUrls)) {
      for (const s of streamUrls) {
        if (typeof s === 'string' && /^https?:/i.test(s.trim())) rawStreams.push(s.trim());
      }
    } else {
      // Encrypted stream_urls requires the WASM decryptor - skip gracefully.
      return;
    }

    if (rawStreams.length === 0) return;

    for (const [index, rawStreamUrl] of rawStreams.entries()) {
      const streamOrigin = baseUrlOf(rawStreamUrl);
      let token = '';
      try {
        token = (await getText(`${streamOrigin}/generate.php`, { headers })).body.trim();
      } catch {
        token = '';
      }

      const finalStreamUrl = !token
        ? rawStreamUrl
        : rawStreamUrl.includes('__TOKEN__')
          ? rawStreamUrl.replace('__TOKEN__', token)
          : rawStreamUrl.includes('?')
            ? `${rawStreamUrl}&token=${token}`
            : `${rawStreamUrl}?token=${token}`;

      emit({
        source: 'VidSrc',
        title: `VidSrc Server ${index + 1}`,
        url: finalStreamUrl,
        quality: 1080,
        kind: 'm3u8',
        referer: `${PLAYER_ORIGIN}/`,
        headers: { Origin: PLAYER_ORIGIN, Referer: `${PLAYER_ORIGIN}/` },
      });
    }
  } catch {
    /* skip */
  }
}
