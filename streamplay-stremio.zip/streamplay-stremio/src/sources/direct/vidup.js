// Vidup source - port of invokeVidup (StreamPlayExtractor.kt:6709-6820).
// Same enc-dec pattern as VidFast but with enc-vidup/dec-vidup endpoints.
import { getText, postText, USER_AGENT } from '../../http.js';

export const id = 'vidup';

const VIDUP_API = 'https://vidup.to';
const ENC_DEC_API = 'https://enc-dec.app/api';

// Matches \"en\" / \"token\" values in the vidup page payload.
const EN_TOKEN_RE = /\\?"(?:en|token)\\?"\s*:\s*\\?"([^\\"]+)\\?"/;

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;

  const requestUrl =
    ctx.season == null ? `${VIDUP_API}/movie/${ctx.tmdbId}` : `${VIDUP_API}/tv/${ctx.tmdbId}/${ctx.season}/${ctx.episode}`;

  const baseHeaders = {
    'User-Agent': USER_AGENT,
    Referer: `${VIDUP_API}/`,
  };

  try {
    const pageText = (await getText(requestUrl, { headers: baseHeaders })).body;
    const encodedText = pageText.match(EN_TOKEN_RE)?.[1];
    if (!encodedText) return;

    const encJson = JSON.parse(
      (await getText(`${ENC_DEC_API}/enc-vidup?text=${encodeURIComponent(encodedText)}`)).body
    );
    const result = encJson?.result;
    if (!result || !result.servers || !result.stream) return;

    const withAjax = { ...baseHeaders, 'X-Requested-With': 'XMLHttpRequest' };
    if (result.token) withAjax['X-CSRF-Token'] = result.token;

    const serversEncrypted = await postText(result.servers, { headers: withAjax }).then((r) => r.body).catch(() => '');
    if (!serversEncrypted) return;

    const serversRoot = JSON.parse(
      (await postText(`${ENC_DEC_API}/dec-vidup`, { json: { text: serversEncrypted } })).body
    );
    const serversList = serversRoot?.result || [];
    if (!Array.isArray(serversList) || serversList.length === 0) return;

    for (const [index, server] of serversList.entries()) {
      const name = server.name || `Server ${index + 1}`;
      const data = server.data;
      if (!data) continue;

      const streamUrl = `${result.stream}/${data}`;
      const streamEncrypted = await postText(streamUrl, { headers: withAjax }).then((r) => r.body).catch(() => '');
      if (!streamEncrypted) continue;

      const streamRoot = JSON.parse(
        (await postText(`${ENC_DEC_API}/dec-vidup`, { json: { text: streamEncrypted } })).body
      );
      const finalUrl = streamRoot?.result?.url;
      if (!finalUrl) continue;

      const noRef = streamRoot.result.noReferrer === true;
      const is4k = /4K/i.test(name) || /Premier/i.test(name) || /4K/i.test(server.description || '') || /4k/i.test(server.image || '');
      const quality = is4k ? 2160 : 1080;

      emit({
        source: 'Vidup',
        title: `Vidup [${name}]`,
        url: finalUrl,
        quality,
        kind: /\.m3u8/i.test(finalUrl) ? 'm3u8' : 'video',
        referer: noRef ? '' : `${VIDUP_API}/`,
      });
    }
  } catch {
    /* skip */
  }
}
