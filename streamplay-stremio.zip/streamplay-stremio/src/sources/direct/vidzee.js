// VidZee source - port of invokeVidzee (StreamPlayExtractor.kt:3759-3902),
// plain (unencrypted) path only - the encrypted `c` payload needs the
// extension's WebView WASM decryptor, which a server cannot run.
import { getText, USER_AGENT } from '../../http.js';

export const id = 'vidzee';

const CORE_API = 'https://core.vidzee.wtf';
const DEFAULT_REFERER = 'https://player.vidzee.wtf/';

const HEADERS = {
  'User-Agent': USER_AGENT,
  Origin: 'https://player.vidzee.wtf',
  Referer: DEFAULT_REFERER,
};

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;
  const id = ctx.tmdbId;
  const { season, episode } = ctx;

  // Languages for the Acme (v4) servers.
  let v4Languages = [];
  try {
    const langUrl =
      season == null ? `${CORE_API}/streams/languages/movie/${id}` : `${CORE_API}/streams/languages/tv/${id}/${season}/${episode}`;
    const langJson = JSON.parse((await getText(langUrl, { headers: HEADERS })).body);
    v4Languages = (langJson?.languages || []).filter((l) => l && l !== '');
  } catch {
    v4Languages = [];
  }

  const servers = [
    ['dcloud', 'Dcloud'],
    ['doppler', 'Doppler'],
    ...v4Languages.map((lang) => [`v4:${lang}`, `Acme (${lang})`]),
    ['tik', 'TCloud'],
    ['ipcloud', 'IPcloud'],
    ['v6:Hindi', 'Server Hindi'],
    ['v6:English', 'Server English'],
  ];

  const jobs = servers.map(async ([serverId, serverName]) => {
    try {
      const encServer = encodeURIComponent(serverId);
      const streamApiUrl =
        season == null
          ? `${CORE_API}/streams/movie/${id}?s=${encServer}&e=1`
          : `${CORE_API}/streams/tv/${id}/${season}/${episode}?s=${encServer}&e=1`;

      const responseText = (await getText(streamApiUrl, { headers: HEADERS })).body;
      if (!responseText.trim().startsWith('{')) return;
      const rootJson = JSON.parse(responseText);

      // Encrypted payloads (rootJson.c) need the WebView WASM decryptor - skip.
      if (rootJson.c) return;
      const streamJson = rootJson;

      const finalUrl = streamJson?.url || '';
      if (!finalUrl.startsWith('http')) return;

      const lang = streamJson.language || '';
      const headersMap = streamJson.headers || {};
      const referer = headersMap.Referer || headersMap.referer || DEFAULT_REFERER;
      const displayName =
        lang && !serverName.toLowerCase().includes(lang.toLowerCase())
          ? `VidZee ${serverName} (${lang})`
          : `VidZee ${serverName}`;

      emit({
        source: 'VidZee',
        title: displayName,
        url: finalUrl,
        quality: null,
        kind: /\.m3u8/i.test(finalUrl) ? 'm3u8' : 'video',
        referer,
        headers: headersMap,
      });
    } catch {
      /* skip server */
    }
  });

  await Promise.allSettled(jobs);
}
