// XPass source - port of invokeXpass (StreamPlayExtractor.kt:7659-7732)
// + decryptXpassDataUrl / extractXpassBackups (StreamPlayUtils.kt).
// play.xpass.top embed -> dataUrl token -> SHA-256/AES-GCM encrypted server list.
import crypto from 'node:crypto';
import { getText, USER_AGENT } from '../../http.js';
export const id = 'xpass';

const XPASS_API = 'https://play.xpass.top';
const BUILD_ID = 'spv3-build-1787821613-50e5fc97c9dce367';

function decryptXpassDataUrl(dataUrl, refererUrl) {
  return (async () => {
    try {
      const path = dataUrl.split('?')[0];
      const token = dataUrl.match(/token=([^&]+)/)?.[1];
      if (!token) return [];

      const key = crypto
        .createHash('sha256')
        .update(`spv3-data-response|${BUILD_ID}|${path}|${token}`, 'utf8')
        .digest();

      const fullDataUrl = /^https?:/i.test(dataUrl) ? dataUrl : `https://play.xpass.top${dataUrl}`;
      const encText = (
        await getText(fullDataUrl, {
          headers: {
            'User-Agent': USER_AGENT,
            Referer: refererUrl,
            Origin: 'https://play.xpass.top',
          },
        })
      ).body.trim();

      const padded = encText.replace(/-/g, '+').replace(/_/g, '/');
      const rawBytes = Buffer.from(padded, 'base64');
      if (rawBytes.length <= 12) return [];

      const iv = rawBytes.subarray(0, 12);
      const ciphertext = rawBytes.subarray(12);
      const tag = ciphertext.subarray(ciphertext.length - 16);
      const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
      decipher.setAuthTag(tag);
      const decrypted = Buffer.concat([
        decipher.update(ciphertext.subarray(0, ciphertext.length - 16)),
        decipher.final(),
      ]).toString('utf8');

      const parsed = JSON.parse(decrypted);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();
}

function extractXpassBackups(html) {
  const raw = html.match(/var backups=(\[.*?]);/s)?.[1];
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    return arr
      .filter((o) => o?.name && o?.url)
      .map((o) => [o.name, o.url]);
  } catch {
    return [];
  }
}

export async function find(ctx, emit) {
  if (!ctx.tmdbId) return;
  const baseRef = `${XPASS_API}/`;
  const embedUrl =
    ctx.season == null
      ? `${XPASS_API}/e/movie/${ctx.tmdbId}?autostart=true`
      : `${XPASS_API}/e/tv/${ctx.tmdbId}/${ctx.season}/${ctx.episode}?autostart=true`;

  let html;
  try {
    html = (await getText(embedUrl, { referer: 'https://streamsrcs.2embed.cc/' })).body;
  } catch {
    return;
  }

  const dataUrl = html.match(/var dataUrl\s*=\s*"([^"]+)"/)?.[1];
  let serverList = [];
  if (dataUrl) {
    serverList = await decryptXpassDataUrl(dataUrl, embedUrl);
  } else {
    serverList = extractXpassBackups(html).map(([name, url]) => ({ name, url }));
  }
  if (serverList.length === 0) return;

  const jobs = serverList.map(async (server) => {
    try {
      const relUrl = server?.url;
      if (!relUrl) return;
      const sName = server?.name || 'Server';
      const fullUrl = /^https?:/i.test(relUrl) ? relUrl : XPASS_API + relUrl;

      const json = (
        await getText(fullUrl, {
          headers: {
            Referer: embedUrl,
            Origin: XPASS_API,
            Accept: 'application/json,*/*',
          },
        })
      ).body;

      const plResp = JSON.parse(json);
      const sources = plResp?.playlist?.[0]?.sources || [];
      for (const source of sources) {
        const file = source?.file;
        if (!file || !file.startsWith('http')) continue;
        const isM3u8 = source.type?.toLowerCase() === 'hls' || file.includes('.m3u8');
        if (isM3u8) {
          emit({
            source: `XPass [${sName}]`,
            title: `XPass [${sName}]`,
            url: file,
            quality: null,
            kind: 'm3u8',
            referer: baseRef,
          });
        } else {
          emit({
            source: `XPass [${sName}]`,
            title: `XPass [${sName}]`,
            url: file,
            quality: null,
            kind: 'video',
            referer: baseRef,
          });
        }
      }
    } catch {
      /* skip server */
    }
  });

  await Promise.allSettled(jobs);
}
