// HDHub4u source - port of invokehdhub4u (StreamPlayExtractor.kt:5339-5560).
// Typesense search (search.pingora.fyi) -> post pages -> download links
// (id= links through getRedirectLinks) -> host router.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { getRedirectLinks } from '../extractors/redirectLinks.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'hdhub4u';

const SEARCH_API =
  'https://search.pingora.fyi/collections/post/documents/search' +
  '?q=<Q>&query_by=post_title,category&query_by_weights=4,2&sort_by=sort_by_date:desc' +
  '&limit=20&highlight_fields=none&use_cache=true&page=1';

export async function find(ctx, emit) {
  const baseUrl = (await getDomain('HDHUB4u')) || '';
  if (!ctx.title) return;

  let json;
  try {
    const resp = await getText(SEARCH_API.replace('<Q>', encodeURIComponent(ctx.title)), {
      referer: baseUrl || undefined,
    });
    json = JSON.parse(resp.body);
  } catch {
    return;
  }
  const hits = json?.hits || [];
  if (hits.length === 0) return;

  const normalizedTitle = ctx.title.toLowerCase().replace(/[^a-z0-9]/g, '');
  const seasonText = ctx.season != null ? `season ${ctx.season}` : null;

  const posts = [];
  for (const hit of hits) {
    const document = hit?.document;
    if (!document) continue;
    const postTitle = (document.post_title || '').toLowerCase();
    const rawPermalink = document.permalink || '';

    let permalink = rawPermalink;
    if (baseUrl) {
      let path = '';
      if (/^https?:/i.test(rawPermalink)) {
        const afterScheme = rawPermalink.split('://').pop();
        const p = afterScheme.includes('/') ? '/' + afterScheme.split('/').slice(1).join('/') : '';
        path = p;
      } else {
        path = rawPermalink.startsWith('/') ? rawPermalink : `/${rawPermalink}`;
      }
      permalink = baseUrl.replace(/\/$/, '') + path;
    }

    if (!postTitle || !permalink) continue;
    const cleanTitle = postTitle.replace(/[^a-z0-9]/g, '');

    const matches =
      ctx.season != null
        ? cleanTitle.includes(normalizedTitle) && postTitle.includes(seasonText)
        : ctx.year != null
          ? cleanTitle.includes(normalizedTitle) && postTitle.includes(String(ctx.year))
          : cleanTitle.includes(normalizedTitle);

    if (matches) posts.push(permalink);
  }

  // IMDb verification when possible; falls back to all matched posts.
  let matchedPosts = posts;
  if (ctx.imdbId) {
    const verified = [];
    for (const postUrl of posts) {
      try {
        const doc = (await getDoc(postUrl)).doc;
        const imdbHref = doc(`a[href*="imdb.com/title/${ctx.imdbId}"]`).first().attr('href');
        if (imdbHref) verified.push(postUrl);
      } catch {
        /* skip */
      }
    }
    if (verified.length > 0) matchedPosts = verified;
  }

  const jobs = matchedPosts.map(async (postUrl) => {
    let doc;
    try {
      doc = (await getDoc(postUrl)).doc;
    } catch {
      return;
    }

    if (ctx.season == null) {
      // Movie: candidate anchors filtered by href/text signals.
      const links = [];
      doc('.page-body h3 a, .page-body h4 a, .page-body p a, .page-body div a, h3 a, h4 a, p a').each(
        (_i, el) => {
          const href = (doc(el).attr('href') || '').trim();
          const text = (doc(el).text() || '').trim();
          if (!href || href.startsWith('#')) return;
          if (/telegram|t\.me|how-to-download|catimages/i.test(href)) return;
          const isMatch =
            href.includes('?id=') ||
            /(hdstream4u|hubstream|hubcloud|hubdrive|hubcdn|hblinks|greenmotors)/i.test(href) ||
            /(480|720|1080|2160|4K|watch|player|download)/i.test(text);
          if (isMatch && !links.includes(href)) links.push(href);
        }
      );
      for (const resolvedLink of [...new Set(links)]) {
        await processLink(resolvedLink, emit);
      }
    } else {
      // Series: episode-heading walk (episode|e N headings + following siblings).
      const episodeRe = /(?:episode|e)\s*0*(\d+)/gi;
      let foundAnyEpisodes = false;

      for (const el of doc('h3, h4').toArray()) {
        episodeRe.lastIndex = 0;
        const epMatch = episodeRe.exec(doc(el).text());
        const episodeNumFromTitle = epMatch ? parseInt(epMatch[1], 10) : null;
        if (episodeNumFromTitle == null || (ctx.episode != null && ctx.episode !== episodeNumFromTitle)) {
          continue;
        }
        foundAnyEpisodes = true;

        const epLinks = [];
        doc(el)
          .find('a[href]')
          .each((_i, a) => {
            const href = doc(a).attr('href');
            if (href) epLinks.push(href);
          });

        let sibling = doc(el).next();
        while (sibling.length > 0 && sibling.get(0).tagName !== 'hr') {
          const sibText = sibling.text() || '';
          episodeRe.lastIndex = 0;
          if (episodeRe.test(sibText)) break;
          sibling
            .find('a[href]')
            .each((_i, a) => {
              const href = doc(a).attr('href');
              if (href) epLinks.push(href);
            });
          sibling = sibling.next();
        }

        const validLinks = epLinks.filter(
          (href) => !href.startsWith('#') && !/telegram|t\.me|catimages/i.test(href)
        );
        for (const href of [...new Set(validLinks)]) {
          await processLink(href, emit);
        }
      }

      if (!foundAnyEpisodes) {
        // Fallback: h3 groups with an "episode N" link + "watch" link.
        for (const h3 of doc('h3').toArray()) {
          const links = doc(h3).find('a[href]').toArray();
          const episodeLink = links.find((a) => /episode/i.test(doc(a).text()) || episodeRe.test(doc(a).text()));
          const watchLink = links.find((a) => /watch/i.test(doc(a).text()));

          episodeRe.lastIndex = 0;
          const episodeNum = episodeRe.exec(doc(episodeLink).text() || '')?.[1];
          const num = episodeNum ? parseInt(episodeNum, 10) : null;
          if (num == null || (ctx.episode != null && ctx.episode !== num)) continue;

          if (episodeLink) {
            const href = doc(episodeLink).attr('href');
            if (href && /^https?:/i.test(href)) {
              const resolved = href.includes('id=') ? await getRedirectLinks(href) : href;
              try {
                const epDoc = (await getDoc(resolved || href)).doc;
                const allLinks = [];
                epDoc('h3 a[href], h4 a[href], h5 a[href]').each((_i, a) => {
                  const l = epDoc(a).attr('href');
                  if (l && /^https?:/i.test(l)) allLinks.push(l);
                });
                for (const l of [...new Set(allLinks)]) {
                  await processLink(l, emit);
                }
              } catch {
                /* skip */
              }
            }
          }
          if (watchLink) {
            const watchHref = doc(watchLink).attr('href');
            if (watchHref && /^https?:/i.test(watchHref)) await processLink(watchHref, emit);
          }
        }
      }
    }
  });

  await Promise.allSettled(jobs);
}

async function processLink(link, emit) {
  const finalLink = link.includes('id=') ? (await getRedirectLinks(link)) || link : link;
  await routeExtractor(finalLink, 'HDhub4u', emit);
}
