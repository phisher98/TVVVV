// Hdmovie2 source - port of invokeHdmovie2 (StreamPlayExtractor.kt:5607-5714).
// /movies/<slug-year> -> dooplay player options (ajax embeds) or legacy dwo
// anchors -> router (embeds resolve via hubcloud/gdflix or are skipped).
import { getDoc, getText, postText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'hdmovie2';

export async function find(ctx, emit) {
  const api = ((await getDomain('hdmovie2')) || '').replace(/\/$/, '');
  if (!api || !ctx.title) return;

  const slug = ctx.title
    .split('')
    .filter((c) => /\s|[a-zA-Z0-9]/.test(c))
    .join('')
    .trim()
    .replace(/\s+/g, '-');
  if (!slug) return;

  const url = `${api}/movies/${slug}-${ctx.year ?? ''}`.replace(/-$/, '');
  const headers = {
    'User-Agent':
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  };
  const ajaxUrl = `${api}/wp-admin/admin-ajax.php`;
  const commonHeaders = {
    ...headers,
    Accept: '*/*',
    'X-Requested-With': 'XMLHttpRequest',
  };

  async function fetchSource(post, nume, type) {
    try {
      const response = await postText(ajaxUrl, {
        form: { action: 'doo_player_ajax', post, nume, type },
        referer: api,
        headers: commonHeaders,
      });
      const embedUrl = JSON.parse(response.body)?.embed_url || '';
      const cheerio = await import('cheerio');
      return cheerio.load(embedUrl)('iframe').first().attr('src') || '';
    } catch {
      return '';
    }
  }

  let doc;
  try {
    doc = (await getDoc(url, { headers })).doc;
  } catch {
    return;
  }

  let link = null;
  const playerOptions = doc('.dooplay_player .options ul li, #video-sources .options ul li')
    .toArray()
    .filter((el) => !/trailer/i.test(doc(el).text()));

  if (ctx.episode != null) {
    if (playerOptions.length > 0) {
      const epString = ctx.episode < 10 ? `EP0${ctx.episode}` : `EP${ctx.episode}`;
      const epNode =
        playerOptions.find((el) => doc(el).text().toLowerCase().includes(epString.toLowerCase())) ||
        playerOptions.find((el) => doc(el).text().toLowerCase().includes(`ep ${ctx.episode}`.toLowerCase())) ||
        playerOptions[ctx.episode - 1];
      link = epNode ? doc(epNode).find('a').first().attr('data-source') : null;
    } else {
      const ep = doc('ul#playeroptionsul > li').get(1);
      if (ep) {
        const post = doc(ep).attr('data-post');
        link = await fetchSource(post, String(ctx.episode + 1), 'movie');
      }
    }
  } else if (playerOptions.length > 0) {
    const preferred =
      playerOptions.find((el) => /v2|v3/i.test(doc(el).text())) || playerOptions[0];
    link = doc(preferred).find('a').first().attr('data-source');
  } else {
    const mv = doc('ul#playeroptionsul > li')
      .toArray()
      .find((el) => /v2|v3/i.test(doc(el).text()));
    if (mv) {
      link = await fetchSource(doc(mv).attr('data-post'), doc(mv).attr('data-nume'), 'movie');
    }
  }

  if (link) {
    await routeExtractor(link, 'Hdmovie2', emit);
  } else {
    // Legacy anchors fallback
    const anchors = [];
    doc('a[href*=dwo]').each((_i, el) => anchors.push(doc(el).attr('href')));
    const jobs = anchors.map(async (anchorHref) => {
      try {
        const innerDoc = (await getDoc(anchorHref)).doc;
        const links = [];
        innerDoc('div > p > a').each((_i, el) => links.push(innerDoc(el).attr('href')));
        for (const href of links) {
          if (/GDFlix/i.test(href)) {
            let redirectedUrl = href;
            for (let i = 0; i < 10; i++) {
              try {
                const loc = (await getText(href, { followRedirect: false })).headers.location;
                if (loc) redirectedUrl = loc;
                else break;
              } catch {
                break;
              }
            }
            await routeExtractor(redirectedUrl, 'Hdmovie2 (Combined)', emit);
          }
        }
      } catch {
        /* skip anchor */
      }
    });
    await Promise.allSettled(jobs);
  }
}
