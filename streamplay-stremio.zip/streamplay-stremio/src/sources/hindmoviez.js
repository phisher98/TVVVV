// Hindmoviez source - port of invokeHindmoviez (StreamPlayExtractor.kt:7165-7237)
// + hindmoviezsignHShare (StreamPlayUtils.kt:2719). ?s= search -> maxbutton
// pages -> hindshare signed dl links -> dl page scrape -> router.
import { getDoc, getText, postText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'hindmoviez';

function base64UrlEncode(str) {
  return Buffer.from(str, 'utf8').toString('base64url');
}

// Sign the id through the site's own AJAX (hindshare_sign), falling back to /dl/.
async function signHShare(rawId, domain, pageDoc) {
  const encoded = base64UrlEncode(rawId);

  let ajaxUrl = null;
  pageDoc('script').each((_i, el) => {
    if (ajaxUrl) return;
    const text = pageDoc(el).html() || '';
    ajaxUrl = text.match(/AJAX_URL\s*=\s*['"]([^'"]+)['"]/)?.[1] || null;
  });
  if (!ajaxUrl) return `${domain}/dl/${encoded}`;

  const resolvedAjax = /^https?:/i.test(ajaxUrl) ? ajaxUrl : `${domain}/${ajaxUrl}`.replace(/([^:]\/)\/+/g, '$1');

  try {
    const resp = await postText(resolvedAjax, {
      form: { action: 'hindshare_sign', d: encoded },
      referer: domain,
    });
    const signed = JSON.parse(resp.body)?.data?.url;
    return signed || `${domain}/dl/${encoded}`;
  } catch {
    return `${domain}/dl/${encoded}`;
  }
}

export async function find(ctx, emit) {
  const api = ((await getDomain('hindmoviez')) || '').replace(/\/$/, '');
  const id = ctx.imdbId || ctx.title;
  if (!api || !id) return;

  let searchDoc;
  try {
    searchDoc = (await getDoc(`${api}/?s=${encodeURIComponent(id)}`, { timeout: 5000 })).doc;
  } catch {
    return;
  }

  const entries = searchDoc('h2.entry-title > a').toArray();
  const jobs = entries.map(async (entry) => {
    try {
      const pageDoc = (await getDoc(searchDoc(entry).attr('href'), { timeout: 5000 })).doc;
      const buttons = pageDoc('a.maxbutton').toArray();

      for (const btn of buttons) {
        let targetDoc = pageDoc;
        let btnHref = pageDoc(btn).attr('href');

        if (ctx.episode != null) {
          // TV: pick the button group whose header mentions the season,
          // then the episode's page.
          const headerText = pageDoc(btn).parent().parent().prev().text() || '';
          if (!headerText.toLowerCase().includes(`season ${ctx.season}`)) continue;
          targetDoc = (await getDoc(btnHref, { timeout: 5000 })).doc;
          const epAnchor = targetDoc('h3 > a').get(ctx.episode - 1);
          if (!epAnchor) continue;
          btnHref = targetDoc(epAnchor).attr('href');
        }

        if (!btnHref) continue;
        const intermediateDoc = (await getDoc(btnHref, { timeout: 5000 })).doc;
        const linkHref = intermediateDoc('a.get-link-btn').first().attr('href');
        if (!linkHref) continue;

        const baseurl = linkHref.split('/?id=')[0];
        const rawId = decodeURIComponent(linkHref.split('id=').pop().replace(/\+/g, '%2B'));
        const signed = await signHShare(rawId, baseurl, intermediateDoc);

        // Scrape the dl page for resolvable links.
        try {
          const dlDoc = (await getDoc(signed, { timeout: 8000 })).doc;
          const links = [];
          dlDoc('a[href]').each((_i, el) => {
            const href = dlDoc(el).attr('href') || '';
            if (/hubcloud|gdflix|gdlink|driveseed|driveleech|pixeldrain|\.mp4|\.mkv|vcloud/i.test(href)) {
              links.push(href);
            }
          });
          if (links.length === 0) {
            await routeExtractor(signed, 'Hindmoviez', emit);
          } else {
            for (const link of [...new Set(links)]) {
              await routeExtractor(link, 'Hindmoviez', emit);
            }
          }
        } catch {
          await routeExtractor(signed, 'Hindmoviez', emit);
        }
      }
    } catch {
      /* skip entry */
    }
  });

  await Promise.allSettled(jobs);
}
