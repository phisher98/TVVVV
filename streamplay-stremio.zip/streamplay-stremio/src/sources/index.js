// Source registry: id -> module with find(ctx, emit).
import * as k4hdhub from './k4hdhub.js';
import * as hdhub4u from './hdhub4u.js';
import * as vegamovies from './vegamovies.js';
import * as rogmovies from './rogmovies.js';
import * as moviesdrive from './moviesdrive.js';
import * as moviebox from './moviebox.js';
import * as twoembed from './2embed.js';
import * as cinejoy from './cinejoy.js';
import * as vidy from './vidy.js';
import * as videasy from './videasy.js';
import * as bollyflix from './bollyflix.js';
import * as moviesmod from './moviesmod.js';
import * as uhdmovies from './uhdmovies.js';
import * as topmovies from './topmovies.js';
import * as multimovies from './multimovies.js';
import * as movies4u from './movies4u.js';
import * as hdmovie2 from './hdmovie2.js';
import * as hindmoviez from './hindmoviez.js';
import * as xdmovies from './xdmovies.js';
import * as anikoto from './anikoto.js';
import * as superstream from './superstream.js';
import * as nyaa from './nyaa.js';
import * as kisskh from './kisskh.js';
import * as vidsrc from './direct/vidsrc.js';
import * as vidlink from './direct/vidlink.js';
import * as vidrock from './direct/vidrock.js';
import * as vidfast from './direct/vidfast.js';
import * as vidup from './direct/vidup.js';
import * as vidzee from './direct/vidzee.js';
import * as xpass from './direct/xpass.js';
import * as vadapav from './direct/vadapav.js';
import * as atlantic from './atlantic.js';

export const SOURCES = {
  [k4hdhub.id]: k4hdhub,
  [hdhub4u.id]: hdhub4u,
  [vegamovies.id]: vegamovies,
  [rogmovies.id]: rogmovies,
  [moviesdrive.id]: moviesdrive,
  [moviebox.id]: moviebox,
  [twoembed.id]: twoembed,
  [cinejoy.id]: cinejoy,
  [vidy.id]: vidy,
  [videasy.id]: videasy,
  [bollyflix.id]: bollyflix,
  [moviesmod.id]: moviesmod,
  [uhdmovies.id]: uhdmovies,
  [topmovies.id]: topmovies,
  [multimovies.id]: multimovies,
  [movies4u.id]: movies4u,
  [hdmovie2.id]: hdmovie2,
  [hindmoviez.id]: hindmoviez,
  [xdmovies.id]: xdmovies,
  [anikoto.id]: anikoto,
  [superstream.id]: superstream,
  [nyaa.id]: nyaa,
  [kisskh.id]: kisskh,
  [vidsrc.id]: vidsrc,
  [vidlink.id]: vidlink,
  [vidrock.id]: vidrock,
  [vidfast.id]: vidfast,
  [vidup.id]: vidup,
  [vidzee.id]: vidzee,
  [xpass.id]: xpass,
  [vadapav.id]: vadapav,
  [atlantic.id]: atlantic,
};
