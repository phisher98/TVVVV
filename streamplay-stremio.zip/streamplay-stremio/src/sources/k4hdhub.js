// 4KHDHub source - port of invoke4khdhub (StreamPlayExtractor.kt:5264).
// WordPress search -> movie-card match -> download links -> getRedirectLinks
// -> host router (HubCloud / GDFlix / Pixeldrain).
import { getDoc } from '../http.js';
import { getDomain } from '../domains.js';
import { getRedirectLinks } from '../extractors/redirectLinks.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'k4hdhub';

export async function find(ctx, emit) {
  const domain = (await getDomain('4khdhub')) || '';
  const query = ctx.title;
  if (!domain || !query) return;

  const { doc: searchDoc } = await getDoc(`${domain}/?s=${encodeURIComponent(query)}`);
  const normalizedTitle = query.toLowerCase().trim();
  const yearStr = ctx.year ? String(ctx.year) : null;

  const cards = searchDoc('div.card-grid > a.movie-card').toArray();
  if (cards.length === 0) return;

  const contentOf = (el) =>
    (searchDoc(el).find('div.movie-card-content').first().text() || '').toLowerCase();

  let matched =
    cards.find((el) => {
      const content = contentOf(el);
      return content.includes(normalizedTitle) && (!yearStr || content.includes(yearStr));
    }) ||
    cards.find((el) => contentOf(el).includes(normalizedTitle));
  if (!matched) return;

  const link = searchDoc(matched).attr('href') || '';
  const url = /^https?:/i.test(link) ? link : `${domain}${link}`;

  const mainDoc = (await getDoc(url)).doc;

  const hrefs = [];
  if (ctx.season == null) {
    mainDoc('div.download-item a').each((_i, el) => {
      const href = mainDoc(el).attr('href');
      if (href && !hrefs.includes(href)) hrefs.push(href);
    });
  } else {
    const seasonText = `S${String(ctx.season).padStart(2, '0')}`;
    const episodeText = ctx.episode != null ? `E${String(ctx.episode).padStart(2, '0')}` : null;

    mainDoc('div.episode-download-item').each((_i, el) => {
      const text = mainDoc(el).text();
      if (!text.toLowerCase().includes(seasonText.toLowerCase())) return;
      if (episodeText && !text.toLowerCase().includes(episodeText.toLowerCase())) return;
      mainDoc(el)
        .find('div.episode-links > a')
        .each((_j, a) => {
          const href = mainDoc(a).attr('href');
          if (href && !hrefs.includes(href)) hrefs.push(href);
        });
    });
  }

  const jobs = hrefs.map(async (href) => {
    const source = (await getRedirectLinks(href)) || href;
    await routeExtractor(source, ctx.season == null ? '4Khdhub' : '4KHDHub', emit);
  });
  await Promise.allSettled(jobs);
}
