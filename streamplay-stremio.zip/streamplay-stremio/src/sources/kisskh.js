// KissKH source - port of invokeKisskh (StreamPlayExtractor.kt:844-1010).
// K-drama/Asian series: slug search -> drama -> episode id -> key-server
// kkey -> sources (video/thirdParty m3u8/mp4). Key endpoints via env.
import { getText } from '../http.js';

export const id = 'kisskh';

const API = process.env.KISSKH_API || 'https://kisskh.is';
const KEY_API = process.env.KISSKH_KEY_API || '';
const SUB_KEY_API = process.env.KISSKH_SUB_API || '';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

const refererHeaders = (ref) => ({
  'User-Agent': UA,
  Referer: ref,
  Accept: 'application/json',
});

function slugify(title) {
  return (title || '')
    .split('')
    .filter((c) => /[a-zA-Z0-9\s-]/.test(c))
    .join('')
    .trim()
    .replace(/\s+/g, '-')
    .toLowerCase();
}

function qualityOf(label) {
  const m = (label || '').match(/(\d{3,4})p/i);
  return m ? parseInt(m[1], 10) : null;
}

export async function find(ctx, emit) {
  if (!KEY_API || !SUB_KEY_API) return; // key endpoints required (env)
  const candidates = [...new Set([ctx.title, ctx.orgTitle].filter(Boolean))];
  if (candidates.length === 0) return;

  const type = ctx.season == null ? '2' : '1';

  for (const title of candidates) {
    try {
      const searchUrl = `${API}/api/DramaList/Search?q=${encodeURIComponent(title)}&type=${type}`;
      const res = await getText(searchUrl, { referer: `${API}/`, headers: refererHeaders(`${API}/`) });
      if (res.statusCode !== 200) continue;
      const list = JSON.parse(res.body);
      if (!Array.isArray(list) || list.length === 0) continue;

      const slug = slugify(title);
      const pick =
        list.length === 1
          ? list[0]
          : list.find((r) => {
              const rs = slugify(r.title);
              if (ctx.season == null) return rs === slug;
              return rs.includes(slug) && (/season/i.test(r.title || '') || true);
            }) || list.find((r) => (r.title || '') === title);
      if (!pick?.id) continue;

      // Drama detail -> episode id
      const detailUrl = `${API}/api/DramaList/Drama/${pick.id}?isq=false`;
      const detail = JSON.parse(
        (await getText(detailUrl, { referer: `${API}/Drama/${title}?id=${pick.id}`, headers: refererHeaders(`${API}/`) })).body
      );
      const eps = detail?.episodes || [];
      const ep =
        ctx.season == null
          ? eps[0]
          : eps.find((e) => e.number === ctx.episode) || eps[ctx.episode - 1];
      if (!ep?.id) continue;
      const epsId = ep.id;

      // Keys from the private key servers
      const [videoKeyRes, subKeyRes] = await Promise.all([
        getText(`${KEY_API}${epsId}&version=2.8.10`, { timeout: 10000 }).catch(() => null),
        getText(`${SUB_KEY_API}${epsId}&version=2.8.10`, { timeout: 10000 }).catch(() => null),
      ]);
      let kkey = null;
      try {
        kkey = JSON.parse(videoKeyRes?.body || '{}')?.key;
      } catch {}
      let kkey1 = null;
      try {
        kkey1 = JSON.parse(subKeyRes?.body || '{}')?.key;
      } catch {}
      if (!kkey) continue;

      const epReferer = `${API}/Drama/${title}/Episode-${ctx.episode || 0}?id=${pick.id}&ep=${epsId}&page=0&pageSize=100`;
      const sourcesResp = await getText(
        `${API}/api/DramaList/Episode/${epsId}.png?err=false&ts=&time=&kkey=${kkey}`,
        { referer: epReferer, headers: refererHeaders(`${API}/`) }
      );
      const sources = JSON.parse(sourcesResp.body);
      if (!sources) continue;

      const emitLink = (link, label) => {
        if (!link) return;
        if (link.includes('.m3u8') || link.includes('.mp4')) {
          emit({
            source: 'KissKH',
            title: `KissKH [${label}]`,
            url: link,
            quality: qualityOf(label) || 720,
            kind: /\.m3u8/i.test(link) ? 'm3u8' : 'video',
            referer: `${API}/`,
          });
        }
      };

      if (sources.video) emitLink(sources.video, sources.quality || 'HD');
      if (sources.thirdParty) emitLink(sources.thirdParty, sources.quality || 'HD');

      if (sources.video || sources.thirdParty) return; // success with this candidate
    } catch {
      /* next candidate */
    }
  }
}
