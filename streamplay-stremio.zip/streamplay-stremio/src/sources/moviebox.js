// MovieBox source - port of invokeMovieBox + the signing helpers in
// StreamPlayExtractor.kt (:5716-6040, :6097-6461). Signed Android-app API:
// x-client-token = "ts,md5(reversed-ts)", x-tr-signature = "ts|2|HmacMD5(canonical)",
// guest visitor-login bearer token, optional GSLB host remap, MP4 resources +
// DASH play-info streams (signCookie -> CloudFront/Edge-Cache policy MPD).
import crypto from 'node:crypto';
import { getText, postText } from '../http.js';

export const id = 'moviebox';

const MOVIEBOX_HOST = process.env.MOVIEBOX_HOST || 'https://apig.inmoviebox.com';
const MOVIEBOX_HOST_POOL = [
  'https://apig.inmoviebox.com',
  'https://apii.inmoviebox.com',
  'https://api7.aoneroom.com',
  'https://api6.aoneroom.com',
  'https://api5.aoneroom.com',
  'https://api4.aoneroom.com',
  'https://api4sg.aoneroom.com',
  'https://api3.aoneroom.com',
];
const MOVIEBOX_GSLB_URL = 'https://gslb.shalltry.com/gslb/domain/convert';
// Server serves a ~23s decoy MP4 unless a valid x-client-build session id is sent.
const MOVIEBOX_CLIENT_BUILD =
  process.env.MOVIEBOX_CLIENT_BUILD || '1790144723381916466.632cf3fe507b339bc757f117f85b4c4a';
// Signing keys. NOTE: the Kotlin source decodes the embedded base64 string
// and then base64-decodes it AGAIN for the key bytes (base64DecodeArray(secret)).
const SECRET_KEY_DEFAULT = Buffer.from(
  Buffer.from(
    process.env.MOVIEBOX_SECRET_KEY_DEFAULT || 'NzZpUmwwN3MweFNOOWpxbUVXQXQ3OUVCSlp1bElRSXNWNjRGWnIyTw==',
    'base64'
  ).toString('utf8'),
  'base64'
);
const SECRET_KEY_ALT = Buffer.from(
  Buffer.from(
    process.env.MOVIEBOX_SECRET_KEY_ALT || 'WHFuMm5uTzQxL0w5Mm8xaXVYaFNMSFRiWHZZNFo1Wlo2Mm04bVNMQQ==',
    'base64'
  ).toString('utf8'),
  'base64'
);

const movieboxUserAgent =
  'com.community.oneroom/50020132 (Linux; U; Android 14; en_IN; Pixel 8; Build/UD1A.230803.041; Cronet/145.0.7582.0)';
const deviceId = crypto.randomBytes(16).toString('hex');
const movieboxClientInfo = JSON.stringify({
  package_name: 'com.community.oneroom',
  version_name: '4.0.03.0930.03',
  version_code: 50020132,
  os: 'android',
  os_version: '14',
  device_id: deviceId,
  install_store: 'official',
  gaid: '1b2212c1-dadf-43c3-a0c8-bd6ce48ae22d',
  brand: 'Google',
  model: 'Pixel 8',
  system_language: 'en',
  net: 'NETWORK_WIFI',
  region: 'IN',
  timezone: 'Asia/Calcutta',
  sp_code: '',
});

const md5Hex = (buf) => crypto.createHash('md5').update(buf).digest('hex');
const sha256Hex = (s) => crypto.createHash('sha256').update(s).digest('hex');

// --- signing -----------------------------------------------------------

function generateXClientToken(ts = Date.now()) {
  const timestamp = String(ts);
  return `${timestamp},${md5Hex([...timestamp].reverse().join(''))}`;
}

function canonicalString(method, accept, contentType, url, body, timestamp) {
  let path = '';
  let query = '';
  try {
    const u = new URL(url);
    path = u.pathname;
    if (u.search) {
      query = u.search
        .slice(1)
        .split('&')
        .map((p) => {
          const idx = p.indexOf('=');
          return idx >= 0 ? [p.slice(0, idx), p.slice(idx + 1)] : [p, ''];
        })
        .sort((a, b) => (a[0] < b[0] ? -1 : 1))
        .map(([k, v]) => `${k}=${v}`)
        .join('&');
    }
  } catch {
    path = url;
  }
  const canonicalUrl = query ? `${path}?${query}` : path;

  let bodyHash = '';
  let bodyLength = '';
  if (body != null) {
    const buf = Buffer.from(body, 'utf8');
    const trimmed = buf.length > 102400 ? buf.subarray(0, 102400) : buf;
    bodyHash = md5Hex(trimmed);
    bodyLength = String(buf.length);
  }

  return [
    method.toUpperCase(),
    accept || '',
    contentType || '',
    bodyLength,
    String(timestamp),
    bodyHash,
    canonicalUrl,
  ].join('\n');
}

function generateXTrSignature(method, accept, contentType, url, body = null, useAltKey = false, ts = Date.now()) {
  const canonical = canonicalString(method, accept, contentType, url, body, ts);
  const secret = useAltKey ? SECRET_KEY_ALT : SECRET_KEY_DEFAULT;
  const signature = crypto.createHmac('md5', secret).update(canonical, 'utf8').digest('base64');
  return `${ts}|2|${signature}`;
}

function buildHeaders(method, url, { contentType = 'application/json', accept = 'application/json', body = null, useToken = true } = {}) {
  const ts = Date.now();
  const map = {
    'user-agent': movieboxUserAgent,
    accept,
    'content-type': contentType,
    connection: 'keep-alive',
    'x-client-token': generateXClientToken(ts),
    'x-tr-signature': generateXTrSignature(method, accept, contentType, url, body, false, ts),
    'x-client-info': movieboxClientInfo,
    'x-client-status': '0',
    'x-client-build': MOVIEBOX_CLIENT_BUILD,
  };
  if (useToken && state.bearerToken) {
    map.Authorization = `Bearer ${state.bearerToken}`;
  }
  return map;
}

// --- token -------------------------------------------------------------

const state = { bearerToken: null, gslbHosts: null };

function jwtExpiry(token) {
  try {
    const payload = token.split('.')[1] || '';
    const json = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return json.exp || 0;
  } catch {
    return 0;
  }
}

function isTokenValid(token) {
  if (!token) return false;
  return jwtExpiry(token) > Math.floor(Date.now() / 1000) + 3600;
}

function persistTokenFromXUser(xUserHeader) {
  if (!xUserHeader) return;
  try {
    const token = JSON.parse(xUserHeader)?.token;
    if (token && isTokenValid(token)) state.bearerToken = token;
  } catch {
    /* ignore */
  }
}

async function ensureToken(forceRefresh = false) {
  if (!forceRefresh && isTokenValid(state.bearerToken)) return state.bearerToken;

  // Official guest login; returns the token in the response body.
  for (const host of MOVIEBOX_HOST_POOL) {
    try {
      const loginUrl = `${host}/wefeed-mobile-bff/user-api/visitor-login`;
      const resp = await postText(loginUrl, {
        headers: buildHeaders('POST', loginUrl, { body: '{}', useToken: false }),
        body: '{}',
      });
      const token = JSON.parse(resp.body)?.data?.token;
      if (token) {
        state.bearerToken = token;
        return token;
      }
    } catch {
      /* try next host */
    }
  }

  // Fallback: ranking-list sets the token in the x-user response header.
  for (const rankUrl of MOVIEBOX_HOST_POOL.map(
    (h) => `${h}/wefeed-mobile-bff/tab/ranking-list?tabId=0&categoryType=4516404531735022304&page=1&perPage=1`
  )) {
    try {
      const resp = await getText(rankUrl, { headers: buildHeaders('GET', rankUrl, { useToken: false }) });
      persistTokenFromXUser(resp.headers['x-user']);
      if (state.bearerToken) return state.bearerToken;
    } catch {
      /* try next */
    }
  }
  return null;
}

// --- GSLB --------------------------------------------------------------

async function gslbHosts() {
  if (state.gslbHosts) return state.gslbHosts;
  try {
    const domainsJson = MOVIEBOX_HOST_POOL.map((h) => `"${h.replace('https://', '')}"`).join(',');
    const key = sha256Hex(deviceId);
    const payload = JSON.stringify({
      appId: 'com.community.oneroom',
      key,
      oldKey: '',
      domains: JSON.parse(`[${domainsJson}]`),
      mcc: '404',
      locale: 'IN',
      language: 'en',
      model: 'Pixel 8',
    });
    const resp = await postText(MOVIEBOX_GSLB_URL, {
      headers: {
        accept: '*/*',
        'Content-Type': 'application/json',
        'X-Gslb-Sign': sha256Hex('com.community.oneroom' + key),
        'User-Agent': 'okhttp/4.11.0',
      },
      body: payload,
    });
    const pairs = JSON.parse(resp.body)?.data?.domainPairs || {};
    const hosts = [];
    for (const [name, mapped] of Object.entries(pairs)) {
      const url = `https://${mapped && mapped !== '' ? mapped : name}`;
      if (!hosts.includes(url)) hosts.push(url);
    }
    state.gslbHosts = hosts;
    return hosts;
  } catch {
    return [];
  }
}

// --- helpers -----------------------------------------------------------

function cleanTitleForMatch(s) {
  return (s || '')
    .toLowerCase()
    .replace(/\[.*?]/g, ' ')
    .replace(/\(.*?\)/g, ' ')
    .replace(/\b(dub|dubbed|hd|4k|hindi|tamil|telugu|dual audio|season|episode|s\d+|e\d+)\b/gi, ' ')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function highestQuality(input) {
  for (const label of ['2160', '1440', '1080', '720', '480', '360', '240']) {
    if (input && input.toLowerCase().includes(label)) return parseInt(label, 10);
  }
  return null;
}

// Extract the signed MPD resource out of Edge-Cache-Cookie / CloudFront-Policy.
function extractPolicyResource(signCookie) {
  if (!signCookie) return null;
  try {
    const edgeMatch = signCookie.match(/Edge-Cache-Cookie=urlprefix=([^:;\s]+)/);
    if (edgeMatch) {
      const decoded = Buffer.from(edgeMatch[1].replace(/_/g, '/').replace(/-/g, '+'), 'base64')
        .toString('utf8')
        .replace(/\/+$/, '');
      return `${decoded}/index.mpd`;
    }
    const cfMatch = signCookie.match(/CloudFront-Policy=([^;]+)/);
    if (!cfMatch) return null;
    const policyRaw = cfMatch[1];
    const std = policyRaw.replace(/-/g, '+').replace(/~/g, '/').replace(/_/g, '=');
    const json = Buffer.from(std, 'base64').toString('utf8');
    const resource = JSON.parse(json)?.Statement?.[0]?.Resource;
    if (!resource) return null;
    const trimmed = resource.replace(/\*+$/, '').replace(/\/+$/, '');
    return /\.mpd$/i.test(trimmed) ? trimmed : `${trimmed}/index.mpd`;
  } catch {
    return null;
  }
}

// --- main flow ---------------------------------------------------------

export async function find(ctx, emit) {
  const title = ctx.title;
  if (!title) return;

  const cleanQuery = title
    .replace(/\[.*?]/g, '')
    .replace(/\(.*?\)/g, '')
    .replace(/\b(dub|dubbed|hd|4k|hindi|tamil|telugu|dual audio)\b/gi, '')
    .trim();
  const searchQuery = cleanQuery || title;

  const url = `${MOVIEBOX_HOST}/wefeed-mobile-bff/subject-api/search/v2`;
  const jsonBody = JSON.stringify({ page: 1, perPage: 20, keyword: searchQuery });

  let resp;
  try {
    resp = await postText(url, {
      headers: buildHeaders('POST', url, { contentType: 'application/json; charset=utf-8', body: jsonBody }),
      body: jsonBody,
    });
    if (resp.statusCode === 401 || resp.statusCode === 441) {
      await ensureToken(true);
      resp = await postText(url, {
        headers: buildHeaders('POST', url, { contentType: 'application/json; charset=utf-8', body: jsonBody }),
        body: jsonBody,
      });
    }
    if (resp.statusCode !== 200) return;
  } catch {
    return;
  }

  persistTokenFromXUser(resp.headers['x-user']);
  const results = JSON.parse(resp.body)?.data?.results;
  if (!results) return;

  const isTv = ctx.season != null && ctx.season > 0;
  const targetClean = cleanTitleForMatch(cleanQuery);
  const orgClean = ctx.orgTitle ? cleanTitleForMatch(ctx.orgTitle) : '';

  const candidates = [];

  const collect = (resultList, baseScore) => {
    for (const result of resultList || []) {
      for (const subject of result?.subjects || []) {
        const sTitle = subject.title;
        const sId = subject.subjectId;
        if (!sTitle || !sId) continue;
        const sType = subject.subjectType ?? 1;
        const sYear = parseInt((subject.releaseDate || '').slice(0, 4), 10) || null;
        const isSubjectTv = sType === 2 || sType === 7;
        const sClean = cleanTitleForMatch(sTitle);

        let score = baseScore;
        const isExactTitle = sClean === targetClean || (orgClean && sClean === orgClean);
        const isFullTitleEquals =
          sTitle.toLowerCase() === (title || '').toLowerCase() ||
          (ctx.orgTitle && sTitle.toLowerCase() === ctx.orgTitle.toLowerCase());

        if (isExactTitle || isFullTitleEquals) {
          score += 100;
        } else if (targetClean && (sClean.includes(targetClean) || targetClean.includes(sClean))) {
          score += 50;
        } else if (orgClean && (sClean.includes(orgClean) || orgClean.includes(sClean))) {
          score += 45;
        } else {
          continue;
        }

        score += isTv === isSubjectTv ? 40 : -30;

        if (ctx.year != null && sYear != null) {
          if (sYear === ctx.year) score += 50;
          else if (Math.abs(sYear - ctx.year) <= 1) score += 20;
          else score -= 40;
        }
        candidates.push({ id: sId, title: sTitle, score });
      }
    }
  };

  collect(results, 0);

  if (candidates.length === 0 && ctx.orgTitle && ctx.orgTitle !== title && ctx.orgTitle !== searchQuery) {
    try {
      const fallbackBody = JSON.stringify({ page: 1, perPage: 20, keyword: ctx.orgTitle });
      const fbResp = await postText(url, {
        headers: buildHeaders('POST', url, { contentType: 'application/json; charset=utf-8', body: fallbackBody }),
        body: fallbackBody,
      });
      if (fbResp.statusCode === 200) {
        persistTokenFromXUser(fbResp.headers['x-user']);
        // Fallback candidates use the org-title scoring baseline.
        const saved = targetClean;
        const t = cleanTitleForMatch(ctx.orgTitle);
        for (const result of JSON.parse(fbResp.body)?.data?.results || []) {
          for (const subject of result?.subjects || []) {
            const sId = subject.subjectId;
            const sTitle = subject.title;
            if (!sId || !sTitle) continue;
            const sType = subject.subjectType ?? 1;
            const sYear = parseInt((subject.releaseDate || '').slice(0, 4), 10) || null;
            const isSubjectTv = sType === 2 || sType === 7;
            const sClean = cleanTitleForMatch(sTitle);
            let score = 40;
            if (sClean === t || (saved && sClean === saved)) score += 60;
            score += isTv === isSubjectTv ? 30 : -20;
            if (ctx.year != null && sYear != null && sYear === ctx.year) score += 40;
            candidates.push({ id: sId, title: sTitle, score });
          }
        }
      }
    } catch {
      /* skip fallback */
    }
  }

  if (candidates.length === 0) return;

  candidates.sort((a, b) => b.score - a.score);
  const best = candidates[0];
  const topCandidates = best.score >= 100 ? [best] : candidates.slice(0, 2);

  for (const candidate of topCandidates) {
    try {
      await emitForCandidate(candidate, ctx, emit);
    } catch {
      /* skip candidate */
    }
  }
}

async function emitForCandidate(candidate, ctx, emit) {
  const subjectUrl = `${MOVIEBOX_HOST}/wefeed-mobile-bff/subject-api/get?subjectId=${candidate.id}`;
  let subjectRes;
  try {
    subjectRes = await getText(subjectUrl, { headers: buildHeaders('GET', subjectUrl) });
    if (subjectRes.statusCode === 401 || subjectRes.statusCode === 441) {
      await ensureToken(true);
      subjectRes = await getText(subjectUrl, { headers: buildHeaders('GET', subjectUrl) });
    }
    if (subjectRes.statusCode !== 200) return;
  } catch {
    return;
  }
  persistTokenFromXUser(subjectRes.headers['x-user']);

  const subjectData = JSON.parse(subjectRes.body)?.data;
  const subjectList = [];
  let originalLanguageName = 'Original';

  for (const dub of subjectData?.dubs || []) {
    const dubId = dub?.subjectId;
    const lanName = dub?.lanName;
    if (dubId && lanName) {
      if (dubId === candidate.id) originalLanguageName = lanName;
      else subjectList.push([dubId, lanName]);
    }
  }
  subjectList.unshift([candidate.id, originalLanguageName]);

  for (const [subjectId, language] of subjectList) {
    try {
      const cleanLang = language.replace(/dub/gi, '').replace(/Audio/gi, '').trim();
      const audioLabel = `${cleanLang} Audio`;
      const emittedUrls = new Set();
      const sniffedSources = new Set();

      const targetSe = ctx.season ?? 0;
      const targetEp = ctx.episode ?? 0;
      const videoNodes = [];

      // resourceDetectors fallback
      try {
        const fbUrl = `${MOVIEBOX_HOST}/wefeed-mobile-bff/subject-api/get?subjectId=${subjectId}`;
        const fbResp = await getText(fbUrl, { headers: buildHeaders('GET', fbUrl) });
        if (fbResp.statusCode === 200) {
          for (const detector of JSON.parse(fbResp.body)?.data?.resourceDetectors || []) {
            for (const node of detector?.resolutionList || []) videoNodes.push(node);
          }
        }
      } catch {
        /* skip detectors */
      }

      // Paged resource listing at 480 and 1080
      for (const resolution of ['480', '1080']) {
        for (let page = 1; page <= 5; page++) {
          const resUrl = `${MOVIEBOX_HOST}/wefeed-mobile-bff/subject-api/resource?subjectId=${subjectId}&page=${page}&perPage=20&resolution=${resolution}&all=0&pagerMode=0`;
          let resResp;
          try {
            resResp = await getText(resUrl, { headers: buildHeaders('GET', resUrl) });
          } catch {
            break;
          }
          if (resResp.statusCode !== 200) break;
          const resData = JSON.parse(resResp.body)?.data;
          if (!resData) break;
          const list = resData.list;
          if (!Array.isArray(list) || list.length === 0) break;
          videoNodes.push(...list);
          if (resData?.pager?.hasMore !== true) break;
        }
      }

      // MP4 resources
      for (const video of videoNodes) {
        let link = video?.resourceLink || '';
        if (!link) continue;
        let sizeBytes = parseInt(video?.size, 10) || 0;
        const durationSeconds = video?.duration ?? 0;
        if (durationSeconds >= 1 && durationSeconds <= 299) continue;

        const sourceUrl = video?.sourceUrl || null;
        if (sizeBytes >= 1 && sizeBytes <= 10_000_000 && sourceUrl && !sniffedSources.has(sourceUrl)) {
          sniffedSources.add(sourceUrl);
          try {
            const sniffUrl = `${MOVIEBOX_HOST}/wefeed-mobile-bff/sniff/config?linkUrl=${encodeURIComponent(sourceUrl)}&subjectId=${subjectId}`;
            const sniffResp = await getText(sniffUrl, { headers: buildHeaders('GET', sniffUrl) });
            if (sniffResp.statusCode === 200) {
              const sniffData = JSON.parse(sniffResp.body)?.data;
              const sniffedUrl = sniffData?.downloadUrl || '';
              const sniffedSize = parseInt(sniffData?.resource?.size, 10) || 0;
              if (sniffedUrl && sniffedSize > 10_000_000) {
                link = sniffedUrl;
                sizeBytes = sniffedSize;
              }
            }
          } catch {
            /* skip sniff */
          }
        }
        if (sizeBytes >= 1 && sizeBytes <= 10_000_000) continue;
        const dedupeKey = link.split('?')[0];
        if (emittedUrls.has(dedupeKey)) continue;
        emittedUrls.add(dedupeKey);

        const quality = video?.resolution ?? 0;
        const se = video?.se;
        const ep = video?.ep;

        if ((targetSe === 0 && targetEp === 0) || (se === targetSe && ep === targetEp)) {
          const codec = video?.codecName ? `(${String(video.codecName).toUpperCase()}) ` : '';
          emit({
            source: `MovieBox MP4 ${audioLabel}`,
            title: `MovieBox MP4 ${codec}(${audioLabel})`,
            url: link,
            quality: quality || null,
            kind: 'video',
            headers: { 'User-Agent': movieboxUserAgent },
          });
        }
      }

      // DASH/HLS play-info streams
      const playUrl = `${MOVIEBOX_HOST}/wefeed-mobile-bff/subject-api/play-info?subjectId=${subjectId}&se=${ctx.season ?? 0}&ep=${ctx.episode ?? 0}`;
      let playRes;
      try {
        playRes = await getText(playUrl, { headers: buildHeaders('GET', playUrl) });
        if (playRes.statusCode === 401 || playRes.statusCode === 441) {
          await ensureToken(true);
          playRes = await getText(playUrl, { headers: buildHeaders('GET', playUrl) });
        }
        if (playRes.statusCode === 403 || playRes.statusCode === 407) {
          const altHosts = [...(await gslbHosts()), ...MOVIEBOX_HOST_POOL];
          for (const host of altHosts) {
            if (host === MOVIEBOX_HOST) continue;
            const altUrl = `${host}/wefeed-mobile-bff/subject-api/play-info?subjectId=${subjectId}&se=${ctx.season ?? 0}&ep=${ctx.episode ?? 0}`;
            try {
              const altResp = await getText(altUrl, { headers: buildHeaders('GET', altUrl) });
              if (altResp.statusCode === 200) {
                playRes = altResp;
                break;
              }
            } catch {
              /* next host */
            }
          }
        }
      } catch {
        return;
      }

      if (playRes.statusCode === 200) {
        persistTokenFromXUser(playRes.headers['x-user']);
        const streams = JSON.parse(playRes.body)?.data?.streams || [];

        const sortedStreams = [...streams].sort((a, b) => {
          const score = (s) =>
            (s?.url || '').toLowerCase().includes('.mpd') || (s?.format || '').toLowerCase() === 'dash' ? 1 : 0;
          return score(b) - score(a);
        });

        for (const stream of sortedStreams) {
          const rawStreamUrl = stream?.url;
          if (!rawStreamUrl) continue;
          const format = stream?.format || '';
          const signCookie = stream?.signCookie || null;
          const quality = highestQuality(stream?.resolutions || '');

          const policyUrl = extractPolicyResource(signCookie);
          const finalStreamUrl = policyUrl || rawStreamUrl;

          const durationSeconds = stream?.duration ?? 0;
          if (finalStreamUrl.includes('b164fbfb4347792950bdfbfb563d39d9')) continue;
          if (durationSeconds >= 1 && durationSeconds <= 299) continue;

          const isDash = finalStreamUrl.toLowerCase().includes('.mpd') || format.toLowerCase() === 'dash';
          const isHls = format.toLowerCase() === 'hls' || finalStreamUrl.toLowerCase().includes('.m3u8');
          const formatName = isDash ? 'DASH' : isHls ? 'HLS' : 'MP4';
          const linkName = `MovieBox ${formatName} ${audioLabel}`;

          const headers = { 'User-Agent': movieboxUserAgent, Accept: '*/*' };
          if (signCookie) headers.Cookie = signCookie;

          emit({
            source: linkName,
            title: linkName,
            url: finalStreamUrl,
            quality,
            kind: isDash ? 'dash' : isHls ? 'm3u8' : 'video',
            headers,
          });
          emittedUrls.add(finalStreamUrl.split('?')[0]);
        }
      }
    } catch {
      /* skip subject */
    }
  }
}
