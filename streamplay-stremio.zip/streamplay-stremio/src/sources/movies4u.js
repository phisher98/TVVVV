// Movies4u source - port of invokeMovies4u (StreamPlayExtractor.kt:7239-7344).
// lookup.php Typesense (or ?s= search) + IMDb verification -> watch/download
// buttons -> inner download page -> router. TV: season blocks -> episode block.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'movies4u';

export async function find(ctx, emit) {
  const api = ((await getDomain('movies4u')) || '').replace(/\/$/, '');
  if (!api || !ctx.title) return;

  const searchQuery = `${ctx.title} ${ctx.year ?? ''}`.trim();

  const postUrls = [];
  try {
    const jsonText = (await getText(`${api}/lookup.php?q=${encodeURIComponent(searchQuery)}&page=1&per_page=10`)).body;
    const hits = JSON.parse(jsonText)?.hits || [];
    for (const hit of hits) {
      const permalink = (hit?.permalink || '').trim();
      if (permalink) postUrls.push(/^https?:/i.test(permalink) ? permalink : `${api}${permalink}`);
    }
  } catch {
    /* fall through */
  }

  if (postUrls.length === 0) {
    try {
      const searchDoc = (await getDoc(`${api}/?s=${encodeURIComponent(searchQuery)}`)).doc;
      searchDoc('article h2 a, article h3 a').each((_i, el) => {
        const href = searchDoc(el).attr('href');
        if (href) postUrls.push(href);
      });
    } catch {
      return;
    }
  }

  const jobs = postUrls.map(async (postUrl) => {
    try {
      const postDoc = (await getDoc(postUrl)).doc;
      const imdbId = postDoc('p a')
        .filter((_i, el) => /IMDb Rating/i.text ? false : postDoc(el).text().includes('IMDb Rating'))
        .first()
        .attr('href') || '';
      const extracted = imdbId.includes('imdb.com/title/') ? imdbId.split('title/').pop().split('/')[0] : '';

      if (extracted && extracted !== ctx.imdbId) return;

      if (ctx.season == null) {
        const watchLinks = [];
        postDoc('div.watch-btns-div a[href]').each((_i, el) => {
          const href = postDoc(el).attr('href');
          if (href) watchLinks.push(href);
        });
        for (const watchLink of watchLinks) {
          await routeExtractor(watchLink, 'Movies4u', emit);
        }

        const innerUrl =
          postDoc('div.download-links-div a.btn').first().attr('href') ||
          postDoc('div.downloads-btns-div a[href]').first().attr('href') ||
          '';
        if (innerUrl) {
          const innerDoc = (await getDoc(innerUrl)).doc;
          const sourceLinks = [];
          innerDoc('div.downloads-btns-div a.btn, div.downloads-btns-div a[href]').each((_i, el) => {
            const href = innerDoc(el).attr('href');
            if (href) sourceLinks.push(href);
          });
          for (const sourceLink of sourceLinks) {
            await routeExtractor(sourceLink, 'Movies4u', emit);
          }
        }
      } else {
        const seasonBlocks = postDoc('div.downloads-btns-div').toArray();
        for (const block of seasonBlocks) {
          const $block = postDoc(block);
          const headerText = $block.prev().text() || '';
          if (!headerText.toLowerCase().includes(`season ${ctx.season}`)) continue;

          const seasonBtn = $block
            .find('a.btn')
            .toArray()
            .find((el) => !/zip/i.test(postDoc(el).text()));
          const seasonLink = seasonBtn ? postDoc(seasonBtn).attr('href') : null;
          if (!seasonLink) continue;

          const episodeDoc = (await getDoc(seasonLink)).doc;
          const episodeBlocks = episodeDoc('div.downloads-btns-div').toArray();

          if (ctx.episode != null && ctx.episode >= 1 && ctx.episode <= episodeBlocks.length) {
            const episodeBlock = episodeBlocks[ctx.episode - 1];
            const epLinks = [];
            episodeDoc(episodeBlock)
              .find('a.btn')
              .each((_i, el) => {
                const href = episodeDoc(el).attr('href');
                if (href) epLinks.push(href);
              });
            for (const sourceLink of epLinks) {
              await routeExtractor(sourceLink, 'Movies4u', emit);
            }
          }
        }
      }
    } catch {
      /* skip post */
    }
  });

  await Promise.allSettled(jobs);
}
