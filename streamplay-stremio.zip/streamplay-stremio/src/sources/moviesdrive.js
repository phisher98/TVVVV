// MoviesDrive source - port of invokeMoviesdrive (StreamPlayExtractor.kt:4612).
// search.php JSON (same Typesense shape) -> h5 links -> extractMdrive -> router.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { extractMdrive } from '../extractors/mdrive.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'moviesdrive';

function episodeSlug(season, episode) {
  const s = season != null && season < 10 ? `0${season}` : `${season ?? ''}`;
  const e = episode != null && episode < 10 ? `0${episode}` : `${episode ?? ''}`;
  return [s, e];
}

export async function find(ctx, emit) {
  const domain = (await getDomain('moviesdrive')) || 'https://new4.moviesdrive.christmas';
  const imdb = ctx.imdbId?.trim() || '';
  const title = ctx.title?.trim() || '';
  if (!imdb && !title) return;

  const headers = { Referer: `${domain}/` };

  async function searchApi(query) {
    try {
      const resp = await getText(`${domain}/search.php?q=${encodeURIComponent(query)}&page=1`, {
        headers,
        timeout: 15000,
      });
      return JSON.parse(resp.body);
    } catch {
      return null;
    }
  }

  let match = null;

  if (imdb) {
    const root = await searchApi(imdb);
    const hits = root?.hits || [];
    match = hits
      .map((h) => h?.document)
      .find((d) => {
        const docImdb = (d?.imdb_id || '').trim();
        const permalink = (d?.permalink || '').trim();
        return (
          (docImdb && docImdb.toLowerCase() === imdb.toLowerCase()) ||
          permalink.toLowerCase().includes(imdb.toLowerCase())
        );
      });
  }

  if (!match && title) {
    const root = await searchApi(title);
    const docs = (root?.hits || []).map((h) => h?.document).filter(Boolean);

    const normTitle = title.toLowerCase().replace(/[^a-z0-9]/g, '');
    const [sSlug] = ctx.season != null ? episodeSlug(ctx.season) : [null];
    const seasonPatterns =
      ctx.season != null
        ? [`season ${ctx.season}`, `season ${sSlug}`, `s${sSlug}`, `s${ctx.season}`]
        : null;

    if (seasonPatterns) {
      match = docs.find((d) => {
        const postTitle = d.post_title || '';
        const permalink = d.permalink || '';
        const normDocTitle = postTitle.toLowerCase().replace(/[^a-z0-9]/g, '');
        const titleMatches =
          normDocTitle.includes(normTitle) ||
          postTitle.toLowerCase().includes(title.toLowerCase()) ||
          permalink.toLowerCase().includes(title.replace(/ /g, '-').toLowerCase());
        const seasonMatches = seasonPatterns.some(
          (p) => postTitle.toLowerCase().includes(p.toLowerCase()) || permalink.toLowerCase().includes(p.toLowerCase())
        );
        return titleMatches && seasonMatches;
      });
    }

    if (!match) {
      match = docs.find((d) => {
        const postTitle = d.post_title || '';
        const permalink = d.permalink || '';
        const normDocTitle = postTitle.toLowerCase().replace(/[^a-z0-9]/g, '');
        return (
          normDocTitle.includes(normTitle) ||
          postTitle.toLowerCase().includes(title.toLowerCase()) ||
          permalink.toLowerCase().includes(title.replace(/ /g, '-').toLowerCase())
        );
      });
    }
  }

  if (!match) return;

  const permalink = match.permalink || '';
  if (!permalink) return;
  const href = /^https?:/i.test(permalink) ? permalink : `${domain.replace(/\/$/, '')}/${permalink.replace(/^\//, '')}`;

  const mainDoc = (await getDoc(href, { headers, timeout: 15000 })).doc;
  const seenUrls = new Set();
  const jobs = [];

  const pushServers = async (rawUrl) => {
    const servers = await extractMdrive(rawUrl);
    const targets = servers.length > 0 ? servers : [rawUrl];
    for (const server of targets) {
      if (!seenUrls.has(server)) {
        seenUrls.add(server);
        await routeExtractor(server, 'MoviesDrive', emit);
      }
    }
  };

  if (ctx.season == null) {
    const links = [];
    mainDoc('h5 > a').each((_i, el) => {
      const href2 = mainDoc(el).attr('href');
      if (href2 && !links.includes(href2)) links.push(href2);
    });
    for (const linkHref of links) {
      jobs.push(pushServers(linkHref));
    }
  } else {
    const [sSlug, eSlug] = episodeSlug(ctx.season, ctx.episode);
    const stag = `Season ${ctx.season}|S${sSlug}`;
    const sepRe = new RegExp(`\\b(?:ep|episode|e)\\s*0?${ctx.episode}\\b|s0?${ctx.season}\\s*e0?${ctx.episode}\\b`, 'i');

    const entries = mainDoc('h5').toArray().filter((el) => {
      const text = mainDoc(el).text();
      return text.includes(`Season ${ctx.season}`) || text.includes(`S${sSlug}`);
    });

    for (const entry of entries) {
      const $entry = mainDoc(entry);
      const epListHref =
        $entry.find('a').first().attr('href') || $entry.next().find('a').first().attr('href') || '';
      if (!epListHref) continue;

      try {
        const doc = (await getDoc(epListHref, { headers, timeout: 15000 })).doc;
        const allH5 = doc('h5, h4, h3, p').toArray();
        const fEp = allH5.find((el) => sepRe.test(doc(el).text()));
        if (!fEp) continue;

        const linklist = [];
        let sibling = doc(fEp).next();
        while (sibling.length > 0 && !/^\s*(EP\d+|Episode\s*\d+|S\d+E\d+)/i.test(sibling.text())) {
          sibling.find('a[href]').each((_i, a) => {
            const l = (doc(a).attr('href') || '').trim();
            if (l) linklist.push(l);
          });
          sibling = sibling.next();
        }

        if (linklist.length === 0) {
          const n1 = doc(fEp).next().find('a').first().attr('href');
          const n2 = doc(fEp).next().next().find('a').first().attr('href');
          if (n1) linklist.push(n1);
          if (n2) linklist.push(n2);
        }

        for (const rawUrl of [...new Set(linklist.filter(Boolean))]) {
          jobs.push(pushServers(rawUrl));
        }
      } catch {
        /* skip entry */
      }
    }
  }

  await Promise.allSettled(jobs);
}
