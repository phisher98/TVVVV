// MoviesMod source - port of invokeMoviesmod/invokeModflix
// (StreamPlayExtractor.kt:4035-4095). search/<imdb> -> post page -> quality
// headings -> Download link -> intermediate page -> hrefli bypass -> router.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';
import { bypassHrefli } from '../extractors/hrefli.js';

export const id = 'moviesmod';

export async function find(ctx, emit) {
  const api = (await getDomain('moviesmod')) || '';
  if (!api || !ctx.imdbId) return;

  const url = ctx.season == null ? `${api}/search/${ctx.imdbId}` : `${api}/search/${ctx.imdbId} ${ctx.season}`;

  let href;
  try {
    href = (await getDoc(url)).doc('#content_box article > a').first().attr('href');
  } catch {
    return;
  }
  if (!href) return;

  const hTag = ctx.season == null ? 'h4' : 'h3';
  const aTag = ctx.season == null ? 'Download' : 'Episode';
  const sTag = ctx.season == null ? '' : `(S0${ctx.season}|Season ${ctx.season})`;

  const doc = (await getDoc(href)).doc;

  const entries = doc(`div.thecontent ${hTag}`)
    .toArray()
    .filter((el) => {
      const text = doc(el).text();
      return (
        new RegExp(`${sTag}.*(480p|720p|1080p|2160p)`, 'i').test(text) &&
        !text.toLowerCase().includes('moviesmod')
      );
    });

  const jobs = entries.map(async (entry) => {
    try {
      const link = doc(entry)
        .next()
        .find(`a:contains(${aTag})`)
        .first()
        .attr('href')?.split('=')
        .pop() || '';
      if (!link) return;

      const selector = ctx.season == null ? 'p a.maxbutton' : `h3 a:matches(Episode ${ctx.episode})`;
      const source = (await getDoc(link)).doc(selector).first().attr('href');
      if (!source) return;

      const bypassedLink = (await bypassHrefli(source)) || source;
      await routeExtractor(bypassedLink, 'Moviesmod', emit);
    } catch {
      /* skip entry */
    }
  });

  await Promise.allSettled(jobs);
}
