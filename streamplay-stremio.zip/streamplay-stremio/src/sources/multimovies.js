// MultiMovies source - port of invokeMultimovies (StreamPlayExtractor.kt:299-506).
// Slug URL or poster-card search -> server chips / JSON embed urls / dooplay
// ajax -> modiplay inner servers (filemoon) -> host router (unpack or skip).
import { getDoc, postText } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'multimovies';

function createSlug(title) {
  const slug = (title || '')
    .split('')
    .filter((c) => /\s|[a-zA-Z0-9]/.test(c))
    .join('')
    .trim()
    .replace(/\s+/g, '-');
  return slug || null;
}

export async function find(ctx, emit) {
  const api = (await getDomain('MultiMovies'))?.replace(/\/$/, '') || '';
  if (!api || !ctx.title) return;

  const fixTitle = createSlug(ctx.title);
  if (!fixTitle) return;

  let targetUrl = null;

  if (ctx.season == null) {
    const directMovieUrl = `${api}/movie/${fixTitle}`;
    let directOk = false;
    try {
      const directRes = (await getDoc(directMovieUrl)).doc;
      const text = directRes.text() || directRes.root().text() || '';
      directOk = !/just a moment/i.test(directRes.html()) && !/page not found/i.test(directRes.html());
      if (directOk) targetUrl = directMovieUrl;
    } catch {
      directOk = false;
    }

    if (!directOk) {
      try {
        const searchRes = (await getDoc(`${api}/search?q=${encodeURIComponent(ctx.title.trim())}`)).doc;
        const cards = searchRes('article.poster-card').toArray();
        const matchingCard =
          cards.find((card) => {
            const cardHref = searchRes(card).find('.poster-caption a, a.poster-art').first().attr('href') || '';
            const cardTitle = (searchRes(card).find('.poster-caption a').first().text() || '').trim();
            const meta = searchRes(card).find('.poster-meta').first().text() || '';
            const isMovie = cardHref.includes('/movie/') || /movie/i.test(meta);
            const titleMatch = cardTitle.toLowerCase() === ctx.title.toLowerCase() || cardTitle.includes(ctx.title);
            const yearMatch = ctx.year == null || meta.includes(String(ctx.year));
            return isMovie && titleMatch && yearMatch;
          }) ||
          cards.find((card) => {
            const cardHref = searchRes(card).find('.poster-caption a, a.poster-art').first().attr('href') || '';
            return cardHref.includes('/movie/');
          });
        const href = matchingCard
          ? searchRes(matchingCard).find('.poster-caption a, a.poster-art').first().attr('href')
          : '';
        if (href) targetUrl = /^https?:/i.test(href) ? href : `${api}${href}`;
      } catch {
        /* skip search */
      }
    }
  } else {
    let seriesHref = null;
    try {
      const searchUrl = `${api}/search?q=${encodeURIComponent(ctx.title.trim())}`;
      const searchRes = (await getDoc(searchUrl)).doc;
      const cards = searchRes('article.poster-card').toArray();
      const matchingCard =
        cards.find((card) => {
          const cardHref = searchRes(card).find('.poster-caption a, a.poster-art').first().attr('href') || '';
          const cardTitle = (searchRes(card).find('.poster-caption a').first().text() || '').trim();
          const meta = searchRes(card).find('.poster-meta').first().text() || '';
          const isSeries = cardHref.includes('/series/') || /series/i.test(meta);
          const titleMatch = cardTitle.toLowerCase() === ctx.title.toLowerCase() || cardTitle.includes(ctx.title);
          return isSeries && titleMatch;
        }) ||
        cards.find((card) => {
          const cardHref = searchRes(card).find('.poster-caption a, a.poster-art').first().attr('href') || '';
          return cardHref.includes('/series/');
        });
      const href = matchingCard
        ? searchRes(matchingCard).find('.poster-caption a, a.poster-art').first().attr('href')?.trimEnd('/')
        : '';
      if (href) seriesHref = href;
    } catch {
      /* skip search */
    }

    if (seriesHref) {
      targetUrl = /^https?:/i.test(seriesHref)
        ? `${seriesHref}/season/${ctx.season}/episode/${ctx.episode}`
        : `${api}${seriesHref}/season/${ctx.season}/episode/${ctx.episode}`;
    } else {
      targetUrl = `${api}/series/${fixTitle}/season/${ctx.season}/episode/${ctx.episode}`;
    }
  }

  const finalUrl = targetUrl || (ctx.season == null ? `${api}/movies/${fixTitle}` : `${api}/episodes/${fixTitle}-${ctx.season}x${ctx.episode}`);

  let doc;
  try {
    doc = (await getDoc(finalUrl)).doc;
  } catch {
    return;
  }
  if (/just a moment/i.test(doc.html())) return; // Cloudflare - can't bypass server-side

  const embedUrls = [];

  doc('.server-grid button.server-chip, button.server-chip').each((_i, el) => {
    const u = (doc(el).attr('data-url') || '').trim();
    if (u.startsWith('http') && !u.includes('{tmdbId}')) embedUrls.push(u);
  });

  for (const m of doc.html().matchAll(/"url"\s*:\s*"([^"]+)"/g)) {
    const u = m[1].replace(/\\\//g, '/').trim();
    if (u.startsWith('http') && !u.includes('{tmdbId}') && !embedUrls.includes(u)) embedUrls.push(u);
  }

  // dooplay ajax fallback
  if (embedUrls.length === 0) {
    const playerOptions = [];
    doc('ul#playeroptionsul li, li.dooplay_player_option').each((_i, el) => {
      playerOptions.push([doc(el).attr('data-post'), doc(el).attr('data-nume'), doc(el).attr('data-type')]);
    });

    for (const [postId, nume, type] of playerOptions) {
      if (/trailer/i.test(nume || '')) continue;
      try {
        const postResponse = await postText(`${api}/wp-admin/admin-ajax.php`, {
          form: { action: 'doo_player_ajax', post: postId, nume, type },
          referer: finalUrl,
          headers: { 'X-Requested-With': 'XMLHttpRequest' },
        });
        if (postResponse.statusCode !== 200) continue;
        const responseData = JSON.parse(postResponse.body);
        const embedUrlRaw = responseData?.embed_url || '';
        const link = embedUrlRaw.includes('<iframe')
          ? embedUrlRaw.match(/src=["']([^"']+)["']/)?.[1]
          : embedUrlRaw.trim().replace(/^"|"$/g, '');
        if (link && link.startsWith('http') && !/youtube/i.test(link)) embedUrls.push(link);
      } catch {
        /* skip option */
      }
    }
  }

  const jobs = [...new Set(embedUrls)]
    .filter((link) => !/youtube/i.test(link))
    .map(async (link) => {
      try {
        if (/modiplay/i.test(link)) {
          const modiplayRes = (await getDoc(link, { referer: `${api}/` })).doc;
          const innerUrls = [];
          for (const m of modiplayRes.html().matchAll(/switchServer\('([^']*)','([^']*)','([^']*)','([^']*)'/g)) {
            const u = m[1].trim();
            const plat = m[2].trim();
            const code = m[4].trim();
            if (u.startsWith('http')) innerUrls.push(u);
            else if (/^filemoon$|^byse$/i.test(plat)) innerUrls.push(`https://filemoon.sx/e/${code}`);
          }
          if (innerUrls.length > 0) {
            for (const innerLink of [...new Set(innerUrls)]) {
              await routeExtractor(innerLink, 'Multimovies', emit);
            }
          } else {
            await routeExtractor(link, 'Multimovies', emit);
          }
        } else {
          await routeExtractor(link, 'Multimovies', emit);
        }
      } catch {
        /* skip */
      }
    });

  await Promise.allSettled(jobs);
}
