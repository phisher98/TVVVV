// Nyaa torrent source, debrid-resolved. Anime-only: matches via ani.zip
// (imdb -> MAL/anilist titles), searches nyaa.si RSS, resolves magnets to
// direct streams through Real-Debrid (needs the RD key from the Keys tab).
import { getText } from '../http.js';
import { getAniZipMapping } from '../anime.js';
import { rdResolveMagnet, rdConfigured } from '../debrid.js';

export const id = 'nyaa';

const NYAA = process.env.NYAA_URL || 'https://nyaa.si';

function decodeEntities(s) {
  return (s || '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'").replace(/&#0?39;/g, "'").replace(/&amp;/g, '&');
}

function parseSizeToBytes(label) {
  const m = (label || '').match(/([\d.]+)\s*(GiB|MiB|KiB|GB|MB)/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  const unit = m[2].toUpperCase();
  if (unit.startsWith('G')) return n * 1024 ** 3;
  if (unit.startsWith('M')) return n * 1024 ** 2;
  return n * 1024;
}

// Simple RSS parse via regex (nyaa RSS is flat).
function parseNyaaRss(xml) {
  const items = [];
  for (const itemXml of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const body = itemXml[1];
    const get = (tag) => decodeEntities(body.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`))?.[1] || '');
    const title = get('title');
    const magnet = body.match(/magnet:\?xt=urn:btih:[a-zA-Z0-9]+[^<\s]*/)?.[0] || '';
    const infoHash = get('nyaa:infoHash');
    const size = get('nyaa:size');
    items.push({ title, magnet: magnet || (infoHash ? `magnet:?xt=urn:btih:${infoHash}` : ''), size });
  }
  return items.filter((i) => i.title && i.magnet);
}

export async function find(ctx, emit) {
  if (!rdConfigured()) return; // needs Real-Debrid key (Keys tab / env)
  if (!ctx.title) return;

  const mapping = ctx.imdbId ? await getAniZipMapping(ctx.imdbId).catch(() => null) : null;
  if (!mapping) return; // nyaa is anime-only

  // Search terms: anilist/ja titles from ani.zip give the best hits.
  const titles = [mapping.title, ...(mapping.titles ? Object.values(mapping.titles) : [])]
    .filter(Boolean)
    .map((t) => String(t).replace(/[^\w\s'!-]/g, ' ').replace(/\s+/g, ' ').trim())
    .filter((t) => t.length > 2);
  const queries = [...new Set(titles)].slice(0, 3);
  if (queries.length === 0) return;

  const episodeTag =
    ctx.type === 'series' && ctx.season != null
      ? ` - ${String(ctx.episode ?? 1).padStart(2, '0')}` // nyaa uses absolute ep numbering; season filter below
      : '';

  const seen = new Set();

  for (const q of queries) {
    let xml = '';
    try {
      const url = `${NYAA}/?page=rss&q=${encodeURIComponent(q + (ctx.type === 'series' ? '' : ' movie'))}&f=0&c=0_0`;
      xml = (await getText(url, { timeout: 15000 })).body;
    } catch {
      continue;
    }
    const items = parseNyaaRss(xml);

    for (const item of items.slice(0, 12)) {
      if (seen.has(item.magnet)) continue;
      seen.add(item.magnet);

      // Episode filter for series: require ep number in title when present.
      if (ctx.type === 'series' && ctx.episode != null) {
        const epMatch = item.title.match(/[-–\s]0?(\d{1,4})(?:v\d)?(?:\s|\]|$)/);
        if (epMatch && parseInt(epMatch[1], 10) !== ctx.episode) continue;
      }

      const quality = /2160|4k/i.test(item.title) ? 2160 : /1080/.test(item.title) ? 1080 : /720/.test(item.title) ? 720 : /480/.test(item.title) ? 480 : null;
      const sizeBytes = parseSizeToBytes(item.size);
      const sizeGB = sizeBytes / 1024 ** 3;
      const sizeLabel = sizeGB ? `${sizeGB.toFixed(1)}GB` : '';

      // Emit a debrid-resolving entry: URL is the magnet; the RD bridge turns
      // it into a direct stream at playback time via a resolve endpoint.
      emit({
        source: 'Nyaa-RD',
        title: `Nyaa (RD) ${quality ? quality + 'p' : ''} [${sizeLabel}]`.trim(),
        url: item.magnet,
        quality,
        kind: 'video',
        debrid: 'rd',
        sizeBytes,
        episodeTag,
      });
    }
    if (seen.size > 0) break; // first productive query is enough
  }
}
