// RogMovies source - port of invokeRogmovies (StreamPlayExtractor.kt:4226-4340).
// Same Typesense search API as VegaMovies (search.php) -> V-Cloud / G-Direct
// buttons -> vcloud extractor.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { vcloud } from '../extractors/vcloud.js';

export const id = 'rogmovies';

const VEGA_HEADERS = {
  Accept:
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
  'Accept-Language': 'en-US,en;q=0.9',
  'Cache-Control': 'no-cache',
  Pragma: 'no-cache',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'none',
  'Sec-Fetch-User': '?1',
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
  cookie: 'xla=s4t',
};

async function search(api, query) {
  try {
    const resp = await getText(`${api}/search.php?q=${query}`, { referer: api, headers: VEGA_HEADERS });
    const json = JSON.parse(resp.body);
    return (json.hits || []).map((h) => h?.document).filter(Boolean);
  } catch {
    return [];
  }
}

export async function find(ctx, emit) {
  const api = (await getDomain('rogmovies')) || '';
  if (!api) return;

  let results = ctx.imdbId ? await search(api, ctx.imdbId) : [];
  if (!results.some((d) => ctx.imdbId && (d.imdb_id || '').toLowerCase() === ctx.imdbId.toLowerCase()) && ctx.title) {
    const titleResults = await search(api, ctx.title);
    results = results.concat(titleResults);
  }
  if (results.length === 0) return;

  // Keyword scoring like the Kotlin side (all keywords -> any keyword).
  const keywords = (ctx.title || '')
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, '')
    .split(' ')
    .filter((k) => k.length > 2);

  const match =
    results.find((d) => ctx.imdbId && (d.imdb_id || '').toLowerCase() === ctx.imdbId.toLowerCase()) ||
    results.find((d) => {
      const docTitle = (d.post_title || '').toLowerCase().replace(/[^a-z0-9 ]/g, '');
      return keywords.length > 0 && keywords.every((k) => docTitle.includes(k));
    }) ||
    results.find((d) => {
      const docTitle = (d.post_title || '').toLowerCase().replace(/[^a-z0-9 ]/g, '');
      return keywords.some((k) => docTitle.includes(k));
    });
  if (!match?.permalink) return;

  const opts = { referer: api, headers: VEGA_HEADERS };
  const mainDoc = (await getDoc(api + match.permalink, opts)).doc;
  const jobs = [];

  if (ctx.season == null) {
    const pages = [];
    mainDoc('button.dwd-button').each((_i, el) => {
      const href = mainDoc(el).parent().attr('href');
      if (href && !pages.includes(href)) pages.push(href);
    });
    for (const page of pages) {
      jobs.push(
        (async () => {
          try {
            const pageDoc = (await getDoc(page, opts)).doc;
            pageDoc('button.btn')
              .filter((_i, el) => /V-Cloud|G-Direct/i.test(pageDoc(el).text()))
              .each((_j, el) => {
                const source = pageDoc(el).parent().attr('href');
                if (source) jobs.push(vcloud(source, 'RogMovies', emit));
              });
          } catch {
            /* skip page */
          }
        })()
      );
    }
  } else {
    const seasonRe = new RegExp(`Season ${ctx.season}`, 'i');
    const episodeText = `Episode ${ctx.episode}`;

    const headings = mainDoc('h3,h5').toArray().filter((el) => seasonRe.test(mainDoc(el).text()));
    for (const heading of headings) {
      const siblings = mainDoc(heading).nextUntil('h3,h5').toArray();
      const links = [];
      for (const sib of siblings) {
        mainDoc(sib)
          .find('a')
          .filter((_i, a) => /V-Cloud|Single|Episode|G-Direct/i.test(mainDoc(a).text()))
          .each((_j, a) => {
            const href = mainDoc(a).attr('href');
            if (href && !links.includes(href)) links.push(href);
          });
      }

      for (const page of links) {
        jobs.push(
          (async () => {
            try {
              const pageDoc = (await getDoc(page, opts)).doc;
              const epNode = pageDoc('h4')
                .toArray()
                .find((el) => pageDoc(el).text().toLowerCase().includes(episodeText.toLowerCase()));
              if (!epNode) return;
              pageDoc(epNode)
                .next()
                .find('a')
                .filter((_i, a) => /V-Cloud|Single|Episode|G-Direct/i.test(pageDoc(a).text()))
                .each((_j, a) => {
                  const link = pageDoc(a).attr('href');
                  if (link) jobs.push(vcloud(link, 'RogMovies', emit));
                });
            } catch {
              /* skip */
            }
          })()
        );
      }
    }
  }

  await Promise.allSettled(jobs);
}
