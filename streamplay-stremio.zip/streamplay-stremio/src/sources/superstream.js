// SuperStream source - port of invokeSuperstream (StreamPlayExtractor.kt:5161-5255)
// + the standalone SuperStream module. Requires a FebBox session token (cookie)
// provided by the user via the Keys tab (config.k.febbox) or SUPERSTREAM_TOKEN
// env. API hosts are env-driven (SUPERSTREAM_FOURTH_API / NUVFEB) - they are
// private infra in the extension's build secrets and rotate over time.
import { getDoc, getText } from '../http.js';

export const id = 'superstream';

const FOURTH_API = (process.env.SUPERSTREAM_FOURTH_API || '').replace(/\/$/, '');
const NUVFEB = (process.env.NUVFEB || '').replace(/\/$/, '');
const ENV_TOKEN = process.env.SUPERSTREAM_TOKEN || '';

function qualityFromName(q) {
  const s = (q || '').toLowerCase();
  if (s.includes('2160') || s === '4k') return 2160;
  const m = s.match(/(\d{3,4})p/);
  if (m) return parseInt(m[1], 10);
  return null;
}

export async function find(ctx, emit) {
  const token = ctx.keys?.febbox || ENV_TOKEN;
  if (!token) return; // needs the user's FebBox session

  let tmdbId = ctx.tmdbId;
  const season = ctx.season ?? 1;
  const episode = ctx.episode ?? 1;

  // Path A (extension primary): fourthAPI search by imdb -> mediaId.
  if (FOURTH_API && ctx.imdbId) {
    try {
      const search = (await getDoc(`${FOURTH_API}/search?keyword=${encodeURIComponent(ctx.imdbId)}`)).doc;
      const href = search('h2.film-name a').first().attr('href');
      if (href) {
        const mediaUrl = /^https?:/i.test(href) ? href : FOURTH_API + href;
        const mediaDoc = (await getDoc(mediaUrl)).doc;
        const mediaId = parseInt(
          (mediaDoc('h2.heading-name a').first().attr('href') || '').split('/').pop(),
          10
        );
        if (Number.isFinite(mediaId) && mediaId > 0) tmdbId = mediaId; // external source uses this id space
      }
    } catch {
      /* fall through to NuvFeb */
    }
  }

  // NuvFeb media API (needs TMDB/media id + FebBox cookie).
  if (!NUVFEB || tmdbId == null) return;
  const enc = encodeURIComponent(token);
  const url =
    ctx.season == null
      ? `${NUVFEB}/api/media/movie/${tmdbId}?cookie=${enc}`
      : `${NUVFEB}/api/media/tv/${tmdbId}/${ctx.season}/${ctx.episode}?cookie=${enc}`;

  try {
    const resp = await getText(url, { headers: { Referer: 'https://www.febbox.com/' } });
    if (resp.statusCode >= 400) return;
    const parsed = JSON.parse(resp.body);
    for (const version of parsed?.versions || []) {
      const baseTitle = (version?.name || '').trim() || 'Stream';
      for (const link of version?.links || []) {
        const streamUrl = link?.url;
        if (!streamUrl) continue;
        const q = link?.quality || '';
        const label = q.toUpperCase() === 'ORG' ? `${baseTitle} • ORG` : baseTitle;
        emit({
          source: 'SuperStream',
          title: `SuperStream • ${label}`,
          url: streamUrl,
          quality: qualityFromName(q),
          kind: /\.m3u8/i.test(streamUrl) ? 'm3u8' : 'video',
        });
      }
    }
  } catch {
    /* fail soft */
  }
}
