// TopMovies source - port of invokeTopMovies (StreamPlayExtractor.kt:3904-4032).
// IMDb/title search -> post -> download-links button -> detail page ->
// fast-server gdrive links -> hrefli bypass -> router.
import { getDoc } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';
import { bypassHrefli } from '../extractors/hrefli.js';

export const id = 'topmovies';

const FIREFOX_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0';

async function findFirstPostHref(api, query) {
  try {
    const doc = (await getDoc(`${api}/?s=${encodeURIComponent(query)}`)).doc;
    const href = doc('#content_box article a, #content_box .post-cards article a').first().attr('href');
    return href && href !== '' ? href : null;
  } catch {
    return null;
  }
}

export async function find(ctx, emit) {
  const api = (await getDomain('topMovies')) || '';
  if (!api) return;

  let hrefpattern = null;

  if (ctx.imdbId) {
    const q = ctx.season == null ? ctx.imdbId : `${ctx.imdbId}+Season+${ctx.season}`;
    hrefpattern = await findFirstPostHref(api, q);
  }

  if (!hrefpattern && ctx.title) {
    const cleanTitle = ctx.title
      .replace(/'/g, '')
      .replace(/’/g, '')
      .replace(/[:\-–_]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const queries =
      ctx.season == null
        ? [ctx.year != null ? `${cleanTitle} ${ctx.year}` : null, cleanTitle].filter(Boolean)
        : [`${cleanTitle} Season ${ctx.season}`, cleanTitle];

    for (const q of queries) {
      hrefpattern = await findFirstPostHref(api, q);
      if (hrefpattern) break;
    }
  }

  if (!hrefpattern) return;

  let doc;
  try {
    doc = (await getDoc(hrefpattern, { headers: { 'User-Agent': FIREFOX_UA } })).doc;
  } catch {
    return;
  }

  const jobs = [];

  if (ctx.season == null) {
    const detailPageUrls = [];
    doc("a.maxbutton-download-links, a[class*='maxbutton']")
      .each((_i, el) => {
        const href = doc(el).attr('href');
        if (href) detailPageUrls.push(href);
      });

    for (const detailPageUrl of detailPageUrls) {
      jobs.push(
        (async () => {
          try {
            const detailDoc = (await getDoc(detailPageUrl)).doc;
            const driveLinks = [];
            detailDoc("a.maxbutton-fast-server-gdrive, a[class*='fast-server-gdrive']").each((_i, el) => {
              const href = detailDoc(el).attr('href');
              if (href) driveLinks.push(href);
            });

            for (const driveLink of driveLinks) {
              const finalLink =
                /unblockedgames|thenaukriadda|href\.li/i.test(driveLink)
                  ? await bypassHrefli(driveLink)
                  : driveLink;
              if (finalLink) await routeExtractor(finalLink, 'TopMovies', emit);
            }
          } catch {
            /* skip */
          }
        })()
      );
    }
  } else {
    const detailPageUrls = [];
    doc("a.maxbutton-g-drive, a[class*='maxbutton']").each((_i, el) => {
      const href = doc(el).attr('href');
      if (href) detailPageUrls.push(href);
    });

    for (const detailPageUrl of detailPageUrls) {
      jobs.push(
        (async () => {
          try {
            const detailDoc = (await getDoc(detailPageUrl)).doc;
            const el = detailDoc('span strong, p, a')
              .toArray()
              .find((e) => new RegExp(`.*Episode\\s+${ctx.episode}.*`, 'i').test(detailDoc(e).text()));
            if (!el) return;

            const $el = detailDoc(el);
            let episodeLink = $el.attr('href');
            if (!episodeLink) {
              episodeLink =
                $el.closest('a').attr('href') || $el.parent().closest('a').attr('href') || '';
            }
            if (!episodeLink) return;

            const finalLink = /unblockedgames|thenaukriadda|href\.li/i.test(episodeLink)
              ? await bypassHrefli(episodeLink)
              : episodeLink;
            if (finalLink) await routeExtractor(finalLink, 'TopMovies', emit);
          } catch {
            /* skip */
          }
        })()
      );
    }
  }

  await Promise.allSettled(jobs);
}
