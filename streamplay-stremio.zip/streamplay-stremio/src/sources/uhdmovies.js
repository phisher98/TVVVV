// UHDMovies source - port of invokeUhdmovies (StreamPlayExtractor.kt:2293-2388).
// search/<query year> -> post page -> maxbutton links (season/episode walk for
// series) -> driveleech/driveseed redirect pages or hrefli bypass -> router.
import { getDoc, getText, baseUrlOf } from '../http.js';
import { getDomain } from '../domains.js';
import { routeExtractor } from '../extractors/hostRouter.js';
import { bypassHrefli } from '../extractors/hrefli.js';

export const id = 'uhdmovies';

export async function find(ctx, emit) {
  const domain = (await getDomain('UHDMovies')) || '';
  const query = ctx.title?.replace(/-/g, ' ').replace(/:/g, ' ').trim();
  if (!domain || !query) return;

  const searchUrl = `${domain}/search/${encodeURIComponent(`${query} ${ctx.year ?? ''}`.trim())}`;

  let pageUrl;
  try {
    pageUrl = (await getDoc(searchUrl)).doc('article div.entry-image a').first().attr('href');
  } catch {
    return;
  }
  if (!pageUrl) return;

  const doc = (await getDoc(pageUrl)).doc;

  let links = [];
  if (ctx.season == null) {
    const byYear = doc('div.entry-content p')
      .toArray()
      .filter((p) => doc(p).text().includes(String(ctx.year ?? '')))
      .map((p) => doc(p).next().find('a.maxbutton-1, a.maxbutton, a').filter((_i, a) => /download/i.test(doc(a).text()) || /maxbutton/.test(doc(a).attr('class') || '')).first().attr('href'))
      .filter(Boolean);
    const deduped = [...new Set(byYear)];
    if (deduped.length > 0) {
      links = deduped;
    } else {
      doc('div.entry-content a.maxbutton-1, div.entry-content a.maxbutton, div.entry-content a')
        .each((_i, a) => {
          const href = doc(a).attr('href');
          if (href && /download/i.test(doc(a).text()) && !links.includes(href)) links.push(href);
        });
    }
  } else {
    let currentSeason = 1;
    doc('h1, h2, h3, h4, h5, pre, p, a').each((_i, el) => {
      const tag = (el.get(0)?.tagName || el[0]?.tagName || (el.get ? el.get(0).tagName : el.tagName) || '').toLowerCase();
      const $el = doc(el);
      const text = $el.text() || '';
      if (tag !== 'a') {
        const seasonMatch = text.match(/(?:season\s*|S)(\d+)/i);
        if (seasonMatch) currentSeason = parseInt(seasonMatch[1], 10) || currentSeason;
      }
      if (tag === 'a' && text.toLowerCase().includes(`episode ${ctx.episode}`)) {
        const sMatch = text.match(/(?:season\s*|S)(\d+)\s*(?:episode|ep|E)/i);
        const epSeason = sMatch ? parseInt(sMatch[1], 10) : currentSeason;
        if (epSeason === ctx.season) {
          const href = $el.attr('href');
          if (href) links.push(href);
        }
      }
    });
    links = [...new Set(links)];
  }

  const jobs = links.map(async (link) => {
    try {
      let driveLink = link;
      if (/driveleech|driveseed/i.test(link)) {
        const text = (await getText(link)).body;
        const fileId = text.match(/window\.location\.replace\(["'](.*?)["']\)/)?.[1];
        if (fileId) driveLink = baseUrlOf(link) + fileId;
      } else {
        driveLink = (await bypassHrefli(link)) || link;
      }
      await routeExtractor(driveLink, 'UHDMovies', emit);
    } catch {
      /* skip link */
    }
  });

  await Promise.allSettled(jobs);
}
