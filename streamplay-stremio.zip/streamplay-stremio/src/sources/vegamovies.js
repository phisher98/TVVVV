// VegaMovies source - port of invokeVegamovies (StreamPlayExtractor.kt:4116).
// Typesense-style search API (hits[].document with imdb_id / post_title /
// permalink) -> post pages -> V-Cloud buttons -> vcloud extractor.
import { getDoc, getText } from '../http.js';
import { getDomain } from '../domains.js';
import { vcloud } from '../extractors/vcloud.js';

export const id = 'vegamovies';

const VEGA_HEADERS = {
  Accept:
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
  'Accept-Language': 'en-US,en;q=0.9',
  'Cache-Control': 'no-cache',
  Pragma: 'no-cache',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'none',
  'Sec-Fetch-User': '?1',
  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Microsoft Edge";v="120"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Linux"',
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
  cookie: 'xla=s4t',
};

async function fetchResults(api, query) {
  try {
    const resp = await getText(`${api}/search.php?q=${query.replace(/ /g, '%20')}`, {
      referer: api,
      headers: VEGA_HEADERS,
    });
    const json = JSON.parse(resp.body);
    return (json.hits || []).map((h) => h?.document).filter(Boolean);
  } catch {
    return [];
  }
}

export async function find(ctx, emit) {
  const api = (await getDomain('vegamovies')) || '';
  const imdb = ctx.imdbId;
  if (!api || !imdb) return;

  const opts = { referer: api, headers: VEGA_HEADERS };

  // Prefer exact IMDb match, fall back to title.
  let match = (await fetchResults(api, imdb)).find((d) => (d.imdb_id || '').toLowerCase() === imdb.toLowerCase());
  if (!match) {
    if (!ctx.title) return;
    const results = await fetchResults(api, ctx.title);
    match =
      results.find((d) => (d.post_title || '').toLowerCase().includes(ctx.title.toLowerCase())) ||
      results[0];
  }
  if (!match) return;

  const permalink = match.permalink;
  if (!permalink) return;

  const mainDoc = (await getDoc(api + permalink, opts)).doc;

  const jobs = [];

  if (ctx.season == null) {
    // Movie: every dwd-button page -> V-Cloud buttons.
    const pages = [];
    mainDoc('button.dwd-button').each((_i, el) => {
      const href = mainDoc(el).parent().attr('href');
      if (href && !pages.includes(href)) pages.push(href);
    });

    for (const page of pages) {
      jobs.push(
        (async () => {
          try {
            const pageDoc = (await getDoc(page, opts)).doc;
            pageDoc('button.btn')
              .filter((_i, el) => /V-Cloud/i.test(pageDoc(el).text()))
              .each((_j, el) => {
                const source = pageDoc(el).parent().attr('href');
                if (source) jobs.push(vcloud(source, 'VegaMovies', emit));
              });
          } catch {
            /* skip page */
          }
        })()
      );
    }
  } else {
    // TV: walk headings "Season N" / episode blocks.
    const seasonRe = new RegExp(`Season ${ctx.season}`, 'i');
    const episodeRe = new RegExp(`Episodes?:\\s*${ctx.episode}`, 'i');

    const headings = mainDoc('h3,h5').toArray().filter((el) => {
      const text = mainDoc(el).text();
      return seasonRe.test(text) || /Episode/i.test(text);
    });

    for (const heading of headings) {
      // nextElementSibling().takeWhile(tag !in h3/h5/h4)
      const siblings = mainDoc(heading).nextUntil('h3,h5,h4').toArray();
      const links = [];
      for (const sib of siblings) {
        mainDoc(sib)
          .find('a')
          .filter((_i, a) => /V-Cloud|Single|Episode/i.test(mainDoc(a).text()))
          .each((_j, a) => {
            const href = mainDoc(a).attr('href');
            if (href && !links.includes(href)) links.push(href);
          });
      }

      for (const page of links) {
        jobs.push(
          (async () => {
            try {
              const pageDoc = (await getDoc(page, opts)).doc;
              const epNode = pageDoc('h4')
                .toArray()
                .find((el) => episodeRe.test(pageDoc(el).text()));
              if (!epNode) return;

              const epLinks = [];
              pageDoc(epNode)
                .next()
                .find('a')
                .filter((_i, a) => /V-Cloud|Single|Episode/i.test(pageDoc(a).text()))
                .each((_j, a) => {
                  const href = pageDoc(a).attr('href');
                  if (href) epLinks.push(href);
                });
              for (const link of epLinks) {
                await vcloud(link, 'VegaMovies', emit);
              }
            } catch {
              /* skip */
            }
          })()
        );
      }
    }
  }

  await Promise.allSettled(jobs);
}
