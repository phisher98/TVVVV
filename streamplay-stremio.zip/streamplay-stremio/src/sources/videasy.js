// Videasy source - port of invokeVideasy (StreamPlayExtractor.kt:2483-2622).
// api.speedracelight.com: seed -> 9 servers, sources-with-title endpoint,
// decrypt with the same keystream cipher as Vidy (magic "mvm1").
import { getText, USER_AGENT } from '../http.js';
import { decryptVidy, qualityOf, fetchSeed } from '../extractors/vidycipher.js';

export const id = 'videasy';

const API = 'https://api.speedracelight.com';
const PLAYER_ORIGIN = 'https://player.videasy.to';

const SERVERS = [
  { name: 'Yoru', endpoint: 'cdn' },
  { name: 'Cypher', endpoint: 'downloader2' },
  { name: 'Breach', endpoint: 'm4uhd' },
  { name: 'Neon', endpoint: 'vsrc' },
  { name: 'Vyse', endpoint: 'hdmovie', filterQuality: 'English' },
  { name: 'Killjoy', endpoint: 'meine', extraParams: 'language=german' },
  { name: 'Fade', endpoint: 'hdmovie', filterQuality: 'Hindi' },
  { name: 'Omen', endpoint: 'lamovie' },
  { name: 'Raze', endpoint: 'superflix' },
];

const HEADERS = {
  Accept: '*/*',
  'User-Agent': USER_AGENT,
  Origin: PLAYER_ORIGIN,
  Referer: `${PLAYER_ORIGIN}/`,
};

export async function find(ctx, emit) {
  if (!ctx.title || !ctx.tmdbId) return;

  const seed = await fetchSeed(API, ctx.tmdbId, HEADERS);
  if (!seed) return;

  const encTitle = encodeURIComponent(encodeURIComponent(ctx.title));
  const isTv = ctx.season != null;

  const jobs = SERVERS.map(async (server) => {
    try {
      const extra = server.extraParams ? `&${server.extraParams}` : '';
      const url = isTv
        ? `${API}/${server.endpoint}/sources-with-title?title=${encTitle}&mediaType=tv&year=${ctx.year ?? ''}&tmdbId=${ctx.tmdbId}&episodeId=${ctx.episode ?? ''}&seasonId=${ctx.season}&imdbId=${ctx.imdbId || ''}&enc=2&seed=${seed}${extra}`
        : `${API}/${server.endpoint}/sources-with-title?title=${encTitle}&mediaType=movie&year=${ctx.year ?? ''}&tmdbId=${ctx.tmdbId}&imdbId=${ctx.imdbId || ''}&enc=2&seed=${seed}${extra}`;

      const encDataRes = await getText(url, { headers: HEADERS });
      if (encDataRes.statusCode >= 400) return;
      const encData = encDataRes.body.trim();
      if (!encData || encData.startsWith('{')) return;

      const decStr = decryptVidy(encData, seed, ctx.tmdbId);
      let parsed = null;
      if (decStr) {
        try {
          parsed = JSON.parse(decStr);
        } catch {
          parsed = null;
        }
      }
      if (!parsed) {
        // Fallback: external decryption service (same as BuildConfig.VideasyDEC path).
        try {
          const { postText } = await import('../http.js');
          const decResp = await postText(`https://enc-dec.app/api/dec-videasy`, {
            json: { text: encData, id: ctx.tmdbId, seed },
          });
          parsed = JSON.parse(decResp.body)?.result || null;
        } catch {
          return;
        }
      }
      if (!parsed) return;

      for (const sourceObj of parsed.sources || []) {
        const sourceUrl = sourceObj?.url;
        if (!sourceUrl) continue;
        const qualityStr = sourceObj.quality || 'Unknown';
        if (server.filterQuality && !qualityStr.toLowerCase().includes(server.filterQuality.toLowerCase())) {
          continue;
        }
        emit({
          source: 'Videasy',
          title: `Videasy [${server.name}]`,
          url: sourceUrl,
          quality: qualityOf(qualityStr),
          kind: /\.m3u8/i.test(sourceUrl) ? 'm3u8' : /\.mp4|\.mkv/i.test(sourceUrl) ? 'video' : null,
          referer: `${PLAYER_ORIGIN}/`,
          headers: HEADERS,
        });
      }
    } catch {
      /* skip server */
    }
  });

  await Promise.allSettled(jobs);
}
