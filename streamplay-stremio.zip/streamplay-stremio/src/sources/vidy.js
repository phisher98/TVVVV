// Vidy source - port of invokeVidy (StreamPlayExtractor.kt:2798-2910).
// api.wecollege.net: seed -> per-server sources endpoint -> keystream
// decryption (magic "mvm1", shared with Videasy) -> HLS/MP4.
import { getText } from '../http.js';
import { decryptVidy, qualityOf, fetchSeed, VIDY_HEADERS, VIDY_BASE_HEADERS } from '../extractors/vidycipher.js';

export const id = 'vidy';

const VIDY_API = 'https://api.wecollege.net';
const VIDY_BASE = 'https://www.vidy.st';

const DEFAULT_SERVERS = [
  { endpoint: 'miami', name: 'Miami' },
  { endpoint: 'boise', name: 'Boise' },
  { endpoint: 'vegas', name: 'Vegas' },
  { endpoint: 'reno', name: 'Reno' },
  { endpoint: 'oakland', name: 'Oakland' },
  { endpoint: 'seattle', name: 'Seattle' },
  { endpoint: 'phoenix', name: 'Phoenix' },
  { endpoint: 'atlanta', name: 'Atlanta' },
  { endpoint: 'portland', name: 'Portland' },
  { endpoint: 'austin', name: 'Austin' },
  { endpoint: 'dallas', name: 'Dallas' },
  { endpoint: 'tampa', name: 'Tampa' },
  { endpoint: 'orlando', name: 'Orlando' },
  { endpoint: 'munich', name: 'Munich', extra: 'language=german' },
  { endpoint: 'berlin', name: 'Berlin' },
  { endpoint: 'paris', name: 'Paris' },
  { endpoint: 'delhi', name: 'Delhi' },
];

// Dynamic server discovery from the site's Next.js chunks (falls back to defaults).
let cachedServers = null;

async function getVidyServers() {
  if (cachedServers) return cachedServers;
  try {
    const home = await getText(VIDY_BASE, { timeout: 8000, headers: VIDY_BASE_HEADERS });
    const manifestPath = home.body.match(/\/_next\/static\/([^/]+)\/_buildManifest\.js/)?.[0];
    if (!manifestPath) return DEFAULT_SERVERS;

    const manifest = await getText(`${VIDY_BASE}${manifestPath}`, { timeout: 8000, headers: VIDY_BASE_HEADERS });
    const chunkPath = manifest.body.match(/static\/chunks\/122-[0-9a-f]+\.js/)?.[0];
    if (!chunkPath) return DEFAULT_SERVERS;

    const chunk = await getText(`${VIDY_BASE}/_next/${chunkPath}`, { timeout: 8000, headers: VIDY_BASE_HEADERS });
    const endpoints = [...new Set([...chunk.body.matchAll(/\/([a-z]+)\/sources/g)].map((m) => m[1]))];
    if (endpoints.length === 0) return DEFAULT_SERVERS;

    cachedServers = endpoints.map((ep) => ({
      endpoint: ep,
      name: ep.charAt(0).toUpperCase() + ep.slice(1),
      extra: ep === 'munich' ? 'language=german' : null,
    }));
    return cachedServers;
  } catch {
    return DEFAULT_SERVERS;
  }
}

export async function find(ctx, emit) {
  if (!ctx.title || !ctx.tmdbId) return;

  const seed = await fetchSeed(VIDY_API, ctx.tmdbId, VIDY_HEADERS);
  if (!seed) return;

  const isTv = ctx.season != null;
  const encTitle = encodeURIComponent(ctx.title).replace(/\+/g, '%20');
  let q = `title=${encTitle}&mediaType=${isTv ? 'tv' : 'movie'}`;
  if (ctx.year != null) q += `&year=${ctx.year}`;
  if (isTv) {
    q += `&seasonId=${ctx.season}`;
    if (ctx.episode != null) q += `&episodeId=${ctx.episode}`;
  }
  q += `&tmdbId=${ctx.tmdbId}`;
  if (ctx.imdbId) q += `&imdbId=${ctx.imdbId}`;
  q += `&enc=2&seed=${seed}`;

  const servers = await getVidyServers();

  const jobs = servers.map(async (server) => {
    try {
      let url = `${VIDY_API}/${server.endpoint}/sources?${q}`;
      if (server.extra) url += `&${server.extra}`;

      const res = await getText(url, { headers: VIDY_HEADERS, timeout: 10000 });
      if (res.statusCode >= 400) return;
      const body = res.body.trim();
      if (!body || body.startsWith('<') || body.startsWith('{')) return;

      const decStr = decryptVidy(body, seed, ctx.tmdbId);
      if (!decStr) return;
      let parsed;
      try {
        parsed = JSON.parse(decStr);
      } catch {
        return;
      }

      for (const src of parsed.sources || []) {
        const streamUrl = src?.url;
        if (!streamUrl) continue;
        emit({
          source: 'Vidy',
          title: `Vidy [${server.name}]`,
          url: streamUrl,
          quality: qualityOf(src.quality || 'Auto'),
          kind: /\.m3u8/i.test(streamUrl) ? 'm3u8' : /\.mp4|\.mkv/i.test(streamUrl) ? 'video' : null,
          referer: `${VIDY_BASE}/`,
          headers: VIDY_HEADERS,
        });
      }

      if ((parsed.sources || []).length === 0 && parsed.playlist) {
        emit({
          source: 'Vidy',
          title: `Vidy [${server.name}]`,
          url: parsed.playlist,
          quality: null,
          kind: 'm3u8',
          referer: `${VIDY_BASE}/`,
          headers: VIDY_HEADERS,
        });
      }
    } catch {
      /* skip server */
    }
  });

  await Promise.allSettled(jobs);
}
