// XDMovies source - port of invokeXDmovies (StreamPlayExtractor.kt:508-604).
// Search API (x-auth-token header) -> tmdb match -> post page. The page sits
// behind Cloudflare: direct fetch first, Firecrawl CF-bypass fallback
// (replaces the extension's WebView cloudflareKiller / Turnstile solver).
import { getDoc, getText } from '../http.js';
import { getDocCF, isCfChallenge } from '../fetchcf.js';
import { routeExtractor } from '../extractors/hostRouter.js';

export const id = 'xdmovies';

const API = process.env.XDMOVIES_API || 'https://huh.xdmovies.wtf';
// Embedded in the extension (base64 "7297skkihkajwnsgaklakshuwd").
const AUTH_TOKEN = '7297skkihkajwnsgaklakshuwd';

const HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
  Referer: `${API}/`,
  'x-requested-with': 'XMLHttpRequest',
  'x-auth-token': AUTH_TOKEN,
};

function qualityFromLabel(label) {
  const m = (label || '').match(/(\d{3,4})p/i);
  return m ? parseInt(m[1], 10) : null;
}

function codecFromLabel(label) {
  const m = (label || '').match(/(av1|h\.264|h\.265|hdr|sdr)/i);
  return m ? m[1] : '';
}

export async function find(ctx, emit) {
  if (!ctx.title) return;

  // 1) fuzzy search
  let searchData;
  try {
    const resp = await getText(`${API}/php/search_api.php?query=${encodeURIComponent(ctx.title)}&fuzzy=true`, {
      headers: HEADERS,
      timeout: 10000,
    });
    searchData = JSON.parse(resp.body);
  } catch {
    return;
  }
  if (!Array.isArray(searchData)) return;

  const matched =
    searchData.find((s) => ctx.tmdbId != null && String(s.tmdb_id) === String(ctx.tmdbId)) ||
    searchData.find((s) => (s.title || '').toLowerCase().includes(ctx.title.toLowerCase()));
  if (!matched?.path) return;

  // 2) post page - CF-protected: direct first, Firecrawl fallback
  const pageUrl = API + matched.path;
  let doc = null;
  try {
    const resp = await getText(pageUrl, { referer: `${API}/` });
    if (!isCfChallenge(resp.body)) {
      doc = (await getDoc(pageUrl, { referer: `${API}/` })).doc;
    }
  } catch {
    doc = null;
  }
  if (!doc) {
    doc = await getDocCF(pageUrl);
  }
  if (!doc) {
    console.warn('[xdmovies] page blocked by CF and firecrawl fallback failed');
    return;
  }

  const jobs = [];

  if (ctx.season == null) {
    // Movie: div.download-item blocks
    doc('div.download-item').each((_i, item) => {
      const $item = doc(item);
      const link = ($item.find('a[href]').first().attr('href') || '').trim();
      if (!link) return;
      const label = $item.find('div').first().text() || '';
      jobs.push(routeExtractor(link, `XDMovies ${codecFromLabel(label)}`.trim(), emit));
    });
  } else {
    // Series: episode cards filtered by SxxEyy
    const epRe = new RegExp(
      `S${String(ctx.season).padStart(2, '0')}E${String(ctx.episode ?? 0).padStart(2, '0')}`,
      'i'
    );
    doc('div.episode-card').each((_i, card) => {
      const $card = doc(card);
      const cardTitle = $card.find('.episode-title').first().text() || '';
      if (!epRe.test(cardTitle)) return;
      const link = (
        $card.find('a.movie-download-btn[href], a.download-button[href]').first().attr('href') || ''
      ).trim();
      if (!link) return;
      const codec = ($card.find('.codec-badge').first().text() || '').trim() || codecFromLabel(cardTitle);
      jobs.push(routeExtractor(link, `XDMovies ${codec}`.trim(), emit));
    });
  }

  await Promise.allSettled(jobs);
}
