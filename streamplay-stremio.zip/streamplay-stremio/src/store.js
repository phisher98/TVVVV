// Short-config store: persists user configs server-side so install URLs
// become /s/<id>/manifest.json instead of a 2KB base64 blob.
// Ids are derived from the config hash -> idempotent (same config = same id).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'data');
const STORE_FILE = path.join(DATA_DIR, 'configs.json');

let store = {};
try {
  if (fs.existsSync(STORE_FILE)) store = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
} catch {
  store = {};
}

function save() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(STORE_FILE, JSON.stringify(store));
  } catch (err) {
    console.warn('[store] save failed:', err.message);
  }
}

export function configId(config) {
  const hash = crypto.createHash('sha256').update(JSON.stringify(config)).digest('base64url');
  return hash.slice(0, 8);
}

// Returns the short id; stores/overwrites the config under it.
export function shorten(config) {
  const id = configId(config);
  store[id] = config;
  save();
  return id;
}

export function lookup(id) {
  return store[id] || null;
}
