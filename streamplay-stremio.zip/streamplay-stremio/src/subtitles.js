// Subtitles resource: merges the public OpenSubtitles Stremio addon
// (opensubtitles-v3.strem.io - same source StreamPlay uses) with Wyzie
// (sub.wyzie.ru), ordered by the user's preferred languages.
import { cached } from './cache.js';
import { getText } from './http.js';

const OS_ADDON = 'https://opensubtitles-v3.strem.io';
const WYZIE = 'https://sub.wyzie.ru';

const LANG_MAP = {
  en: ['english', 'en'],
  hi: ['hindi', 'hi'],
  es: ['spanish', 'es'],
  fr: ['french', 'fr'],
  de: ['german', 'de'],
  pt: ['portuguese', 'pt'],
  ar: ['arabic', 'ar'],
  ru: ['russian', 'ru'],
  it: ['italian', 'it'],
  tr: ['turkish', 'tr'],
  ja: ['japanese', 'ja'],
  ko: ['korean', 'ko'],
  zh: ['chinese', 'zh'],
  ta: ['tamil', 'ta'],
  te: ['telugu', 'te'],
};

async function fromOpensubtitles(type, imdbId, season, episode) {
  const target = type === 'series' && season ? `${imdbId}:${season}:${episode}` : imdbId;
  const url = `${OS_ADDON}/subtitles/${type}/${target}.json`;
  return cached(`ossub:${url}`, 60 * 60 * 1000, async () => {
    try {
      const resp = await getText(url, { timeout: 10000 });
      return JSON.parse(resp.body)?.subtitles || [];
    } catch {
      return [];
    }
  });
}

async function fromWyzie(type, imdbId, season, episode) {
  const params = new URLSearchParams({ id: imdbId });
  if (type === 'series' && season) {
    params.set('season', String(season));
    if (episode) params.set('episode', String(episode));
  }
  const url = `${WYZIE}/search?${params.toString()}`;
  return cached(`wysub:${url}`, 60 * 60 * 1000, async () => {
    try {
      const resp = await getText(url, { timeout: 10000 });
      const arr = JSON.parse(resp.body);
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  });
}

function normLangCode(sub) {
  const raw = (sub.lang || sub.language || sub.langCode || sub.ext || '').toString().toLowerCase();
  for (const [code, names] of Object.entries(LANG_MAP)) {
    if (names.some((n) => raw.includes(n))) return code;
  }
  return raw.slice(0, 2) || '';
}

export async function getSubtitles(type, imdbId, season, episode, preferredLangs) {
  const [os, wz] = await Promise.all([
    fromOpensubtitles(type, imdbId, season, episode),
    fromWyzie(type, imdbId, season, episode),
  ]);

  const seen = new Set();
  const merged = [];

  const push = (sub, sourceLabel) => {
    const url = sub.url;
    if (!url || !/^https?:/i.test(url)) return;
    const key = `${url}|${sub.lang || sub.langCode || ''}`;
    if (seen.has(key)) return;
    seen.add(key);
    merged.push({
      id: sub.id || `${sourceLabel}-${merged.length}`,
      url,
      lang: sub.lang || sub.language || sub.display || normLangCode(sub) || 'unknown',
      _code: normLangCode(sub),
    });
  };

  for (const s of os) push(s, 'os');
  for (const s of wz) push({ ...s, id: s.id || undefined, lang: s.display || s.lang || s.language }, 'wz');

  // Stable ordering: preferred languages first, then everything else.
  const order = new Map((preferredLangs || []).map((c, i) => [c, i]));
  merged.sort((a, b) => {
    const ai = order.has(a._code) ? order.get(a._code) : 999;
    const bi = order.has(b._code) ? order.get(b._code) : 999;
    return ai - bi;
  });

  return merged.slice(0, 60).map(({ id, url, lang }) => ({ id, url, lang }));
}
