#!/usr/bin/env python3
"""
firecrawl_playwright.py — minimal Playwright-only firecrawl playground scraper.

Opens the real playground page once in (full-build) Chromium, then mints a
fresh reCAPTCHA Enterprise token inside that page for EVERY scrape request
(`grecaptcha.enterprise.execute`), exactly like the website does. Tokens are
single-use / ~2 min expiry → always re-minted per attempt, auto-retry on 401.

  pip install playwright requests
  python -m playwright install chromium      # FULL build, not headless-shell
  python firecrawl_playwright.py https://netmirror.gg/tv [out.json]
"""
import json
import random
import sys
import time

import requests
from playwright.sync_api import sync_playwright

PLAYGROUND = "https://www.firecrawl.dev/playground?endpoint=scrape"
API = "https://www.firecrawl.dev/api/scrape"
AUTH = "Bearer this_is_just_a_preview_token"
DEFAULT_KEY = "6Le0qegqAAAAAEeq9YODUpwqriP7_z07liJI9O56"
ACTION = "playground_submit"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

# NOTE: the default headless *shell* reports HeadlessChrome and every token
# gets rejected — channel="chromium" (full build) is mandatory.
MINI_STEALTH = """
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
window.chrome = window.chrome || {runtime: {}};
Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
"""

GET_TOKEN_JS = """
async ({siteKey, action}) => {
    const g = window.grecaptcha && (grecaptcha.enterprise || grecaptcha);
    if (!g) throw new Error('grecaptcha is not loaded on this page');
    await new Promise((resolve) => g.ready(resolve));   // execute not callable before ready
    return await g.execute(siteKey, { action });
}
"""

DETECT_KEY_JS = """
() => {
    const el = document.querySelector('[data-sitekey], .g-recaptcha');
    if (el) return el.getAttribute('data-sitekey');
    for (const s of document.querySelectorAll('script[src*="recaptcha"]'))
        return new URL(s.src).searchParams.get('render');
    return null;
}
"""

INPAGE_FETCH_JS = """
async ({auth, payload}) => {
    const r = await fetch('/api/scrape', {
        method: 'POST',
        headers: {'content-type': 'application/json', 'authorization': auth},
        body: JSON.stringify(payload),
    });
    return {status: r.status, body: await r.text(),
            ctype: r.headers.get('content-type') || ''};
}
"""


def log(msg):
    print(msg, flush=True)


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "https://netmirror.gg/tv"
    outfile = sys.argv[2] if len(sys.argv) > 2 else "scrape_result.json"
    retries = 3

    with sync_playwright() as pw:
        try:
            browser = pw.chromium.launch(channel="chromium", headless=True)
        except Exception:
            log("[!] full chromium missing — run: python -m playwright install chromium")
            browser = pw.chromium.launch(headless=True)
        ctx = browser.new_context(
            viewport={"width": 1366, "height": 850},
            locale="en-US", timezone_id="America/New_York", user_agent=UA,
        )
        ctx.add_init_script(MINI_STEALTH)
        page = ctx.new_page()

        log(f"[*] opening {PLAYGROUND}")
        page.goto(PLAYGROUND, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_function(
            "() => !!(window.grecaptcha && grecaptcha.enterprise)", timeout=45000)
        site_key = page.evaluate(DETECT_KEY_JS) or DEFAULT_KEY
        log(f"[*] site key: {site_key}  action: {ACTION}")

        # browser cookies + UA so the POST looks like it came from the page
        http = requests.Session()
        http.headers["user-agent"] = page.evaluate("navigator.userAgent")
        for c in ctx.cookies():
            http.cookies.set(c["name"], c["value"],
                             domain=c["domain"].lstrip("."), path=c.get("path", "/"))

        for attempt in range(1, retries + 1):
            t0 = time.time()
            log(f"[*] attempt {attempt}/{retries} — minting token in page ...")
            token = page.evaluate(GET_TOKEN_JS, {"siteKey": site_key, "action": ACTION})
            log(f"    token {token[:40]}... ({len(token)} chars, {time.time()-t0:.1f}s)")

            payload = {"url": target, "onlyMainContent": True, "maxAge": 172800000,
                       "parsers": ["pdf"], "formats": ["rawHtml"],
                       "origin": "website", "recaptchaToken": token}
            headers = {"accept": "*/*", "authorization": AUTH,
                       "content-type": "application/json",
                       "origin": "https://www.firecrawl.dev",
                       "referer": PLAYGROUND}
            r = http.post(API, json=payload, headers=headers, timeout=120)
            status, body, ctype = r.status_code, r.text, r.headers.get("content-type", "")

            # edge challenge → re-send from inside the page (browser TLS)
            if status == 403 and "text/html" in ctype:
                log("[!] edge challenge — retrying via in-page fetch")
                res = page.evaluate(INPAGE_FETCH_JS,
                                    {"auth": AUTH, "payload": payload})
                status, body, ctype = res["status"], res["body"], res["ctype"]

            log(f"[*] HTTP {status} ({len(body)} bytes, {time.time()-t0:.1f}s total)")
            if status == 200 and "json" in (ctype or "application/json"):
                data = json.loads(body)
                with open(outfile, "w") as f:
                    json.dump(data, f, indent=2)
                log(f"[✓] success={data.get('success')} — saved {outfile}")
                browser.close()
                return 0
            log(f"[!] {body[:200]} — re-minting fresh token ...")
            time.sleep(2 * attempt + random.uniform(0, 1))
        log("[x] all attempts failed")
        browser.close()
        return 1


if __name__ == "__main__":
    sys.exit(main())